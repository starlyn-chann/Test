import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { crearKey, obtenerKeys, totalKeys } from '../lib/key.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'newkey',
    alias: ['generatekey', 'genkey'],
    description: 'Genera una nueva key de acceso (solo owner)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isOwner, pushName, userNumber } = options;
            
            if (!isOwner) {
                return await replyWithContext(`๑ֵ݊🍀 El comando \`${config.prefix}newkey\` no existe.\n> Usa ${config.prefix}help para ver mis comandos`);
            }
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '🔑', key: msg.key } });
            } catch (e) {}
            
            if (args.length === 0) {
                return await replyWithContext(
                    `❀ *USO DEL COMANDO*\n\n` +
                    `📌 *Formato:*\n` +
                    `${config.prefix}newkey <key> / <plan>\n\n` +
                    `📌 *Planes disponibles:*\n` +
                    `• free → 100 solicitudes/día\n` +
                    `• premium → 5,000 solicitudes/día\n` +
                    `• infinite → ∞ solicitudes\n\n` +
                    `📌 *Ejemplos:*\n` +
                    `${config.prefix}newkey MiKey123 / premium\n` +
                    `${config.prefix}newkey AbC123Xy / free`
                );
            }
            
            const texto = args.join(' ');
            const partes = texto.split('/').map(p => p.trim());
            
            if (partes.length !== 2) {
                return await replyWithContext(
                    `❀ *Formato incorrecto*\n\n` +
                    `📌 *Formato:*\n` +
                    `${config.prefix}newkey <key> / <plan>\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}newkey MiKey123 / premium`
                );
            }
            
            const [key, plan] = partes;
            
            if (!key || !plan) {
                return await replyWithContext(
                    `❀ *Datos incompletos*\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}newkey MiKey123 / premium`
                );
            }
            
            const resultado = await crearKey(key, plan);
            
            if (!resultado.success) {
                return await replyWithContext(`❌ ${resultado.message}`);
            }
            
            const data = resultado.data;
            const total = totalKeys();
            const solicitudes = data.solicitudes === Infinity ? '∞' : data.solicitudes.toLocaleString();
            
            let infoMensaje = `✅ *Key creada exitosamente*\n\n`;
            infoMensaje += `🔑 *Key:* \`${data.key}\`\n`;
            infoMensaje += `📋 *Plan:* ${data.plan.toUpperCase()}\n`;
            infoMensaje += `📊 *Solicitudes:* ${solicitudes}/día\n`;
            infoMensaje += `📅 *Creada:* ${data.created}\n\n`;
            infoMensaje += `📊 *Total keys:* ${total}`;
            
            await replyWithContext(infoMensaje);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`🔑 Nueva key generada por OWNER: ${pushName || userNumber} - Key: ${key} - Plan: ${plan}`);
            
        } catch (error) {
            console.error('❌ Error en newkey:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:*\n\`\`\`\n${error.stack || error.message}\n\`\`\``);
            } catch (e) {}
        }
    }
};