import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function getSelfPath(sock, isSubBot) {
    let botNumber = '';
    if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    
    if (!botNumber) return null;
    
    // SIEMPRE guardar en subs/{botNumber}/self.json (tanto para principal como sub-bots)
    const subDir = path.join(process.cwd(), 'subs', botNumber);
    return path.join(subDir, 'self.json');
}

function loadSelfStatus(filePath) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf-8');
            const parsed = JSON.parse(data);
            return parsed.enabled === true;
        }
    } catch (e) {}
    return false;
}

function saveSelfStatus(filePath, enabled) {
    try {
        // Asegurar que la carpeta existe
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(filePath, JSON.stringify({ enabled: enabled, updated: Date.now() }, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando estado self:', e);
        return false;
    }
}

export default {
    name: 'self',
    alias: ['privado'],
    description: 'Activa/Desactiva el modo self (solo el dueño puede usar el bot)',
    category: 'sub-bot',
    
    execute: async (sock, msg, options) => {
        try {
            const { args, config, senderNumber, userNumber, replyWithContext, isSubBot } = options;
            
            const userNumberClean = cleanNumber(senderNumber || userNumber || '');
            const botownerClean = config.botowner ? cleanNumber(config.botowner) : '';
            
            if (!botownerClean || userNumberClean !== botownerClean) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede usar este comando*`);
            }
            
            const argsLower = args[0]?.toLowerCase();
            if (!argsLower || (argsLower !== 'on' && argsLower !== 'off')) {
                return await replyWithContext(`❀ Uso incorrecto\n> Ejemplo: ${config.prefix}self on/off`);
            }
            
            const selfFilePath = getSelfPath(sock, isSubBot);
            if (!selfFilePath) {
                throw new Error('No se pudo encontrar la ruta del bot');
            }
            
            const newStatus = argsLower === 'on';
            saveSelfStatus(selfFilePath, newStatus);
            
            const statusText = newStatus ? '✅ ACTIVADO' : '❌ DESACTIVADO';
            const statusMsg = newStatus ? 'solo el dueño puede usar el bot' : 'todos pueden usar el bot';
            
            await replyWithContext(`❀ *Modo Self ${statusText}*\n> Ahora ${statusMsg}`);
            
            console.log(`🔒 Self mode ${newStatus ? 'ON' : 'OFF'} para ${selfFilePath}`);
            
        } catch (error) {
            console.error('Error en self:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`🌼 Error: ${error.message}`);
            } catch (e) {}
        }
    }
};