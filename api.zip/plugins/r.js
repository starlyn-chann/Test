import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';

const exec = promisify(_exec).bind(cp);

export default {
    name: '$',
    alias: ['exec', 'ejecutar'],
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, startTime, isOwner, pushName, userNumber, isGroup, replyWithContext, body } = options;
            const from = msg.key.remoteJid;
            
            // Verificar si el mensaje comienza con "$"
            if (!body || !body.startsWith('$')) {
                return;
            }
            
            // Solo owner puede usar este comando
            if (!isOwner) {
                return; // No responder nada, silencioso
            }
            
            // Extraer el comando después de "$"
            let command = body.substring(1).trim();
            
            if (!command) {
                return; // No hay comando, no responder
            }
            
            let o;
            try {
                await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } });
                o = await exec(command);
                await sock.sendMessage(from, { react: { text: '✔️', key: msg.key } });
            } catch (e) {
                o = e;
                await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } });
            } finally {
                const { stdout, stderr } = o;
                if (stdout?.trim()) {
                    await replyWithContext(stdout);
                }
                if (stderr?.trim()) {
                    await replyWithContext(stderr);
                }
            }
            
            console.log(`✅ Exec ejecutado por OWNER: ${pushName || userNumber}`);
            console.log(`📝 Comando: ${command.substring(0, 100)}${command.length > 100 ? '...' : ''}`);
            
        } catch (error) {
            console.error('❌ Error en exec:', error);
            // No responder nada al usuario si hay error
        }
    }
};