import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');
const BOT_STATUS_FILE = path.join(__dirname, '..', 'data', 'bot_status.json');
const WELCOME_FILE = path.join(__dirname, '..', 'data', 'welcome.json');
const GOODBYE_FILE = path.join(__dirname, '..', 'data', 'goodbye.json');
const ALERTS_FILE = path.join(__dirname, '..', 'data', 'alerts.json');

function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

function loadBotStatus() {
    try {
        if (fs.existsSync(BOT_STATUS_FILE)) {
            const data = fs.readFileSync(BOT_STATUS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

function loadWelcome() {
    try {
        if (fs.existsSync(WELCOME_FILE)) {
            const data = fs.readFileSync(WELCOME_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

function loadGoodbye() {
    try {
        if (fs.existsSync(GOODBYE_FILE)) {
            const data = fs.readFileSync(GOODBYE_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

function loadAlerts() {
    try {
        if (fs.existsSync(ALERTS_FILE)) {
            const data = fs.readFileSync(ALERTS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

export default {
    name: 'gp',
    alias: ['groupinfo'],
    description: 'Muestra información del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber, isGroup } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // Obtener metadata del grupo
            const groupMetadata = await sock.groupMetadata(from);
            
            // Obtener configuraciones
            const nsfwConfig = loadNsfwConfig();
            const isNsfwActive = nsfwConfig[from] || false;
            const nsfwStatus = isNsfwActive ? 'Activado' : 'Desactivado';
            
            const botStatus = loadBotStatus();
            const isBotActive = botStatus[from] !== false;
            const botStatusText = isBotActive ? 'Activado' : 'Desactivado';
            
            const welcomeData = loadWelcome();
            const welcomeEnabled = welcomeData[from]?.enabled !== false;
            const welcomeStatus = welcomeEnabled ? 'Activado' : 'Desactivado';
            
            const goodbyeData = loadGoodbye();
            const goodbyeEnabled = goodbyeData[from]?.enabled !== false;
            const goodbyeStatus = goodbyeEnabled ? 'Activado' : 'Desactivado';
            
            const alertsData = loadAlerts();
            const alertsEnabled = alertsData[from] !== false;
            const alertsStatus = alertsEnabled ? 'Activado' : 'Desactivado';
            
            // Obtener progreso de personajes reclamados
            const { obtenerTodosPersonajes, obtenerPersonajesReclamados } = await import('../lib/gacha.js');
            
            const todosPersonajes = await obtenerTodosPersonajes();
            const totalPersonajes = todosPersonajes ? todosPersonajes.length : 0;
            
            const reclamados = await obtenerPersonajesReclamados(from);
            const totalReclamados = reclamados ? reclamados.length : 0;
            
            const libres = totalPersonajes - totalReclamados;
            const porcentaje = totalPersonajes > 0 ? Math.round((totalReclamados / totalPersonajes) * 100) : 0;
            
            // Obtener descripción del grupo
            const groupDesc = groupMetadata.desc || groupMetadata.description || 'Sin descripción';
            
            // Obtener foto del grupo
            let groupIconBuffer = null;
            try {
                const groupIconUrl = await sock.profilePictureUrl(from, 'image');
                const { default: axios } = await import('axios');
                const iconResponse = await axios.get(groupIconUrl, { responseType: 'arraybuffer' });
                groupIconBuffer = Buffer.from(iconResponse.data);
            } catch (error) {
                console.log('No se pudo obtener la foto del grupo');
            }
            
            // Construir mensaje
            const infoText = `࣪ꉂ֟᷼ꉂ๋ׅ🍪 *Nombre* » ${groupMetadata.subject}\n` +
                           `ꉂ֟᷼ꉂ๋ׅ🍪 *Miembros* » ${groupMetadata.participants.length}\n` +
                           `ꉂ֟᷼ꉂ๋ׅ🍪 *Id* » ${from.split('@')[0]}\n` +
                           `ꉂ֟᷼ꉂ๋ׅ🍪 *Progreso* » ${totalReclamados}/${totalPersonajes} *(${porcentaje}%)*\n\n` +
                           `⋱᮫࣪ ׅ✿⃘ׅ᪲🥮 ⃘ׅ⃨֟፝ᩫ͌ᩖ̶ฺฺฺ *Nsfw* » \`${nsfwStatus}\`\n` +
                           `⋱᮫࣪ ׅ✿⃘ׅ᪲🥮 ⃘ׅ⃨֟፝ᩫ͌ᩖ̶ฺฺฺ *Bot* » \`${botStatusText}\`\n` +
                           `⋱᮫࣪ ׅ✿⃘ׅ᪲🥮 ⃘ׅ⃨֟፝ᩫ͌ᩖ̶ฺฺฺ *Alerts* » \`${alertsStatus}\`\n` +
                           `⋱᮫࣪ ׅ✿⃘ׅ᪲🥮 ⃘ׅ⃨֟፝ᩫ͌ᩖ̶ฺฺฺ *Welcome* » \`${welcomeStatus}\`\n` +
                           `⋱᮫࣪ ׅ✿⃘ׅ᪲🥮 ⃘ׅ⃨֟፝ᩫ͌ᩖ̶ฺฺฺ *Goodbye* » \`${goodbyeStatus}\`\n\n` +
                           `> ᧔❀̼ ${groupDesc}`;
            
            // Enviar con foto si está disponible
            if (groupIconBuffer) {
                await sock.sendMessage(from, {
                    image: groupIconBuffer,
                    caption: infoText,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(infoText);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`📊 Información del grupo ${groupMetadata.subject} mostrada por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en gp:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};