import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Número específico que puede usar el comando
const ALLOWED_NUMBER = '5219992042946';

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

export default {
    name: 'getcode',
    alias: [],
    description: 'obtiene el código de un archivo JS',
    category: 'owner',
    
    async execute(sock, msg, options) {
        
        const { args, config, startTime, isOwner, pushName, userNumber, isGroup, replyWithContext, isBotSelf, senderNumber } = options;
        const from = msg.key.remoteJid;
        
        // Obtener número del usuario que ejecuta el comando
        const userNumberClean = cleanNumber(senderNumber || userNumber || '');
        
        // Verificar que sea el número específico 5219992042946
        if (userNumberClean !== ALLOWED_NUMBER) {
            await replyWithContext(`🐿️`);
            return;
        }
        
        // Verificar que se proporcionó un nombre de archivo
        if (!args || args.length === 0) {
            return await replyWithContext(`🌾 *Debes proporcionar el nombre de un archivo*\n\n> Ejemplo: ${config.prefix}getcode plugins/ping.js\n> Ejemplo: ${config.prefix}getcode handler.js`);
        }
        
        const fileName = args[0].trim();
        
        // Obtener ruta base (directorio raíz del proyecto)
        const baseDir = path.resolve(__dirname, '..');
        let filePath;
        
        // Si el archivo tiene una ruta relativa
        if (fileName.includes('/') || fileName.includes('\\')) {
            filePath = path.join(baseDir, fileName);
        } else {
            // Buscar en diferentes carpetas comunes
            const possiblePaths = [
                path.join(baseDir, fileName),
                path.join(baseDir, 'plugins', fileName),
                path.join(baseDir, 'lib', fileName),
                path.join(baseDir, 'utils', fileName),
                path.join(baseDir, 'handlers', fileName),
                path.join(baseDir, 'data', fileName),
                path.join(baseDir, 'temp', fileName)
            ];
            
            // Encontrar la primera ruta que existe
            for (const possiblePath of possiblePaths) {
                if (fs.existsSync(possiblePath) && fs.statSync(possiblePath).isFile()) {
                    filePath = possiblePath;
                    break;
                }
            }
            
            // Si no se encontró, usar la ruta en plugins
            if (!filePath) {
                filePath = path.join(baseDir, 'plugins', fileName);
            }
        }
        
        // Verificar si el archivo existe
        if (!fs.existsSync(filePath)) {
            return await replyWithContext(`🌴 *El archivo* \`${fileName}\` *no existe*\n\n📁 *Rutas buscadas:*\n- plugins/${fileName}\n- lib/${fileName}\n- data/${fileName}\n- ${fileName}`);
        }
        
        // Verificar que sea un archivo
        const stats = fs.statSync(filePath);
        if (!stats.isFile()) {
            return await replyWithContext(`🌴 *${fileName}* no es un archivo válido`);
        }
        
        // Verificar tamaño del archivo (máx 5MB)
        const fileSizeMB = stats.size / (1024 * 1024);
        if (fileSizeMB > 5) {
            return await replyWithContext(`🌴 *El archivo es demasiado grande* (${fileSizeMB.toFixed(2)}MB)\n> Máximo permitido: 5MB`);
        }
        
        // Leer el contenido del archivo
        const fileContent = fs.readFileSync(filePath, 'utf8');
        
        // Enviar el código
        await replyWithContext(fileContent);
        
        console.log(`📄 Archivo enviado: ${filePath} (${stats.size} bytes) por ${pushName || userNumber}`);
    }
};