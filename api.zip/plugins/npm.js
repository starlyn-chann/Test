import axios from 'axios';

export default {
    name: 'npm',
    alias: ['npmsearch'],
    description: 'Busca paquetes en NPM',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ');
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes proporcionar el nombre del paquete NPM a buscar\n> Ejemplo: ${options.config.prefix}npm axios`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            // Llamar a la API de NPM
            const apiUrl = `https://api-xemoz-official.my.id/api/search/search-npm.php?q=${encodeURIComponent(query)}`;
            const response = await axios.get(apiUrl, {
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            // Verificar si la API respondió correctamente
            if (!response.data?.status || !response.data?.result?.success || !response.data.result.result?.length) {
                return await replyWithContext(`《✧》No se encontraron resultados para *${query}*`);
            }
            
            const results = response.data.result.result;
            
            // Construir el mensaje con el diseño exacto
            let message = `★ \`\`\`N P M - S E A R C H\`\`\`\n\n`;
            
            // Mostrar cada resultado con el mismo formato
            for (let i = 0; i < results.length; i++) {
                const result = results[i];
                message += `[ ✰ ] *Paquete ›* ${result.package}\n`;
                message += `[ ✰ ] *Versión ›* ${result.version}\n`;
                message += `[ ✰ ] *Descripción ›* ${result.description}\n`;
                message += `[ ✰ ] *Publicado ›* ${new Date(result.publishedAt).toLocaleDateString()}\n`;
                message += `[ ✰ ] *NPM ›* ${result.links.npm}\n`;
                if (result.links.repository) {
                    message += `[ ✰ ] *Repositorio ›* ${result.links.repository}`;
                }
                
                // Agregar separador entre resultados excepto en el último
                if (i < results.length - 1) {
                    message += `\n\n`;
                }
            }
            
            // Enviar el mensaje
            await replyWithContext(message);
            
            // Reacción de éxito
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ NPM buscado por ${pushName || userNumber}: "${query}" - ${results.length} resultados`);
            
        } catch (error) {
            console.error('❌ Error en npm:', error);
            
            // Reacción de error
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            // Verificar si el error es por la API lenta pero tiene datos parciales
            if (error.response?.data) {
                try {
                    const partialData = error.response.data;
                    if (partialData?.result?.result?.length) {
                        const results = partialData.result.result;
                        let message = `★ \`\`\`N P M - S E A R C H\`\`\`\n\n`;
                        
                        for (let i = 0; i < results.length; i++) {
                            const result = results[i];
                            message += `[ ✰ ] *Paquete ›* ${result.package}\n`;
                            message += `[ ✰ ] *Versión ›* ${result.version}\n`;
                            message += `[ ✰ ] *Descripción ›* ${result.description}\n`;
                            message += `[ ✰ ] *Publicado ›* ${new Date(result.publishedAt).toLocaleDateString()}\n`;
                            message += `[ ✰ ] *NPM ›* ${result.links.npm}\n`;
                            if (result.links.repository) {
                                message += `[ ✰ ] *Repositorio ›* ${result.links.repository}`;
                            }
                            
                            if (i < results.length - 1) {
                                message += `\n\n`;
                            }
                        }
                        
                        return await replyWithContext(message);
                    }
                } catch (e) {}
            }
            
            // Mensaje de error exacto
            const query = options.args?.join(' ') || 'la búsqueda';
            await options.replyWithContext(`《✧》No se encontraron resultados para *${query}*`);
        }
    }
};