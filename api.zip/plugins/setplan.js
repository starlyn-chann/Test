import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { crearKey, obtenerKeys, obtenerKeyInfo, saveKeys, loadKeys } from '../lib/key.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'upgradeplan',
    alias: ['upgrade', 'cambiarplan', 'setplan'],
    description: 'Mejora el plan de un usuario (solo owner)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isOwner, pushName, userNumber } = options;
            
            if (!isOwner) {
                return await replyWithContext(`๑ֵ݊🍀 El comando \`${config.prefix}upgradeplan\` no existe.\n> Usa ${config.prefix}help para ver mis comandos`);
            }
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '⬆️', key: msg.key } });
            } catch (e) {}
            
            if (args.length === 0) {
                return await replyWithContext(
                    `❀ *USO DEL COMANDO*\n\n` +
                    `📌 *Formato:*\n` +
                    `${config.prefix}upgradeplan <email> / <plan>\n\n` +
                    `📌 *Planes disponibles:*\n` +
                    `• free → 100 solicitudes/día\n` +
                    `• premium → 5,000 solicitudes/día\n` +
                    `• infinite → ∞ solicitudes\n\n` +
                    `📌 *Ejemplos:*\n` +
                    `${config.prefix}upgradeplan danoninoleonel@gmail.com / premium\n` +
                    `${config.prefix}upgradeplan usuario@gmail.com / infinite\n` +
                    `${config.prefix}upgradeplan user@mail.com / free`
                );
            }
            
            const texto = args.join(' ');
            const partes = texto.split('/').map(p => p.trim());
            
            if (partes.length !== 2) {
                return await replyWithContext(
                    `❀ *Formato incorrecto*\n\n` +
                    `📌 *Formato:*\n` +
                    `${config.prefix}upgradeplan <email> / <plan>\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}upgradeplan danoninoleonel@gmail.com / premium`
                );
            }
            
            const [email, nuevoPlan] = partes;
            
            if (!email || !nuevoPlan) {
                return await replyWithContext(
                    `❀ *Datos incompletos*\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}upgradeplan danoninoleonel@gmail.com / premium`
                );
            }
            
            // Validar email básico
            if (!email.includes('@') || !email.includes('.')) {
                return await replyWithContext(`❌ *Email inválido:*\n\`${email}\`\n\n📌 Usa un email válido.`);
            }
            
            // Validar plan
            const planesValidos = ['free', 'premium', 'infinite', 'infinito'];
            const planLower = nuevoPlan.toLowerCase();
            
            if (!planesValidos.includes(planLower)) {
                return await replyWithContext(
                    `❌ *Plan inválido:* \`${nuevoPlan}\`\n\n` +
                    `📌 *Planes disponibles:*\n` +
                    `• free → 100 solicitudes/día\n` +
                    `• premium → 5,000 solicitudes/día\n` +
                    `• infinite → ∞ solicitudes`
                );
            }
            
            // Buscar la key del usuario
            const keys = obtenerKeys();
            const keyData = keys.find(k => k.user === email);
            
            if (!keyData) {
                return await replyWithContext(
                    `❌ *Usuario no encontrado*\n\n` +
                    `📌 El usuario \`${email}\` no tiene una key registrada.\n\n` +
                    `📌 *Keys registradas:*\n` +
                    keys.map(k => `• ${k.user} → ${k.plan}`).join('\n') || '• Ninguna'
                );
            }
            
            const planAnterior = keyData.plan;
            
            // Actualizar el plan
            keyData.plan = planLower;
            
            // Actualizar solicitudes según el nuevo plan
            const planesSolicitudes = {
                'free': 100,
                'premium': 5000,
                'infinite': Infinity,
                'infinito': Infinity
            };
            keyData.solicitudes = planesSolicitudes[planLower] || 100;
            
            // Si el nuevo plan es infinito, reiniciar usage a 0
            if (planLower === 'infinite' || planLower === 'infinito') {
                keyData.usage = 0;
            }
            
            // Guardar cambios
            const data = loadKeys();
            const index = data.keys.findIndex(k => k.key === keyData.key);
            if (index !== -1) {
                data.keys[index] = keyData;
                saveKeys(data);
            }
            
            const solicitudesMostrar = keyData.solicitudes === Infinity ? '∞' : keyData.solicitudes.toLocaleString();
            
            let infoMensaje = `✅ *Plan actualizado exitosamente*\n\n`;
            infoMensaje += `👤 *Usuario:* ${email}\n`;
            infoMensaje += `🔑 *Key:* \`${keyData.key}\`\n`;
            infoMensaje += `📋 *Plan anterior:* ${planAnterior.toUpperCase()}\n`;
            infoMensaje += `📋 *Nuevo plan:* ${planLower.toUpperCase()}\n`;
            infoMensaje += `📊 *Solicitudes:* ${solicitudesMostrar}/día\n`;
            infoMensaje += `📅 *Actualizado:* ${new Date().toLocaleString()}`;
            
            await replyWithContext(infoMensaje);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`⬆️ Plan actualizado por OWNER: ${pushName || userNumber} - Usuario: ${email} - ${planAnterior} → ${planLower}`);
            
        } catch (error) {
            console.error('❌ Error en upgradeplan:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:*\n\`\`\`\n${error.stack || error.message}\n\`\`\``);
            } catch (e) {}
        }
    }
};