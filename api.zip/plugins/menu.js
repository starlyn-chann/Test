import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

const letterMap = {
    'a': 'α', 'A': 'α',
    'b': 'b', 'B': 'b',
    'c': 'c', 'C': 'c',
    'd': 'd', 'D': 'd',
    'e': 'ᧉ', 'E': 'ᧉ',
    'f': '𝖿', 'F': '𝖿',
    'g': 'g', 'G': 'g',
    'h': 'һ', 'H': 'һ',
    'i': 'ꪱ', 'I': 'ꪱ',
    'j': 'ȷ', 'J': 'ȷ',
    'k': 'k', 'K': 'k',
    'l': '𝗅', 'L': '𝗅',
    'm': '𝗆', 'M': '𝗆',
    'n': '𝗇', 'N': '𝗇',
    'ñ': 'ᥒ̃', 'Ñ': 'ᥒ̃',
    'o': 'ᦅ', 'O': 'ᦅ',
    'p': '𝗉', 'P': '𝗉',
    'q': '𝗊', 'Q': '𝗊',
    'r': 'ꭇ', 'R': 'ꭇ',
    's': '𝗌', 'S': '𝗌',
    't': 'ƚ', 'T': 'ƚ',
    'u': '𝗎', 'U': '𝗎',
    'v': '᥎', 'V': '᥎',
    'w': 'w', 'W': 'w',
    'x': 'x', 'X': 'x',
    'y': 'ᥡ', 'Y': 'ᥡ',
    'z': 'z', 'Z': 'z',
    '0': '𝟢', '1': '𝟣', '2': '𝟤', '3': '𝟥', '4': '𝟦',
    '5': '𝟧', '6': '𝟨', '7': '𝟩', '8': '𝟪', '9': '𝟫',
    ' ': ' ', '.': '.', ',': ',', '!': '!', '?': '?',
    '-': '-', '_': '_', '@': '@', '#': '#', '$': '$',
    '%': '%', '&': '&', '*': '*', '(': '(', ')': ')',
    '[': '[', ']': ']', '{': '{', '}': '}', ';': ';',
    ':': ':', '"': '"', "'": "'", '\\': '\\', '/': '/',
    '|': '|', '°': '°', '¡': '¡', '¿': '¿'
};

function convertToSpecialLetters(text) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        result += letterMap[char] || char;
    }
    return result;
}

export default {
    name: 'menu',
    alias: ['help', 'comandos', 'commands'],
    description: 'Muestra el menú del bot',
    category: 'main',
    
    async execute(sock, msg, options) {
        
        let { 
            args = [], 
            config = {}, 
            startTime = Date.now(), 
            isOwner = false, 
            pushName = 'Usuario', 
            userNumber = '', 
            senderJid = '', 
            isGroup = false, 
            replyWithContext = async (text) => await sock.sendMessage(msg.key.remoteJid, { text }),
            plugins = new Map(),
            isSubBot = false
        } = options;
        
        const from = msg.key.remoteJid;
        
        // Obtener número del bot actual
        let currentBotNumber = '';
        if (sock.phoneNumber) {
            currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        // ============ BANNER DESDE CONFIG ============
        const bannerUrl = config.banner || '';
        const link = 'https://moonstaff.onrender.com/';
        
        // Función para enviar texto CON BANNER
        async function sendWithBanner(text) {
            if (bannerUrl) {
                try {
                    const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                    
                    if (!uploadMethod) {
                        throw new Error('No hay método de upload disponible');
                    }
                    
                    const { imageMessage } = await prepareWAMessageMedia(
                        { image: { url: bannerUrl } },
                        { 
                            upload: uploadMethod, 
                            mediaTypeOverride: 'thumbnail-link' 
                        }
                    );
                    
                    const linkPreview = {
                        'canonical-url': link,
                        'matched-text': link,
                        title: config.nombre || config.name || "Sirius",
                        description: "Made With ❤️ - By starlyn",
                        jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                        highQualityThumbnail: imageMessage || undefined
                    };
                    
                    await sock.sendMessage(from, {
                        text: text,
                        linkPreview: linkPreview,
                        contextInfo: {
                            mentionedJid: [config.ownerNumber, senderJid].filter(Boolean),
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: '0',
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (error) {
                    console.error('Error con banner:', error);
                    await replyWithContext(text);
                }
            } else {
                await replyWithContext(text);
            }
        }
        
        // Obtener todos los comandos
        let commandList = [];
        
        if (plugins && typeof plugins.forEach === 'function') {
            const processedCommands = new Set();
            
            for (const [name, plugin] of plugins) {
                if (processedCommands.has(plugin.name)) continue;
                processedCommands.add(plugin.name);
                
                if (plugin.name && plugin.category) {
                    if (plugin.category.toLowerCase() === 'owner' && !isOwner) continue;
                    
                    commandList.push({
                        name: plugin.name,
                        alias: plugin.alias || [],
                        description: plugin.description || 'Sin descripción',
                        category: plugin.category
                    });
                }
            }
        }
        
        // Ordenar categorías
        let uniqueCategories = [...new Set(commandList.map(cmd => cmd.category))].sort();
        
        // Verificar si se solicitó una categoría específica
        let categoryFilter = null;
        if (args && args.length > 0) {
            const categoryArg = args[0].toLowerCase();
            const categoriesLower = uniqueCategories.map(c => c.toLowerCase());
            if (categoriesLower.includes(categoryArg)) {
                categoryFilter = categoryArg;
            } else {
                return await replyWithContext(`《✧》 La categoria *${args[0]}* no existe, las categorias disponibles son: *${uniqueCategories.join(', ')}*.\n> Para ver la lista completa escribe *${config.prefix}menu*`);
            }
        }
        
        // ============ CONSTRUIR MENÚ ============
        let menuText = '';
        
        // Encabezado
        menuText += `˙ ‌ ‌• ‌˚ ⁔⁔⁔⁔ㅤ ୨🍒୧ㅤ⁔⁔⁔⁔˙  ∘ ‌!! ‌         ‌ ‌ ‌ ‌ ‌ ‌ ‌\n`;
        menuText += `ꦁ   ׄ  ☘️  ࣪   𝗵𝗈𝗅𝖺 ǃǃ :3   ִ   ${pushName} *Bienvenido/a a mi menu*\n\n`;
        menuText += `.ㅤㅤ  •|| . \`𝖶𝖾𝖻𝗌\` ★•|•||  ▬ׄ▬ׅ||\n`;
        menuText += `•▬▬۟▭ㅤ★\n\n`;
        menuText += `🧁 ᳕ꯨᩙ✦ׅ۫ *Info › https://moonstaff.onrender.com/*\n`;
        menuText += `🧁 ᳕ꯨᩙ✦ׅ۫ *Soporte › https://hoshistars.vercel.app/soporte/*\n\n`;
        menuText += `.ㅤㅤ  •|| . \`𝖨𝗇𝖿𝗈\` ★•|•||  ▬ׄ▬ׅ||\n`;
        menuText += `•▬▬۟▭ㅤ★\n\n`;
        menuText += `🧁 ᳕ꯨᩙ✦۫  *Bot › ${config.nombre || config.name || 'Sirius'}*\n`;
        menuText += `🧁 ᳕ꯨᩙ✦᮫۫ *Tipo › ${config.tipo || 'principal'}*\n\n`;
        menuText += `╾ׄ𖹭ִ╼ᮀ✿ִ╾ᜒ𖹭╼ִ✿╾᩿ׄ𖹭╼ִ✿╾ᮀ𖹭ִ╼ᜒ✿ִ╾ׄ𖹭᩿╼\n`;
        menuText += `> *Disfruta de este nuevo proyecto ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ*\n\n`;
        
        if (categoryFilter) {
            // ============ MOSTRAR CATEGORÍA ESPECÍFICA ============
            const filteredCommands = commandList.filter(cmd => cmd.category.toLowerCase() === categoryFilter);
            
            if (filteredCommands.length === 0) {
                menuText = `「✰」 No hay comandos en la categoría *${categoryFilter}*`;
            } else {
                // Título de la categoría con letras especiales
                const categoryNameSpecial = convertToSpecialLetters(categoryFilter.toUpperCase());
                menuText += `꒰͜͡ ꒰͜͡ ۫ ֢ ꩜⵿֟፝  *${categoryNameSpecial}* ꩜ׂ 𑇖ׂ𑇖\n\n`;
                
                for (const cmd of filteredCommands) {
                    const aliasText = cmd.alias.length > 0 ? ` ${config.prefix}${cmd.alias.join(` ${config.prefix}`)}` : '';
                    menuText += ` ＠꤫࣪🥥᪲𝄒ׅ𝄒﹚ᜒ ${config.prefix}${cmd.name}${aliasText}\n`;
                    menuText += `> *» ${cmd.description}*\n\n`;
                }
            }
            
            await sendWithBanner(menuText);
            
        } else {
            // ============ MOSTRAR TODAS LAS CATEGORÍAS ============
            for (const category of uniqueCategories) {
                const filteredCommands = commandList.filter(cmd => cmd.category === category);
                
                if (filteredCommands.length === 0) continue;
                
                // Título de la categoría con letras especiales
                const categoryNameSpecial = convertToSpecialLetters(category.toUpperCase());
                menuText += `꒰͜͡ ꒰͜͡ ۫ ֢ ꩜⵿֟፝  *${categoryNameSpecial}* ꩜ׂ 𑇖ׂ𑇖\n\n`;
                
                for (const cmd of filteredCommands) {
                    const aliasText = cmd.alias.length > 0 ? ` ${config.prefix}${cmd.alias.join(` ${config.prefix}`)}` : '';
                    menuText += ` ＠꤫࣪🥥᪲𝄒ׅ𝄒﹚ᜒ ${config.prefix}${cmd.name}${aliasText}\n`;
                    menuText += `> *» ${cmd.description}*\n\n`;
                }
            }
            
            await sendWithBanner(menuText);
        }
        
        console.log(`📋 Menú mostrado a ${pushName} (${userNumber}) - Categoría: ${categoryFilter || 'todas'}`);
    }
};