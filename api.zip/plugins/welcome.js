import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const WELCOME_FILE = path.join(__dirname, '..', 'data', 'welcome.json');

// ============ WELCOME DEFAULT ============
const DEFAULT_WELCOME = 
`✿ @user

  ╭   ۪ ໋ 𝆬ฅ ฅ (ᐡ ⩌⩊⩌ ᐡ) 𝆬   𖹭ᩧ𑁀🌻̥  ֵ   ֘ ⪩⪨  ໋໋╮
          𖹭 ㅤ  𝓦𝘦𝘭𝘤𝘰𝘮𝘦ㅤ   ᗝ᳢    ::
          
      ✿ @user 𝖡𝗂𝖾𝗇𝗏𝖾𝗇𝗂𝖽𝗈 𝖺𝗅 𝗀𝗋𝗎𝗉𝗈 *(ᐢ˙꒳˙ᐢ)*
      ✐ @group  
         ︶⏝︶ ౨🩰ৎ ︶ׁ⏝︶

> ✐ Usa /help para ver mis funciones
> https://moonstaff.onrender.com/`;
// ================================================================

function loadWelcome() {
    try {
        if (fs.existsSync(WELCOME_FILE)) {
            const data = fs.readFileSync(WELCOME_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de bienvenida:', e);
    }
    return {};
}

function saveWelcome(welcome) {
    try {
        fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcome, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando mensajes de bienvenida:', e);
        return false;
    }
}

export default {
    name: 'welcome',
    alias: ['wlc'],
    description: 'Activar o desactivar el mensaje de bienvenida',
    category: 'on / off',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, isGroup, isOwner } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === msg.key.participant);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            
            if (!isAdmin && !isOwner) {
                return await replyWithContext(`❌ *Solo administradores pueden usar este comando*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`❀ Debes proporcionar *on/off*`);
            }
            
            const accion = args[0].toLowerCase();
            
            if (accion !== 'on' && accion !== 'off') {
                return await replyWithContext(`❀ Debes proporcionar *on/off*`);
            }
            
            const welcomeData = loadWelcome();
            
            if (!welcomeData[from]) {
                welcomeData[from] = {
                    message: DEFAULT_WELCOME,
                    enabled: true
                };
            }
            
            if (accion === 'on') {
                if (!welcomeData[from].message || welcomeData[from].message.trim() === '') {
                    welcomeData[from].message = DEFAULT_WELCOME;
                }
                welcomeData[from].enabled = true;
                saveWelcome(welcomeData);
                
                const bannerUrl = config.banner || '';
                const link = 'https://moonstaff.onrender.com/';
                
                let infoText = `❀ *Se ha activado la bienvenida*`;
                
                if (bannerUrl) {
                    try {
                        const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                        if (uploadMethod) {
                            const { imageMessage } = await prepareWAMessageMedia(
                                { image: { url: bannerUrl } },
                                { 
                                    upload: uploadMethod, 
                                    mediaTypeOverride: 'thumbnail-link' 
                                }
                            );
                            const linkPreview = {
                                'canonical-url': link,
                                'matched-text': link,
                                title: config.nombre || config.name || "Sirius",
                                description: `🐝 Bienvenidas activadas`,
                                jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                                highQualityThumbnail: imageMessage || undefined
                            };
                            await sock.sendMessage(from, {
                                text: infoText,
                                linkPreview: linkPreview,
                                contextInfo: {
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        } else {
                            await replyWithContext(infoText);
                        }
                    } catch (error) {
                        console.error('Error con banner en welcome:', error);
                        await replyWithContext(infoText);
                    }
                } else {
                    await replyWithContext(infoText);
                }
            } else {
                welcomeData[from].enabled = false;
                saveWelcome(welcomeData);
                
                const bannerUrl = config.banner || '';
                const link = 'https://moonstaff.onrender.com/';
                
                let infoText = `❀ *Se ha desactivado la bienvenida*`;
                
                if (bannerUrl) {
                    try {
                        const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                        if (uploadMethod) {
                            const { imageMessage } = await prepareWAMessageMedia(
                                { image: { url: bannerUrl } },
                                { 
                                    upload: uploadMethod, 
                                    mediaTypeOverride: 'thumbnail-link' 
                                }
                            );
                            const linkPreview = {
                                'canonical-url': link,
                                'matched-text': link,
                                title: config.nombre || config.name || "Sirius",
                                description: `🐝 Bienvenidas desactivadas`,
                                jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                                highQualityThumbnail: imageMessage || undefined
                            };
                            await sock.sendMessage(from, {
                                text: infoText,
                                linkPreview: linkPreview,
                                contextInfo: {
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        } else {
                            await replyWithContext(infoText);
                        }
                    } catch (error) {
                        console.error('Error con banner en welcome:', error);
                        await replyWithContext(infoText);
                    }
                } else {
                    await replyWithContext(infoText);
                }
            }
            
        } catch (error) {
            console.error('❌ Error en welcome:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};