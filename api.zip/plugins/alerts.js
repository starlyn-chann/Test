import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ALERTS_FILE = path.join(__dirname, '..', 'data', 'alerts.json');

function loadAlerts() {
    try {
        if (fs.existsSync(ALERTS_FILE)) {
            const data = fs.readFileSync(ALERTS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando alertas:', e);
    }
    return {};
}

function saveAlerts(alerts) {
    try {
        fs.writeFileSync(ALERTS_FILE, JSON.stringify(alerts, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando alertas:', e);
        return false;
    }
}

export default {
    name: 'alerts',
    alias: ['alertas'],
    description: 'Activar o desactivar las alertas de administradores',
    category: 'on / off',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, isGroup, isOwner } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === msg.key.participant);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            
            if (!isAdmin && !isOwner) {
                return await replyWithContext(`❌ *Solo administradores pueden usar este comando*`);
            }
            
            if (!args || args.length === 0) {
                const alerts = loadAlerts();
                const status = alerts[from] !== false ? '🟢 Activadas' : '🔴 Desactivadas';
                return await replyWithContext(
                    `❀ Debes proporcionar *on/off*`
                );
            }
            
            const accion = args[0].toLowerCase();
            
            if (accion !== 'on' && accion !== 'off') {
                return await replyWithContext(`❀ Debes proporcionar *on/off*`);
            }
            
            const alerts = loadAlerts();
            
            if (accion === 'on') {
                alerts[from] = true;
                saveAlerts(alerts);
                await replyWithContext(`❀ *Alertas activadas* en este grupo.`);
            } else {
                alerts[from] = false;
                saveAlerts(alerts);
                await replyWithContext(`❀ *Alertas desactivadas* en este grupo.`);
            }
            
        } catch (error) {
            console.error('❌ Error en alerts:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};