import express from 'express';
import { 
    verificarKey, 
    crearKey, 
    obtenerKeys, 
    usarKey, 
    obtenerKeyInfo,
    verificarCredenciales,
    registrarUsuario,
    usuarioExiste,
    obtenerUsuario,
    obtenerUsuarios,
    loadKeys,
    esPlanInfinito,
    normalizarKeyData,
    reiniciarUsosDiarios
} from './lib/key.js';

const app = express();
app.use(express.json());

// ============ REINICIAR USOS DIARIOS ============
// Ejecutar al iniciar
reiniciarUsosDiarios();

// ============ REGISTRAR USUARIO ============
app.post('/api/auth/register', (req, res) => {
    const { email, password, plan } = req.body;

    console.log('📝 Registrando usuario:', email);

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            error: 'Email y contraseña requeridos'
        });
    }

    try {
        if (usuarioExiste(email)) {
            return res.status(400).json({
                success: false,
                error: 'El usuario ya está registrado'
            });
        }

        const keys = obtenerKeys();
        const existingKey = keys.find(k => k.user === email);
        
        let key = existingKey ? existingKey.key : null;
        
        if (!existingKey) {
            const keyResult = crearKey(null, plan || 'free', email, password);
            
            if (!keyResult.success) {
                return res.status(500).json({
                    success: false,
                    error: keyResult.message || 'Error al crear la key'
                });
            }
            key = keyResult.key;
        } else {
            const registro = registrarUsuario(email, password, existingKey.key, existingKey.plan);
            if (!registro.success && registro.message !== 'El usuario ya está registrado') {
                console.log('⚠️ Error registrando usuario en login:', registro.message);
            }
        }

        const user = obtenerUsuario(email);

        res.json({
            success: true,
            key: key,
            email: email,
            user: user || { email, plan: plan || 'free' }
        });

    } catch (error) {
        console.error('❌ Error en registro:', error);
        res.status(500).json({
            success: false,
            error: 'Error al registrar usuario: ' + error.message
        });
    }
});

// ============ INICIAR SESION ============
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;

    console.log('🔍 Iniciando sesion:', email);

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            error: 'Email y contraseña requeridos'
        });
    }

    try {
        const verifyResult = verificarCredenciales(email, password);
        
        if (!verifyResult.success) {
            return res.status(401).json({
                success: false,
                error: verifyResult.message
            });
        }

        const keys = obtenerKeys();
        const userKey = keys.find(k => k.user === email);

        if (!userKey) {
            return res.status(404).json({
                success: false,
                error: 'Usuario no tiene key asociada'
            });
        }

        res.json({
            success: true,
            key: userKey.key,
            email: email,
            user: verifyResult.user
        });

    } catch (error) {
        console.error('❌ Error en login:', error);
        res.status(500).json({
            success: false,
            error: 'Error al iniciar sesion: ' + error.message
        });
    }
});

// ============ VERIFICAR KEY ============
app.post('/api/verify-key', (req, res) => {
    const { key } = req.body;

    if (!key) {
        return res.status(400).json({
            success: false,
            error: 'Falta la key'
        });
    }

    const result = verificarKey(key);
    
    // ===== CORREGIDO: Asegurar que remaining sea Infinity o número =====
    res.json({
        success: true,
        valid: result.valid,
        exists: result.exists,
        key: key,
        data: result.data || null,
        remaining: result.remaining || 0
    });
});

// ============ CREAR KEY ============
app.post('/api/create-key', (req, res) => {
    const { email, password, plan } = req.body;

    if (!email) {
        return res.status(400).json({
            success: false,
            error: 'Falta el email'
        });
    }

    const keys = obtenerKeys();
    const existingKey = keys.find(k => k.user === email);
    
    if (existingKey) {
        return res.status(400).json({
            success: false,
            message: 'El usuario ya tiene una key registrada',
            key: existingKey.key
        });
    }

    const result = crearKey(null, plan || 'free', email, password || null);
    res.json(result);
});

// ============ USAR KEY ============
app.post('/api/use-key', (req, res) => {
    const { key } = req.body;

    if (!key) {
        return res.status(400).json({
            success: false,
            error: 'Falta la key'
        });
    }

    const result = usarKey(key);
    
    // ===== CORREGIDO: Convertir '∞' a Infinity si viene como string =====
    if (result.success && result.remaining === '∞') {
        result.remaining = Infinity;
    }
    
    res.json(result);
});

// ============ INFO KEY ============
app.post('/api/key-info', (req, res) => {
    const { key } = req.body;

    if (!key) {
        return res.status(400).json({
            success: false,
            error: 'Falta la key'
        });
    }

    const info = obtenerKeyInfo(key);
    
    if (!info) {
        return res.json({
            success: false,
            message: 'Key no encontrada'
        });
    }

    const esInfinito = esPlanInfinito(info.plan);
    
    // ===== CORREGIDO: remaining es Infinity o número, NO string =====
    const remaining = esInfinito ? Infinity : (info.solicitudes - info.usage);

    res.json({
        success: true,
        key: info.key,
        user: info.user,
        plan: info.plan,
        solicitudes: info.solicitudes,
        usage: info.usage,
        remaining: remaining,
        created: info.created,
        lastReset: info.lastReset,
        lastUsed: info.lastUsed
    });
});

// ============ VERIFICAR USUARIO ============
app.post('/api/verify-user', (req, res) => {
    const { email, password } = req.body;

    if (!email) {
        return res.status(400).json({
            success: false,
            error: 'Falta el email'
        });
    }

    try {
        if (password) {
            const verifyResult = verificarCredenciales(email, password);
            if (!verifyResult.success) {
                return res.status(401).json({
                    success: false,
                    error: verifyResult.message
                });
            }
        }

        const keys = obtenerKeys();
        const userKey = keys.find(k => k.user === email);

        if (!userKey) {
            return res.json({
                success: false,
                message: 'Usuario no encontrado'
            });
        }

        return res.json({
            success: true,
            key: userKey.key,
            email: email
        });
    } catch (error) {
        console.error('Error verificando usuario:', error);
        return res.status(500).json({
            success: false,
            error: 'Error al verificar usuario'
        });
    }
});

// ============ LISTAR KEYS ============
app.get('/api/list-keys', (req, res) => {
    try {
        const keys = obtenerKeys();
        res.json({
            success: true,
            total: keys.length,
            keys: keys
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============ LISTAR USUARIOS LOGIN ============
app.get('/api/list-login-users', (req, res) => {
    try {
        const users = obtenerUsuarios();
        res.json({
            success: true,
            total: users.length,
            users: users.map(u => ({
                email: u.email,
                plan: u.plan,
                created: u.created,
                lastLogin: u.lastLogin
            }))
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============ REINICIAR USOS (endpoint manual) ============
app.post('/api/reset-usage', (req, res) => {
    try {
        const reiniciados = reiniciarUsosDiarios();
        res.json({
            success: true,
            message: `Usos reiniciados para ${reiniciados} keys`,
            reiniciados: reiniciados
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============ STATUS ============
app.get('/api/status', (req, res) => {
    res.json({
        success: true,
        status: 'online',
        timestamp: Date.now()
    });
});

// ============ ROOT ============
app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'Key API - Akari Bot',
        version: '2.0.0',
        endpoints: [
            'POST /api/auth/register',
            'POST /api/auth/login',
            'POST /api/verify-key',
            'POST /api/create-key',
            'POST /api/use-key',
            'POST /api/key-info',
            'POST /api/verify-user',
            'GET  /api/list-keys',
            'GET  /api/list-login-users',
            'POST /api/reset-usage',
            'GET  /api/status'
        ]
    });
});

const PORT = 8082;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🔑 Key API corriendo en http://0.0.0.0:${PORT}`);
    console.log('📡 POST /api/auth/register');
    console.log('📡 POST /api/auth/login');
    console.log('📡 POST /api/verify-key');
    console.log('📡 POST /api/create-key');
    console.log('📡 POST /api/use-key');
    console.log('📡 POST /api/key-info');
    console.log('📡 POST /api/verify-user');
    console.log('📡 GET  /api/list-keys');
    console.log('📡 GET  /api/list-login-users');
    console.log('📡 POST /api/reset-usage');
    console.log('📡 GET  /api/status');
});
