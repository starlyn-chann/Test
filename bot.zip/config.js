export default {
    nombre: 'αkαꭇꪱ',
    nombre2: 'あかり',
    prefix: '/',
    moneda: 'αkαꭇꪱcᦅꪱ𝗇𝗌',
    banner: 'https://files.catbox.moe/eojnfj.jpeg',
    icono: 'https://files.catbox.moe/nuuxxk.jpeg',
    botowner: '5219992042946',
    owner: ['5219992042946', '595993311799', '5215649067926', '51954087647'],
    version: '1.0.5',
    tipo: '𝗉ꭇꪱ𝗇cꪱ𝗉α𝗅',
    canalId: '120363410749028878@newsletter',
    canalNombre: '꒰ა ★ ໒꒱ 𝙈𝙤𝙤𝙣𝙡𝙞𝙜𝙝𝙩 (๑^◡^๑) 𖹭',
};