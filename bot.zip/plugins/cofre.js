import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getDomingoMediaNoche, getFechaUltimoDomingo } from '../lib/time.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const COFRE_FILE = path.join(__dirname, '..', 'data', 'cofre.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadCofre() {
    try {
        if (fs.existsSync(COFRE_FILE)) {
            const data = fs.readFileSync(COFRE_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando cofre:', e);
    }
    return {};
}

function saveCofre(cofre) {
    try {
        fs.writeFileSync(COFRE_FILE, JSON.stringify(cofre, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando cofre:', e);
        return false;
    }
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'cofre',
    alias: ['treasure', 'tesoro'],
    description: 'Reclama tu recompensa semanal del cofre',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const now = Date.now();
            const domingoMediaNoche = getDomingoMediaNoche();
            const ultimoDomingo = getFechaUltimoDomingo();
            
            let cofreData = loadCofre();
            if (!cofreData[userNumber]) {
                cofreData[userNumber] = {
                    semanas: 0,
                    ultimoReclamo: 0,
                    ultimoReclamoGrupo: {},
                    totalReclamado: 0
                };
            }
            
            const usuarioCofre = cofreData[userNumber];
            const ultimoReclamoGlobal = usuarioCofre.ultimoReclamo || 0;
            const ultimoReclamoGrupo = usuarioCofre.ultimoReclamoGrupo?.[from] || 0;
            let semanas = usuarioCofre.semanas || 0;
            
            if (ultimoReclamoGrupo > 0 && ultimoReclamoGrupo >= ultimoDomingo) {
                return await replyWithContext(`❀ *Ya reclamaste tu cofre en este grupo esta semana*\n> Vuelve el domingo a las 12:00 AM`);
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const RECOMPENSA_BASE = 7000000;
            const BONO_SEMANA = 1000000;
            const RECOMPENSA = RECOMPENSA_BASE + BONO_SEMANA;
            const BONO = BONO_SEMANA;
            
            let mensaje = '';
            
            // Verificar si ya reclamo esta semana en otro grupo
            if (ultimoReclamoGlobal > 0 && ultimoReclamoGlobal >= ultimoDomingo) {
                // Ya reclamo esta semana en otro grupo, solo da la recompensa sin sumar semana
                economy[from][userNumber].banco = (economy[from][userNumber].banco || 0) + RECOMPENSA;
                economy[from][userNumber].nombre = pushName || 'Usuario';
                saveEconomy(economy);
                
                if (!usuarioCofre.ultimoReclamoGrupo) {
                    usuarioCofre.ultimoReclamoGrupo = {};
                }
                usuarioCofre.ultimoReclamoGrupo[from] = now;
                saveCofre(cofreData);
                
                mensaje = `▭ֹ ▭ׅ ▭ֹ ▭ׅ ▭ׅ  ਏਓ  ▭ׅ ▭ֹ ▭ׅ ▭ֹ ▭ׅ \n\n` +
                         `𖹭ᩧ𑁀🪙̥  ֵ *Recompensa: ${formatNumber(RECOMPENSA)} ${moneda}*\n` +
                         `𖹭ᩧ𑁀💰  ֵ *Bono: +${formatNumber(BONO)} ${moneda}*\n` +
                         `> *Semana ${semanas} de recompensa* ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`;
                
                await replyWithContext(mensaje);
                return;
            }
            
            // Nueva semana - sumar semana
            if (ultimoReclamoGlobal > 0) {
                const diffDias = Math.floor((now - ultimoReclamoGlobal) / (24 * 60 * 60 * 1000));
                if (diffDias >= 7) {
                    semanas++;
                }
            } else {
                semanas = 1;
            }
            
            // Depositar en el banco
            economy[from][userNumber].banco = (economy[from][userNumber].banco || 0) + RECOMPENSA;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            usuarioCofre.semanas = semanas;
            usuarioCofre.ultimoReclamo = now;
            if (!usuarioCofre.ultimoReclamoGrupo) {
                usuarioCofre.ultimoReclamoGrupo = {};
            }
            usuarioCofre.ultimoReclamoGrupo[from] = now;
            usuarioCofre.totalReclamado = (usuarioCofre.totalReclamado || 0) + RECOMPENSA;
            saveCofre(cofreData);
            
            mensaje = `▭ֹ ▭ׅ ▭ֹ ▭ׅ ▭ׅ  ਏਓ  ▭ׅ ▭ֹ ▭ׅ ▭ֹ ▭ׅ \n\n` +
                     `𖹭ᩧ𑁀🪙̥  ֵ *Recompensa: ${formatNumber(RECOMPENSA)} ${moneda}*\n` +
                     `𖹭ᩧ𑁀💰  ֵ *Bono: +${formatNumber(BONO)} ${moneda}*\n` +
                     `> *Semana ${semanas} de recompensa* ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en cofre:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};