import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'baltop',
    alias: ['topcoins', 'rank'],
    description: 'Muestra el top de usuarios con más coins en el grupo',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, args, usersDb } = options;
            const from = msg.key.remoteJid;
            const moneda = config.moneda || '💰';
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let economy = loadEconomy();
            if (!economy[from] || Object.keys(economy[from]).length === 0) {
                return await replyWithContext(`❀ *No hay usuarios registrados en este grupo*`);
            }
            
            let pagina = 1;
            if (args && args.length > 0) {
                const num = parseInt(args[0]);
                if (!isNaN(num) && num > 0) {
                    pagina = num;
                }
            }
            
            const USUARIOS_POR_PAGINA = 10;
            
            const usuarios = [];
            for (const [userId, data] of Object.entries(economy[from])) {
                // Obtener nombre del usuario desde usersDb o desde economy
                let nombre = data.nombre || userId;
                
                // Buscar en usersDb para obtener el pushName actualizado
                if (usersDb) {
                    const userFound = usersDb.find(u => u.number === userId);
                    if (userFound && userFound.pushName) {
                        nombre = userFound.pushName;
                    }
                }
                
                const total = (data.dinero || 0) + (data.banco || 0);
                usuarios.push({
                    id: userId,
                    nombre: nombre,
                    total: total
                });
            }
            
            usuarios.sort((a, b) => b.total - a.total);
            
            const totalUsuarios = usuarios.length;
            const totalPaginas = Math.ceil(totalUsuarios / USUARIOS_POR_PAGINA);
            
            if (pagina > totalPaginas) {
                return await replyWithContext(`❀ *Página no válida*\n> Hay ${totalPaginas} páginas disponibles`);
            }
            
            const inicio = (pagina - 1) * USUARIOS_POR_PAGINA;
            const fin = Math.min(inicio + USUARIOS_POR_PAGINA, totalUsuarios);
            const usuariosPagina = usuarios.slice(inicio, fin);
            
            let mensaje = `❀ 𝗧𝗼𝗽 𝗖𝗼𝗶𝗻𝘀\n\n`;
            
            for (let i = 0; i < usuariosPagina.length; i++) {
                const user = usuariosPagina[i];
                const posicion = inicio + i + 1;
                mensaje += `♡ ${posicion} » ${user.nombre}\n`;
                mensaje += `> *${formatNumber(user.total)} ${moneda}*\n\n`;
            }
            
            mensaje += `> *Lista (${pagina}) de (${totalPaginas})*`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en baltop:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};