import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const PRESTAMO_FILE = path.join(__dirname, '..', 'data', 'prestamo.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadPrestamo() {
    try {
        if (fs.existsSync(PRESTAMO_FILE)) {
            const data = fs.readFileSync(PRESTAMO_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando préstamos:', e);
    }
    return {};
}

function savePrestamo(prestamo) {
    try {
        fs.writeFileSync(PRESTAMO_FILE, JSON.stringify(prestamo, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando préstamos:', e);
        return false;
    }
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

async function getImageBuffer(url) {
    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        return Buffer.from(response.data);
    } catch (e) {
        return null;
    }
}

export default {
    name: 'prestamo',
    alias: ['loan'],
    description: 'Pide un préstamo o paga tu préstamo',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Pedir préstamo: ${config.prefix}prestamo 500000\n> Pagar préstamo: ${config.prefix}prestamo pagar`);
            }
            
            const moneda = config.moneda || '💰';
            const now = Date.now();
            
            let prestamoData = loadPrestamo();
            if (!prestamoData[userNumber]) {
                prestamoData[userNumber] = {
                    debe: 0,
                    totalPedido: 0,
                    fechaPrestamo: 0,
                    grupoPrestamo: ''
                };
            }
            
            const usuarioPrestamo = prestamoData[userNumber];
            let debeActual = usuarioPrestamo.debe || 0;
            const fechaPrestamo = usuarioPrestamo.fechaPrestamo || 0;
            const grupoPrestamo = usuarioPrestamo.grupoPrestamo || '';
            
            // ============ VERIFICAR DEUDA Y COBRAR AUTOMÁTICAMENTE ============
            if (debeActual > 0 && fechaPrestamo > 0 && grupoPrestamo === from) {
                const tiempoSinPagar = now - fechaPrestamo;
                const horasSinPagar = tiempoSinPagar / (60 * 60 * 1000);
                
                if (horasSinPagar >= 24) {
                    let economy = loadEconomy();
                    if (!economy[from]) economy[from] = {};
                    if (!economy[from][userNumber]) {
                        economy[from][userNumber] = {
                            dinero: 0,
                            banco: 0,
                            nombre: pushName || 'Usuario'
                        };
                    }
                    
                    const dineroActual = economy[from][userNumber].dinero || 0;
                    let cobrado = 0;
                    
                    if (dineroActual >= 500) {
                        economy[from][userNumber].dinero -= 500;
                        cobrado = 500;
                    } else {
                        cobrado = dineroActual;
                        economy[from][userNumber].dinero = 0;
                    }
                    
                    usuarioPrestamo.debe -= cobrado;
                    usuarioPrestamo.fechaPrestamo = now;
                    
                    if (usuarioPrestamo.debe < 0) {
                        const excedente = Math.abs(usuarioPrestamo.debe);
                        usuarioPrestamo.debe = 0;
                        economy[from][userNumber].dinero += excedente;
                        if (usuarioPrestamo.debe === 0) {
                            usuarioPrestamo.grupoPrestamo = '';
                        }
                    }
                    
                    economy[from][userNumber].nombre = pushName || 'Usuario';
                    saveEconomy(economy);
                    savePrestamo(prestamoData);
                    
                    if (usuarioPrestamo.debe > 0) {
                        await replyWithContext(`❀ *Cobro automático*\n> Se te han cobrado ${formatNumber(cobrado)} ${moneda} por tu préstamo pendiente\n> Deuda restante: ${formatNumber(usuarioPrestamo.debe)} ${moneda}\n> Siguiente cobro en 24 horas`);
                    } else {
                        await replyWithContext(`❀ *Préstamo liquidado*\n> Se te han cobrado ${formatNumber(cobrado)} ${moneda} y has liquidado tu deuda\n> 🎉 *¡Préstamo pagado completamente!*`);
                    }
                    
                    return;
                }
            }
            
            // ============ PAGAR PRÉSTAMO COMPLETO ============
            if (args[0].toLowerCase() === 'pagar' || args[0].toLowerCase() === 'pay') {
                if (debeActual <= 0) {
                    return await replyWithContext(`❀ *No tienes ningún préstamo pendiente*`);
                }
                
                let economy = loadEconomy();
                if (!economy[from]) economy[from] = {};
                if (!economy[from][userNumber]) {
                    economy[from][userNumber] = {
                        dinero: 0,
                        banco: 0,
                        nombre: pushName || 'Usuario'
                    };
                }
                
                const dineroActual = economy[from][userNumber].dinero || 0;
                
                if (debeActual > dineroActual) {
                    return await replyWithContext(`❀ *No tienes suficiente dinero para pagar el préstamo*\n> Debes: ${formatNumber(debeActual)} ${moneda}\n> Billetera: ${formatNumber(dineroActual)} ${moneda}`);
                }
                
                const cantidadPagada = debeActual;
                economy[from][userNumber].dinero -= debeActual;
                economy[from][userNumber].nombre = pushName || 'Usuario';
                saveEconomy(economy);
                
                usuarioPrestamo.debe = 0;
                usuarioPrestamo.totalPedido = 0;
                usuarioPrestamo.fechaPrestamo = 0;
                usuarioPrestamo.grupoPrestamo = '';
                savePrestamo(prestamoData);
                
                await replyWithContext(`❀ *Préstamo pagado*\n> Has pagado ${formatNumber(cantidadPagada)} ${moneda}\n> Deuda restante: 0 ${moneda}\n\n*Billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${moneda}\n\n🎉 *¡Has liquidado tu préstamo completamente!*`);
                
                return;
            }
            
            // ============ PEDIR PRÉSTAMO ============
            if (debeActual > 0) {
                return await replyWithContext(`❀ *Ya tienes un préstamo pendiente*\n> Debes: ${formatNumber(debeActual)} ${moneda}\n> Usa ${config.prefix}prestamo pagar para liquidarlo`);
            }
            
            let cantidad = parseInt(args[0]);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await replyWithContext(`「✰」 Cantidad inválida\n> Debes ingresar un número positivo`);
            }
            
            if (cantidad < 10000) {
                return await replyWithContext(`「✰」 El préstamo mínimo es de 10,000 ${moneda}`);
            }
            
            if (cantidad > 500000) {
                return await replyWithContext(`「✰」 El préstamo máximo es de 500,000 ${moneda}`);
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            economy[from][userNumber].dinero += cantidad;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            usuarioPrestamo.debe = cantidad;
            usuarioPrestamo.totalPedido = cantidad;
            usuarioPrestamo.fechaPrestamo = now;
            usuarioPrestamo.grupoPrestamo = from;
            savePrestamo(prestamoData);
            
            // ============ ENVIAR CON IMAGEN ============
            const imageBuffer = await getImageBuffer('https://files.catbox.moe/5npuy6.jpeg');
            
            const mensaje = `❀ *Préstamo aprobado*\n> Has recibido ${formatNumber(cantidad)} ${moneda}\n> Debes pagar: ${formatNumber(cantidad)} ${moneda}\n\n*Billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${moneda}\n\n> ⏰ Tienes 24 horas para pagar\n> Usa ${config.prefix}prestamo pagar para liquidar`;
            
            if (imageBuffer) {
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: mensaje,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(mensaje);
            }
            
        } catch (error) {
            console.error('❌ Error en prestamo:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};