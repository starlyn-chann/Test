import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function saveTimers(timers) {
    try {
        fs.writeFileSync(TIMER_FILE, JSON.stringify(timers, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando timeeconomy:', e);
        return false;
    }
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function getTimerKey(userNumber) {
    return `rob_${userNumber}`;
}

export default {
    name: 'rob',
    alias: ['robar'],
    description: 'Roba coins a otro usuario',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName, senderJid, args, usersDb } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let targetUser = null;
            let targetJid = null;
            
            // ============ OBTENER USUARIO OBJETIVO ============
            let mentionedUser = null;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg) {
                const quotedParticipant = msg.message.extendedTextMessage.contextInfo.participant;
                if (quotedParticipant) {
                    mentionedUser = quotedParticipant;
                }
            }
            
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                const mentions = msg.message.extendedTextMessage.contextInfo.mentionedJid;
                if (mentions && mentions.length > 0) {
                    mentionedUser = mentions[0];
                }
            }
            
            if (!mentionedUser && args && args.length > 0) {
                const arg = args[0].replace(/@/g, '').replace(/\D/g, '');
                if (arg) {
                    mentionedUser = `${arg}@s.whatsapp.net`;
                }
            }
            
            if (!mentionedUser) {
                return await replyWithContext(`「✰」 Debes mencionar o responder al usuario que quieres robar\n> Ejemplo: ${config.prefix}rob @usuario`);
            }
            
            targetJid = mentionedUser;
            targetUser = cleanNumber(targetJid);
            
            // Verificar que no sea a sí mismo
            if (targetUser === userNumber) {
                return await replyWithContext(`❀ *No puedes robarte a ti mismo*`);
            }
            
            // ============ VERIFICAR COOLDOWN (1 hora) ============
            const timerKey = getTimerKey(userNumber);
            const now = Date.now();
            const cooldownTime = 60 * 60 * 1000; // 1 hora
            
            let timers = loadTimers();
            
            if (timers[timerKey]) {
                const lastUsed = timers[timerKey];
                const tiempoRestante = cooldownTime - (now - lastUsed);
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.floor((tiempoRestante % 60000) / 1000);
                    return await replyWithContext(`❀ *Espera un poco*\n> Puedes robar de nuevo en ${minutos}m ${segundos}s`);
                }
            }
            
            // ============ CARGAR ECONOMÍA ============
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            
            // Verificar que el objetivo existe
            if (!economy[from][targetUser]) {
                return await replyWithContext(`❀ *El usuario no tiene dinero en este grupo*`);
            }
            
            const dineroVictima = economy[from][targetUser].dinero || 0;
            
            if (dineroVictima <= 0) {
                return await replyWithContext(`❀ *El usuario no tiene dinero para robar*`);
            }
            
            // Verificar que el ladrón existe
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            // ============ CALCULAR ROBO ============
            // Probabilidad de éxito: 60%
            const exito = Math.random() < 0.6;
            
            let cantidadRobada = 0;
            let mensaje = '';
            
            if (exito) {
                // Robar entre 10% y 30% del dinero de la víctima
                const porcentaje = Math.random() * (0.30 - 0.10) + 0.10;
                cantidadRobada = Math.floor(dineroVictima * porcentaje);
                
                // Mínimo 100, máximo 100,000
                if (cantidadRobada < 100) cantidadRobada = 100;
                if (cantidadRobada > 100000) cantidadRobada = 100000;
                
                // No robar más de lo que tiene
                if (cantidadRobada > dineroVictima) cantidadRobada = dineroVictima;
                
                // Realizar robo
                economy[from][targetUser].dinero -= cantidadRobada;
                economy[from][userNumber].dinero += cantidadRobada;
                
                // Actualizar nombres
                economy[from][targetUser].nombre = economy[from][targetUser].nombre || 'Usuario';
                economy[from][userNumber].nombre = pushName || 'Usuario';
                saveEconomy(economy);
                
                mensaje = `❀ *Robo exitoso* 🔫\n> Has robado ${formatNumber(cantidadRobada)} ${config.moneda} a @${targetUser}\n\n*Tu billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${config.moneda}\n*Billetera de la víctima:* ${formatNumber(economy[from][targetUser].dinero)} ${config.moneda}`;
                
            } else {
                // Robo fallido
                // Se pierde entre 100 y 1000
                const perdida = Math.floor(Math.random() * (1000 - 100 + 1)) + 100;
                const dineroLadron = economy[from][userNumber].dinero || 0;
                
                if (dineroLadron >= perdida) {
                    economy[from][userNumber].dinero -= perdida;
                    mensaje = `❀ *Robo fallido*\n> Intentaste robar a @${targetUser} pero te atraparon\n> Has perdido ${formatNumber(perdida)} ${config.moneda}\n\n*Tu billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${config.moneda}`;
                } else {
                    // Si no tiene dinero para perder, no pierde nada
                    mensaje = `❀ *Robo fallido*\n> Intentaste robar a @${targetUser} pero no tenías dinero para perder\n> Te dejaron ir con una advertencia`;
                }
                
                economy[from][userNumber].nombre = pushName || 'Usuario';
                saveEconomy(economy);
            }
            
            // ============ GUARDAR COOLDOWN ============
            timers[timerKey] = now;
            saveTimers(timers);
            
            await replyWithContext(mensaje, [targetJid]);
            
        } catch (error) {
            console.error('❌ Error en rob:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};