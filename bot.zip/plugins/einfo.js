import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');
const RACHA_FILE = path.join(__dirname, '..', 'data', 'racha.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function loadRacha() {
    try {
        if (fs.existsSync(RACHA_FILE)) {
            const data = fs.readFileSync(RACHA_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando racha:', e);
    }
    return {};
}

function getTimerKey(userNumber, groupId, command) {
    return `${command}_${userNumber}_${groupId}`;
}

function getTimerKeyRob(userNumber) {
    return `rob_${userNumber}`;
}

function getTimerKeyDaily(userNumber, groupId) {
    return `daily_${userNumber}_${groupId}`;
}

function getTimerKeyCrimen(userNumber, groupId) {
    return `crimen_${userNumber}_${groupId}`;
}

function getCooldownTime(command) {
    const cooldowns = {
        work: 3 * 60 * 1000,
        aventura: 3 * 60 * 1000,
        chambear: 3 * 60 * 1000,
        minar: 3 * 60 * 1000,
        crimen: 5 * 60 * 1000,
        rob: 60 * 60 * 1000,
        daily: 24 * 60 * 60 * 1000
    };
    return cooldowns[command] || 0;
}

function formatTime(ms) {
    if (ms <= 0) return 'Libre';
    
    const horas = Math.floor(ms / (60 * 60 * 1000));
    const minutos = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
    const segundos = Math.floor((ms % (60 * 1000)) / 1000);
    
    if (horas > 0) {
        return `${horas}h ${minutos}m ${segundos}s`;
    } else if (minutos > 0) {
        return `${minutos}m ${segundos}s`;
    } else {
        return `${segundos}s`;
    }
}

function getRemainingTime(timers, userNumber, groupId, command) {
    let key;
    if (command === 'rob') {
        key = getTimerKeyRob(userNumber);
    } else if (command === 'daily') {
        key = getTimerKeyDaily(userNumber, groupId);
    } else if (command === 'crimen') {
        key = getTimerKeyCrimen(userNumber, groupId);
    } else {
        key = getTimerKey(userNumber, groupId, command);
    }
    
    const lastUsed = timers[key] || 0;
    const cooldown = getCooldownTime(command);
    const now = Date.now();
    const remaining = (lastUsed + cooldown) - now;
    
    if (remaining <= 0) return 'Libre';
    return formatTime(remaining);
}

export default {
    name: 'einfo',
    alias: [],
    description: 'Muestra el tiempo restante para usar comandos de economía',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { replyWithContext, isGroup, userNumber, config } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const timers = loadTimers();
            
            const workTime = getRemainingTime(timers, userNumber, from, 'work');
            const aventuraTime = getRemainingTime(timers, userNumber, from, 'aventura');
            const chambearTime = getRemainingTime(timers, userNumber, from, 'chambear');
            const minarTime = getRemainingTime(timers, userNumber, from, 'minar');
            const crimenTime = getRemainingTime(timers, userNumber, from, 'crimen');
            const robTime = getRemainingTime(timers, userNumber, from, 'rob');
            const dailyTime = getRemainingTime(timers, userNumber, from, 'daily');
            
            const mensaje = `❀ *Información de economía*

*⧖ Work :* ${workTime}
*⧖ Aventura :* ${aventuraTime}
*⧖ Chambear :* ${chambearTime}
*⧖ Minar :* ${minarTime}
*⧖ Crimen :* ${crimenTime}
*⧖ Robar :* ${robTime}
*⧖ Daily :* ${dailyTime}`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en einfo:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};