import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const RACHA_FILE = path.join(__dirname, '..', 'data', 'racha.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadRacha() {
    try {
        if (fs.existsSync(RACHA_FILE)) {
            const data = fs.readFileSync(RACHA_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando racha:', e);
    }
    return {};
}

function saveRacha(racha) {
    try {
        fs.writeFileSync(RACHA_FILE, JSON.stringify(racha, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando racha:', e);
        return false;
    }
}

function calcularRecompensa(dia) {
    let recompensa = 30000 + (dia - 1) * 10000;
    if (recompensa > 1000000) {
        recompensa = 1000000;
    }
    return recompensa;
}

function getCooldownKey(userNumber, groupId) {
    return `daily_${userNumber}_${groupId}`;
}

function getFechaDia() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export default {
    name: 'daily',
    alias: ['recompensa', 'diario'],
    description: 'Reclama tu recompensa diaria',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || 'Golosinas';
            const now = Date.now();
            const TIEMPO_ESPERA = 24 * 60 * 60 * 1000;
            const fechaActual = getFechaDia();
            
            // ============ CARGAR RACHA GLOBAL ============
            let rachaData = loadRacha();
            if (!rachaData[userNumber]) {
                rachaData[userNumber] = {
                    racha: 0,
                    ultimaFecha: null,
                    ultimoReclamoGlobal: 0
                };
            }
            
            // ============ CARGAR COOLDOWN POR GRUPO ============
            const cooldownKey = getCooldownKey(userNumber, from);
            if (!rachaData[cooldownKey]) {
                rachaData[cooldownKey] = {
                    ultimoReclamo: 0
                };
            }
            
            const usuarioRacha = rachaData[userNumber];
            const cooldownGrupo = rachaData[cooldownKey];
            const ultimoReclamoGrupo = cooldownGrupo.ultimoReclamo || 0;
            const ultimaFecha = usuarioRacha.ultimaFecha || null;
            const ultimoReclamoGlobal = usuarioRacha.ultimoReclamoGlobal || 0;
            let racha = usuarioRacha.racha || 0;
            
            // ============ VERIFICAR COOLDOWN POR GRUPO (24 HORAS) ============
            if (ultimoReclamoGrupo > 0) {
                const tiempoRestante = (ultimoReclamoGrupo + TIEMPO_ESPERA) - now;
                if (tiempoRestante > 0) {
                    const horas = Math.floor(tiempoRestante / (60 * 60 * 1000));
                    const minutos = Math.floor((tiempoRestante % (60 * 60 * 1000)) / (60 * 1000));
                    return await replyWithContext(`❀ *Ya reclamaste tu daily en este grupo*\n> Vuelve en ${horas}h ${minutos}m`);
                }
            }
            
            // ============ VERIFICAR RACHA GLOBAL ============
            // Si es la primera vez o la fecha cambió (nuevo día)
            if (ultimaFecha !== fechaActual) {
                // Verificar si pasaron más de 3 días sin reclamar
                if (ultimaFecha) {
                    const fechaAnterior = new Date(ultimaFecha);
                    const fechaActualObj = new Date(fechaActual);
                    const diffDias = Math.floor((fechaActualObj - fechaAnterior) / (24 * 60 * 60 * 1000));
                    
                    if (diffDias > 3) {
                        racha = 0;
                    } else if (diffDias === 1) {
                        // Si es el día siguiente, sumar racha
                        racha++;
                    } else if (diffDias > 1) {
                        // Si pasaron más de 1 día pero menos de 3, resetear racha
                        racha = 0;
                    }
                } else {
                    // Primera vez, racha = 1
                    racha = 1;
                }
            } else {
                // Ya reclamo hoy en otro grupo, no sumar racha
                // La racha se mantiene igual
            }
            
            // ============ GUARDAR RACHA ============
            usuarioRacha.racha = racha;
            usuarioRacha.ultimaFecha = fechaActual;
            usuarioRacha.ultimoReclamoGlobal = now;
            
            // ============ GUARDAR COOLDOWN POR GRUPO ============
            cooldownGrupo.ultimoReclamo = now;
            
            saveRacha(rachaData);
            
            // ============ DAR RECOMPENSA ============
            const recompensa = calcularRecompensa(racha);
            const siguienteRecompensa = calcularRecompensa(racha + 1);
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            economy[from][userNumber].dinero += recompensa;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            let mensaje = `「✿」Has reclamado tu recompensa diaria de *${recompensa.toLocaleString()} ${moneda}*! (Día *${racha}*)\n`;
            mensaje += `> Día *${racha + 1}* » *+${siguienteRecompensa.toLocaleString()}*\n`;
            mensaje += `> _¡Sigue reclamando seguido para aumentar tu daily!_\n\n`;
            mensaje += `*Billetera:* ${economy[from][userNumber].dinero.toLocaleString()} ${moneda}`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en daily:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};