import { obtenerTodosPersonajes } from '../lib/gacha.js';

export default {
    name: 'waifusboard',
    alias: ['waifustop', 'topwaifus', 'wtop', 'top', 'topvalor'],
    description: 'Ver el top de personajes con mayor valor',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando waifusboard...');
            
            const { config, replyWithContext, args, userNumber } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // ============ OBTENER TODOS LOS PERSONAJES ============
            const todosPersonajes = await obtenerTodosPersonajes();
            
            if (!todosPersonajes || todosPersonajes.length === 0) {
                return await replyWithContext(`❀ No hay personajes en la base de datos\n> Agrega personajes con ${config.prefix}addpj`);
            }
            
            // ============ ORDENAR POR VALOR (MAYOR A MENOR) ============
            const sorted = todosPersonajes.sort((a, b) => (b.valor || 0) - (a.valor || 0));
            
            // ============ PAGINACIÓN ============
            const page = parseInt(args[0]) || 1;
            const perPage = 10;
            const totalPages = Math.max(1, Math.ceil(sorted.length / perPage));
            
            if (page < 1 || page > totalPages) {
                return await replyWithContext(`❀ Página no válida. Hay un total de *${totalPages}* páginas.`);
            }
            
            const start = (page - 1) * perPage;
            const end = Math.min(start + perPage, sorted.length);
            const sliced = sorted.slice(start, end);
            // ================================================================
            
            // ============ CREAR MENSAJE ============
            let mensaje = '❀ *Personajes con más valor:*\n\n';
            
            for (let i = 0; i < sliced.length; i++) {
                const char = sliced[i];
                const posicion = start + i + 1;
                const valor = char.valor || 0;
                mensaje += `✰ ${posicion} » *${char.nombre}*\n`;
                mensaje += `   → Valor: *${valor.toLocaleString()}*\n`;
            }
            
            mensaje += `\n⌦ Página *${page}* de *${totalPages}*`;
            
            if (page < totalPages) {
                mensaje += `\n> Para ver la siguiente página › *${config.prefix}wtop ${page + 1}*`;
            }
            // ================================================================
            
            await replyWithContext(mensaje);
            
            console.log(`✅ waifusboard ejecutado: página ${page}/${totalPages}`);
            
        } catch (error) {
            console.error('❌ Error en waifusboard:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};