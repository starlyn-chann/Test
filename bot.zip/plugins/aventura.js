import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function saveTimers(timers) {
    try {
        fs.writeFileSync(TIMER_FILE, JSON.stringify(timers, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando timeeconomy:', e);
        return false;
    }
}

function getTimerKey(userNumber, groupId) {
    return `aventura_${userNumber}_${groupId}`;
}

export default {
    name: 'aventura',
    alias: ['av', 'adventure'],
    description: 'Ve de aventura y gana o pierde dinero',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const timerKey = getTimerKey(userNumber, from);
            const now = Date.now();
            const cooldownTime = 3 * 60 * 1000;
            
            let timers = loadTimers();
            
            if (timers[timerKey]) {
                const lastUsed = timers[timerKey];
                const tiempoRestante = cooldownTime - (now - lastUsed);
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.floor((tiempoRestante % 60000) / 1000);
                    return await replyWithContext(`❀ *Espera un poco*\n> Puedes ir de aventura de nuevo en ${minutos}m ${segundos}s`);
                }
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const esGanancia = Math.random() < 0.7;
            
            let cantidad = 0;
            let aventura = '';
            let resultado = '';
            
            const aventurasGanar = [
                'Encontraste un tesoro escondido en una cueva 🏴‍☠️',
                'Un comerciante te regaló una bolsa de monedas 💰',
                'Ganaste una apuesta en el casino 🎲',
                'Recibiste una herencia de un familiar lejano 📜',
                'Encontraste una cartera con dinero en la calle 💼',
                'Te dieron una propina generosa en el trabajo 💵',
                'Ganaste el premio mayor de la lotería 🎰',
                'Un desconocido te recompensó por tu ayuda 🤝',
                'Encontraste un cofre del tesoro enterrado 📦',
                'Te pagaron por resolver un misterio 🔍',
                'Descubriste una mina de oro ⛏️',
                'Te robaron... pero al ladrón le fue mal y recuperaste el doble 😂',
                'Ganaste un concurso de talentos 🎭',
                'Te encontraste un billete de alta denominación 💶',
                'Un banco te dio intereses por error 📈'
            ];
            
            const aventurasPerder = [
                'Te robaron en un callejón oscuro 🦹',
                'Perdiste una apuesta en el póker 🎲',
                'Tuviste un accidente y pagaste reparaciones 🚗',
                'Te estafaron con una inversión falsa 💸',
                'Se te cayó el dinero y se lo llevó el viento 💨',
                'Pagaste una multa por exceso de velocidad 👮',
                'Te enfermaste y tuviste que pagar médico 🏥',
                'Te robaron la cartera en el transporte público 👝',
                'Perdiste dinero en la bolsa de valores 📉',
                'Te cobraron de más por un servicio técnico 💳',
                'Se te quemó la casa y perdiste tus ahorros 🔥',
                'Te estafaron con una compra por internet 📦',
                'Perdiste tu teléfono y tuviste que comprar otro 📱',
                'Te robaron la bicicleta 🚲',
                'Tuviste que pagar una fianza ⚖️'
            ];
            
            if (esGanancia) {
                cantidad = Math.floor(Math.random() * (5000 - 50 + 1)) + 50;
                economy[from][userNumber].dinero += cantidad;
                aventura = aventurasGanar[Math.floor(Math.random() * aventurasGanar.length)];
                resultado = `★ *Ganaste* ${cantidad} ${config.moneda}`;
            } else {
                cantidad = Math.floor(Math.random() * (2000 - 10 + 1)) + 10;
                if (economy[from][userNumber].dinero < cantidad) {
                    cantidad = economy[from][userNumber].dinero;
                    economy[from][userNumber].dinero = 0;
                } else {
                    economy[from][userNumber].dinero -= cantidad;
                }
                aventura = aventurasPerder[Math.floor(Math.random() * aventurasPerder.length)];
                resultado = `★ *Perdiste* ${cantidad} ${config.moneda}`;
            }
            
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            timers[timerKey] = now;
            saveTimers(timers);
            
            await replyWithContext(`❀ *Aventura*\n> ${aventura}\n> ${resultado}`);
            
        } catch (error) {
            console.error('❌ Error en aventura:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};