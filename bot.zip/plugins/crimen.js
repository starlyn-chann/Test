import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function saveTimers(timers) {
    try {
        fs.writeFileSync(TIMER_FILE, JSON.stringify(timers, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando timeeconomy:', e);
        return false;
    }
}

function getTimerKey(userNumber, groupId) {
    return `crimen_${userNumber}_${groupId}`;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'crimen',
    alias: ['crime'],
    description: 'Comete un crimen y gana o pierde dinero',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            
            const timerKey = getTimerKey(userNumber, from);
            const now = Date.now();
            const cooldownTime = 5 * 60 * 1000; // 5 minutos
            
            let timers = loadTimers();
            
            if (timers[timerKey]) {
                const lastUsed = timers[timerKey];
                const tiempoRestante = cooldownTime - (now - lastUsed);
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.floor((tiempoRestante % 60000) / 1000);
                    return await replyWithContext(`❀ *Espera un poco*\n> Puedes cometer otro crimen en ${minutos}m ${segundos}s`);
                }
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            // 60% éxito, 40% fracaso
            const exito = Math.random() < 0.6;
            
            let cantidad = 0;
            let mensaje = '';
            let crimen = '';
            
            const crimenesExito = [
                'Robaste un banco 🏦',
                'Asaltaste una joyería 💎',
                'Hiciste un robo a mano armada 🔫',
                'Estafaste a un millonario 🎭',
                'Robaste un vehículo de lujo 🚗',
                'Atracaste un camión de valores 🚚',
                'Hiciste un secuestro express 🎯',
                'Robaste una casa de empeño 🏪',
                'Asaltaste un casino 🎰',
                'Hiciste un fraude bancario 💳',
                'Robaste un cargamento de oro 🪙',
                'Atracaste una tienda de electrónicos 📱',
                'Robaste una colección de arte 🖼️',
                'Hiciste un golpe en un hotel 🏨',
                'Robaste un banco de sangre 🩸'
            ];
            
            const crimenesFracaso = [
                'Intentaste robar un banco pero te atraparon 🚔',
                'Fallaste en un asalto y te hirieron 🏥',
                'Te descubrieron en una estafa ⚖️',
                'La policía te atrapó en el robo 👮',
                'Tu plan de secuestro salió mal 😅',
                'Te delataron en el atraco 🔍',
                'Fallaste en el golpe y perdiste dinero 💸',
                'Te atraparon robando una joyería 📸',
                'El sistema de seguridad te detectó 🛡️',
                'Tu cómplice te traicionó 🤝'
            ];
            
            if (exito) {
                cantidad = Math.floor(Math.random() * (15000 - 5000 + 1)) + 5000;
                economy[from][userNumber].dinero += cantidad;
                crimen = crimenesExito[Math.floor(Math.random() * crimenesExito.length)];
                mensaje = `❀ *Crimen exitoso* 😈\n> ${crimen}\n> *Ganaste* ${formatNumber(cantidad)} ${moneda}`;
            } else {
                cantidad = Math.floor(Math.random() * (3000 - 500 + 1)) + 500;
                const dineroActual = economy[from][userNumber].dinero || 0;
                
                if (dineroActual >= cantidad) {
                    economy[from][userNumber].dinero -= cantidad;
                } else {
                    cantidad = dineroActual;
                    economy[from][userNumber].dinero = 0;
                }
                
                crimen = crimenesFracaso[Math.floor(Math.random() * crimenesFracaso.length)];
                mensaje = `❀ *Crimen fallido* 😅\n> ${crimen}\n> *Perdiste* ${formatNumber(cantidad)} ${moneda}`;
            }
            
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            timers[timerKey] = now;
            saveTimers(timers);
            
            await replyWithContext(`${mensaje}\n\n*Billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en crimen:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};