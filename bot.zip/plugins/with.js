import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

export default {
    name: 'with',
    alias: ['retirar'],
    description: 'Retira dinero del banco',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Debes especificar una cantidad\n> Ejemplo: ${config.prefix}with 1000\n> ${config.prefix}with all`);
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const bancoActual = economy[from][userNumber].banco || 0;
            
            let cantidad = 0;
            if (args[0].toLowerCase() === 'all') {
                cantidad = bancoActual;
            } else {
                cantidad = parseInt(args[0]);
                if (isNaN(cantidad) || cantidad <= 0) {
                    return await replyWithContext(`「✰」 Cantidad inválida\n> Debes ingresar un número positivo`);
                }
            }
            
            if (cantidad === 0) {
                return await replyWithContext(`❀ *No tienes dinero en el banco para retirar*`);
            }
            
            if (cantidad > bancoActual) {
                return await replyWithContext(`❀ *No tienes suficiente dinero en el banco*\n> Banco: ${bancoActual} ${config.moneda}`);
            }
            
            economy[from][userNumber].banco -= cantidad;
            economy[from][userNumber].dinero = (economy[from][userNumber].dinero || 0) + cantidad;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            await replyWithContext(`❀ *Retiro exitoso*\n> Has retirado ${cantidad} ${config.moneda} del banco\n\n*Billetera:* ${economy[from][userNumber].dinero} ${config.moneda}\n*Banco:* ${economy[from][userNumber].banco} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en with:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};