export default {
    name: 'pfp',
    alias: ['getpic', 'fotoperfil'],
    description: 'Obtiene la foto de perfil de un usuario',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, pushName, userNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Función para limpiar número
            function cleanNumber(num) {
                return num.toString().replace(/\D/g, '');
            }
            
            // Función para obtener número limpio del JID
            function getNumberFromJid(jid) {
                if (!jid) return '';
                return jid.split(':')[0].split('@')[0].replace(/\D/g, '');
            }
            
            // Obtener usuario objetivo
            let targetJid = null;
            let targetNumber = null;
            
            // Opción 1: Verificar si hay un número en los argumentos
            if (args && args.length > 0) {
                const possibleNumber = cleanNumber(args[0]);
                if (possibleNumber && possibleNumber.length >= 8) {
                    targetNumber = possibleNumber;
                    targetJid = `${targetNumber}@s.whatsapp.net`;
                }
            }
            
            // Opción 2: Verificar si hay mención
            if (!targetJid) {
                const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
                if (mentionedJid && mentionedJid.length > 0) {
                    targetJid = mentionedJid[0];
                    targetNumber = getNumberFromJid(targetJid);
                }
            }
            
            // Opción 3: Verificar si hay mensaje citado
            if (!targetJid) {
                const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                if (quotedMsg) {
                    targetJid = msg.message.extendedTextMessage.contextInfo.participant;
                    targetNumber = getNumberFromJid(targetJid);
                }
            }
            
            // Opción 4: Usar el propio usuario
            if (!targetJid) {
                targetJid = senderJid;
                targetNumber = getNumberFromJid(targetJid);
            }
            
            try {
                // Obtener foto de perfil
                const imgUrl = await sock.profilePictureUrl(targetJid, 'image');
                
                // Descargar la imagen
                const { default: axios } = await import('axios');
                const imgResponse = await axios.get(imgUrl, { responseType: 'arraybuffer' });
                const imgBuffer = Buffer.from(imgResponse.data);
                
                // Enviar la foto sin caption
                await sock.sendMessage(from, {
                    image: imgBuffer,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
            } catch (error) {
                // Manejar errores específicos
                if (error.message?.includes('404') || error.status === 404 || error.message?.includes('item-not-found')) {
                    await replyWithContext(`《✧》 No se pudo obtener la foto de perfil`);
                } else if (error.message?.includes('not-authorized')) {
                    await replyWithContext(`《✧》 No se pudo obtener la foto de perfil`);
                } else {
                    throw error;
                }
            }
            
            console.log(`🖼️ Foto de perfil obtenida por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en pfp:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};