import db from '#db';

export default {
    name: 'delpasatiempo',
    alias: ['delhobby', 'deletepasatiempo'],
    description: 'Elimina tu pasatiempo',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        
        if (!user?.pasatiempo) {
            return await replyWithContext(`✐ *No tienes un pasatiempo establecido para eliminar.*`);
        }
        
        await db.updateUser(userNumber, 'pasatiempo', null);
        return await replyWithContext(`✐ *Tu pasatiempo ha sido eliminado correctamente.*`);
    }
};