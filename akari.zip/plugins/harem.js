import { obtenerPersonajesReclamados, obtenerPersonajePorId } from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

export default {
    name: 'harem',
    alias: [],
    description: 'Ver tus personajes reclamados en el grupo',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando harem...');
            
            const { config, replyWithContext, userNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // ============ DETERMINAR EL USUARIO TARGET ============
            let targetNumber = userNumber;
            let targetName = pushName;
            let targetJid = senderJid;
            let isOther = false;
            
            // Verificar si hay mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (mentionedJid) {
                const cleanMention = cleanNumber(mentionedJid);
                if (cleanMention) {
                    targetNumber = cleanMention;
                    targetJid = mentionedJid;
                    isOther = true;
                    
                    const usersDb = loadUsersDb();
                    const user = usersDb.find(u => u.number === targetNumber);
                    targetName = user ? user.pushName : targetNumber;
                }
            } else if (args && args.length > 0) {
                const possibleNumber = cleanNumber(args[0]);
                if (possibleNumber && possibleNumber.length > 8) {
                    targetNumber = possibleNumber;
                    targetJid = `${possibleNumber}@s.whatsapp.net`;
                    isOther = true;
                    
                    const usersDb = loadUsersDb();
                    const user = usersDb.find(u => u.number === targetNumber);
                    targetName = user ? user.pushName : targetNumber;
                }
            }
            
            // Verificar si el mensaje es respuesta a otro mensaje
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!isOther && quotedMsg && quotedMessage) {
                const quotedParticipant = quotedMsg?.participant || quotedMsg?.remoteJid;
                if (quotedParticipant) {
                    const cleanQuoted = cleanNumber(quotedParticipant);
                    if (cleanQuoted && cleanQuoted !== userNumber) {
                        targetNumber = cleanQuoted;
                        targetJid = quotedParticipant;
                        isOther = true;
                        
                        const usersDb = loadUsersDb();
                        const user = usersDb.find(u => u.number === targetNumber);
                        targetName = user ? user.pushName : targetNumber;
                    }
                }
            }
            // ================================================================
            
            // ============ OBTENER RECLAMOS DEL USUARIO ============
            const reclamos = await obtenerPersonajesReclamados(from, targetNumber);
            
            if (!reclamos || reclamos.length === 0) {
                if (isOther) {
                    return await replyWithContext(`ꕤ ${targetName} aún no tiene personajes reclamados`);
                }
                return await replyWithContext(`ꕤ Aún no tienes personajes reclamados\n> Usa ${config.prefix}rw para obtener uno`);
            }
            
            // Obtener información de cada personaje reclamado
            const personajesInfo = [];
            for (const reclamo of reclamos) {
                const personaje = await obtenerPersonajePorId(reclamo.personajeId);
                if (personaje) {
                    personajesInfo.push(personaje);
                }
            }
            
            if (personajesInfo.length === 0) {
                return await replyWithContext(`ꕤ No se encontró información de los personajes reclamados`);
            }
            
            // ============ ORDENAR POR VALOR (MAYOR A MENOR) ============
            personajesInfo.sort((a, b) => b.valor - a.valor);
            // ================================================================
            
            // ============ CREAR MENSAJE ============
            let mensaje = `𑊐✿︪︩፝🕸️ ᩖ᪲ׄ *Usuario › ${targetName}*\n`;
            mensaje += `𑊐✿︪︩፝🕸️ ᩖ᪲ׄ *Total › ${personajesInfo.length}*\n\n`;
            mensaje += `⌢⌢⌢⌢⌢୨୧⌢⌢ ⌢⌢⌢\n`;
            mensaje += `*✦.˚ Harem:*\n\n`;
            
            // Cada personaje en su propia línea con el formato solicitado
            for (const pj of personajesInfo) {
                mensaje += `𖹭.ᐟ ${pj.nombre} *(${pj.valor})*\n\n`;
            }
            // ================================================================
            
            // ============ OBTENER FOTO DE PERFIL ============
            let profilePicUrl = null;
            
            try {
                const ppUrl = await sock.profilePictureUrl(targetJid, 'image');
                if (ppUrl) {
                    profilePicUrl = ppUrl;
                    console.log(`✅ Foto de perfil obtenida para ${targetNumber}`);
                }
            } catch (e) {
                console.log(`⚠️ No se pudo obtener foto de perfil para ${targetNumber}: ${e.message}`);
            }
            // ================================================================
            
            // ============ ENVIAR MENSAJE CON FOTO ============
            if (profilePicUrl) {
                await sock.sendMessage(from, {
                    image: { url: profilePicUrl },
                    caption: mensaje,
                    contextInfo: {
                        mentionedJid: isOther ? [targetJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(mensaje, isOther ? [targetJid] : []);
            }
            // ================================================================
            
            console.log(`✅ harem ejecutado para ${targetName} (${personajesInfo.length} personajes)`);
            
        } catch (error) {
            console.error('❌ Error en harem:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};