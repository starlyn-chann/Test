import { obtenerPacksUsuario, actualizarPack } from '../lib/mongoose.js';

export default {
    name: 'renamepack',
    alias: ['setpackname', 'renombrarpack'],
    description: 'Renombra un pack de stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid } = options;
            
            const args = options.args || [];
            
            if (args.length < 3) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre actual y el nuevo nombre separados por un "/"\n> Ejemplo: ${config.prefix}renamepack Mis Stickers / Nuevo Nombre`);
            }
            
            const fullText = args.join(' ');
            const separatorIndex = fullText.indexOf(' / ');
            
            if (separatorIndex === -1) {
                return await replyWithContext(`「✰」Formato incorrecto\n> Usa "/" para separar el nombre actual del nuevo nombre\n> Ejemplo: ${config.prefix}renamepack Mis Stickers / Nuevo Nombre`);
            }
            
            const oldName = fullText.substring(0, separatorIndex).trim();
            const newName = fullText.substring(separatorIndex + 3).trim();
            
            if (!oldName || !newName) {
                return await replyWithContext(`「✰」Nombre inválido\n> Ejemplo: ${config.prefix}renamepack Mis Stickers / Nuevo Nombre`);
            }
            
            if (newName.length < 1 || newName.length > 64) {
                return await replyWithContext(`「✰」El nuevo nombre debe tener entre 1 y 64 caracteres`);
            }
            
            // Obtener packs del usuario desde MongoDB
            const packs = await obtenerPacksUsuario(userNumber);
            
            if (!packs || packs.length === 0) {
                return await replyWithContext(`「✰」No tienes ningún pack creado\n> Usa ${config.prefix}packlist para ver tus packs`);
            }
            
            const packExists = packs.find(p => p.name.toLowerCase() === oldName.toLowerCase());
            
            if (!packExists) {
                return await replyWithContext(`「✰」No tienes un pack llamado "${oldName}"\n> Usa ${config.prefix}packlist para ver tus packs`);
            }
            
            // Verificar si ya existe un pack con el nuevo nombre
            const existingPack = packs.find(p => p.name.toLowerCase() === newName.toLowerCase());
            
            if (existingPack) {
                return await replyWithContext(`《✧》Ya tienes un pack llamado "${newName}"\n> Usa otro nombre o elimina el existente con ${config.prefix}delpack ${newName}`);
            }
            
            // Actualizar nombre del pack en MongoDB
            const resultado = await actualizarPack(userNumber, oldName, { name: newName });
            
            if (!resultado) {
                return await replyWithContext(`❌ Error al renombrar el pack. Por favor, intenta nuevamente.`);
            }
            
            await replyWithContext(`《✧》Pack renombrado exitosamente\n> Antiguo: ${oldName}\n> Nuevo: ${newName}`);
            
        } catch (error) {
            console.error('❌ Error en renamepack:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};