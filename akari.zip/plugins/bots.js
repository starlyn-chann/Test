import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function getMainBotNumber() {
    try {
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const number = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                return number;
            }
        }
    } catch (err) {}
    return null;
}

function getMainBotName() {
    try {
        const configPath = path.join(process.cwd(), 'config.js');
        if (fs.existsSync(configPath)) {
            const content = fs.readFileSync(configPath, 'utf8');
            const match = content.match(/nombre:\s*['"]([^'"]+)['"]/);
            if (match) return match[1];
            const match2 = content.match(/name:\s*['"]([^'"]+)['"]/);
            if (match2) return match2[1];
        }
    } catch (err) {}
    return 'Principal';
}

function loadConfigSync(botNumber) {
    try {
        const configPath = path.join(process.cwd(), 'subs', botNumber, 'config.js');
        if (fs.existsSync(configPath)) {
            const content = fs.readFileSync(configPath, 'utf8');
            const match = content.match(/export default\s+({[\s\S]*})/);
            if (match && match[1]) {
                return eval('(' + match[1] + ')');
            }
        }
    } catch (err) {
        console.log(`Error leyendo config de ${botNumber}:`, err.message);
    }
    return null;
}

async function getBuffer(url) {
    const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 15000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });
    return Buffer.from(response.data);
}

async function getIconBuffer(config, isSubBot = false, subNumber = '') {
    try {
        let iconUrl = config.icono || config.icon || '';
        
        if (!iconUrl && isSubBot && subNumber) {
            const subConfig = loadConfigSync(subNumber);
            if (subConfig && (subConfig.icono || subConfig.icon)) {
                iconUrl = subConfig.icono || subConfig.icon;
            }
        }
        
        if (iconUrl) {
            return await getBuffer(iconUrl);
        }
        
        return null;
    } catch (err) {
        console.log('Error obteniendo icono:', err.message);
        return null;
    }
}

export default {
    name: 'bots',
    alias: ['sockets'],
    description: 'Muestra los bots conectados',
    category: 'main',
    
    async execute(sock, msg, options) {
        try {
            const { config, isSubBot, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const esSubBot = sock.isSubBot === true;
            const subNumber = sock.subNumber || '';
            
            const mainBotNumber = getMainBotNumber();
            const mainBotName = getMainBotName();
            
            // ============ OBTENER TODOS LOS BOTS DE LA CARPETA SUBS ============
            const allBotsInfo = [];
            
            try {
                const subsDir = path.join(process.cwd(), 'subs');
                if (fs.existsSync(subsDir)) {
                    const folders = fs.readdirSync(subsDir).filter(folder => {
                        const folderPath = path.join(subsDir, folder);
                        return fs.statSync(folderPath).isDirectory() && /^\d+$/.test(folder);
                    });
                    
                    for (const folder of folders) {
                        const botConfig = loadConfigSync(folder);
                        if (botConfig) {
                            // Determinar tipo por las propiedades del config
                            let tipo = 'Bot';
                            if (botConfig.premium === true) {
                                tipo = 'Premium';
                            } else if (botConfig.subBot === true) {
                                tipo = 'Sub';
                            }
                            
                            allBotsInfo.push({
                                number: folder,
                                name: botConfig.nombre || botConfig.name || 'Bot',
                                prefix: botConfig.prefix || '.',
                                type: tipo,
                                premium: botConfig.premium === true,
                                subBot: botConfig.subBot === true
                            });
                        } else {
                            // Si no se pudo cargar config, verificar si tiene sesión
                            const sessionsPath = path.join(process.cwd(), 'Sessions', 'Subs', folder);
                            const premsPath = path.join(process.cwd(), 'Sessions', 'prems', folder);
                            
                            let tipo = 'Bot';
                            if (fs.existsSync(premsPath) && fs.existsSync(path.join(premsPath, 'creds.json'))) {
                                tipo = 'Premium';
                            } else if (fs.existsSync(sessionsPath) && fs.existsSync(path.join(sessionsPath, 'creds.json'))) {
                                tipo = 'Sub';
                            }
                            
                            allBotsInfo.push({
                                number: folder,
                                name: 'Bot',
                                prefix: '.',
                                type: tipo,
                                premium: tipo === 'Premium',
                                subBot: tipo === 'Sub'
                            });
                        }
                    }
                }
            } catch (e) {
                console.log('Error obteniendo bots:', e.message);
            }
            
            // Separar premiums y subs
            const premiumBotsInfo = allBotsInfo.filter(b => b.premium === true);
            const subBotsInfo = allBotsInfo.filter(b => b.subBot === true);
            const totalPremiums = premiumBotsInfo.length;
            const totalSubs = subBotsInfo.length;
            // ============================================================
            
            const totalSessions = totalPremiums + totalSubs + 1;
            const link = config.link || 'https://hoshistars.vercel.app/';
            let botsInGroup = [];
            
            if (from.endsWith('@g.us')) {
                try {
                    const groupMetadata = await sock.groupMetadata(from);
                    const participants = groupMetadata.participants;
                    
                    if (mainBotNumber) {
                        const mainBotJid = `${mainBotNumber}@s.whatsapp.net`;
                        if (participants.some(p => p.id === mainBotJid || p.id === mainBotNumber)) {
                            botsInGroup.push({
                                number: mainBotNumber,
                                name: mainBotName,
                                type: 'Principal',
                                jid: mainBotJid
                            });
                        }
                    }
                    
                    // Todos los bots en el grupo
                    for (const bot of allBotsInfo) {
                        const botJid = `${bot.number}@s.whatsapp.net`;
                        if (participants.some(p => p.id === botJid || p.id === bot.number)) {
                            botsInGroup.push({
                                number: bot.number,
                                name: bot.name,
                                type: bot.type,
                                jid: botJid
                            });
                        }
                    }
                } catch (err) {
                    console.log('Error obteniendo metadata del grupo:', err.message);
                }
            }
            
            let text = ` ᰱ꫶᮫ ⠾᷼͝★ Total: ${totalSessions} sesiones\n\n`;
            text += `🍰ᩚ̷᳟ ▢֟ Principal: 1 sesión\n`;
            if (totalPremiums > 0) {
                text += `🍰ᩚ̷᳟ ▢֟ Premiums: ${totalPremiums} sesiones\n`;
            }
            text += `🍰ᩚ̷᳟ ▢֟ Subs: ${totalSubs} sesiones\n`;
            text += `> Stars » ${link}\n\n`;
            
            if (from.endsWith('@g.us')) {
                text += ` ݃  Ი᷼ᰍ *ᧉ𝗇 ᧉ𝗌ƚᧉ gꭇ𝗎𝗉ᦅ* (${botsInGroup.length})\n\n`;
                
                if (botsInGroup.length > 0) {
                    for (const bot of botsInGroup) {
                        text += `🍪〪꤬〫֟𖹭𑂳ׄ ${bot.type} - ${bot.name} » @${bot.number}\n`;
                    }
                } else {
                    text += `✿ ⪩꯭͡ີ⪨ີ No hay bots en este grupo\n`;
                }
            } else {
                text += ` ݃  Ი᷼ᰍ Bots disponibles\n\n`;
                if (mainBotNumber) {
                    text += `🍪〪꤬〫֟𖹭𑂳ׄ Principal - ${mainBotName} » @${mainBotNumber}\n`;
                }
                for (const bot of allBotsInfo) {
                    text += `🍪〪꤬〫֟𖹭𑂳ׄ ${bot.type} - ${bot.name} » @${bot.number}\n`;
                }
            }
            
            const mentions = botsInGroup.map(bot => bot.jid);
            const previewUrl = link;
            const botName = config.nombre || config.name || 'Sirius';
            
            const iconBuffer = await getIconBuffer(config, esSubBot, subNumber);
            
            const body = text.trim();
            
            if (iconBuffer) {
                try {
                    await sock.sendMessage(from, {
                        text: body,
                        linkPreview: {
                            'matched-text': previewUrl,
                            title: `Bots - ${botName}`,
                            description: `Total: ${totalSessions} sesiones`,
                            jpegThumbnail: iconBuffer
                        },
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: '0',
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                } catch (error) {
                    console.error('Error con link preview:', error);
                    await sock.sendMessage(from, {
                        text: body,
                        mentions: mentions,
                        contextInfo: {
                            mentionedJid: mentions,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: '0',
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            } else {
                await sock.sendMessage(from, {
                    text: body,
                    mentions: mentions,
                    contextInfo: {
                        mentionedJid: mentions,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: '0',
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            console.log(`📊 Bots info mostrado a ${options.pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en bots:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};