import count from '#count';

export default {
    name: 'count',
    alias: ['mensajes', 'messages', 'msgcount'],
    description: 'Obtener el conteo de mensajes de un usuario.',
    category: 'group',
    
    async execute(sock, msg, { args, config, replyWithContext, userNumber, senderJid, isGroup }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Obtener usuario objetivo
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            let who = mentionedJid?.[0] || msg.quoted?.sender || senderJid;
            let whoClean = who?.split('@')[0] || userNumber;
            
            // Obtener estadísticas del usuario
            const userStats = await count.getUserStats(from, whoClean);
            
            if (!userStats) {
                return await replyWithContext(`「✎」 El usuario mencionado no está registrado en el bot.`);
            }
            
            const daysArg = parseInt(args[0]) || 30;
            const { totalMsgs, totalCmds, daysData } = count.calculateStats(userStats.stats || {}, daysArg);
            
            let report = `❀ Contador de mensajes de @${whoClean}\n`;
            report += `> Total en los últimos *${daysArg}* días: \`${count.formatNumber(totalMsgs)}\` mensajes\n\n`;
            
            // Mostrar solo los últimos 10 días
            const displayDays = daysData.slice(0, 10);
            for (const [date, d] of displayDays) {
                const fecha = count.formatDate(date);
                report += `*❏ ${fecha}*\n`;
                report += `\t» Mensajes: \`${count.formatNumber(d.msgs || 0)}\`, Comandos: \`${count.formatNumber(d.cmds || 0)}\`\n`;
            }
            
            if (daysData.length > 10) {
                report += `\n> *Mostrando los últimos 10 días de ${daysData.length} totales*`;
            }
            
            await replyWithContext(report, [who]);
            
        } catch (error) {
            console.error('❌ Error en count:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};