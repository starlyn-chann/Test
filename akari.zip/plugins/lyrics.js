import axios from 'axios';
import path from 'path';
import fs from 'fs';

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'lyrics',
    alias: ['letra'],
    description: 'Busca la letra de una canción',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, pushName, userNumber, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir el nombre de una canción\n> Ejemplo: ${config.prefix}lyrics Bugambilia`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📝', key: msg.key } });
            } catch (e) {}
            
            const apiUrl = `https://fare.ink/search/lyrics?q=${encodeURIComponent(query)}`;
            
            const response = await axios.get(apiUrl, {
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            });
            
            if (!response.data?.status) {
                return await replyWithContext(`《✧》No se encontraron letras para "${query}"`);
            }
            
            const data = response.data;
            const titulo = data.titulo || 'Sin título';
            const artista = data.artista || 'Artista desconocido';
            const imagen = data.imagen || '';
            const lanzamiento = data.lanzamiento || 'N/A';
            const letra = data.letra || 'No se encontró la letra';
            
            const letraCorta = letra.length > 3000 ? letra.substring(0, 3000) + '\n\n... (letra truncada)' : letra;
            
            let mensaje = `「✰」 *${titulo}*\n`;
            mensaje += `*ᰔᩚ* *Artista:* ${artista}\n`;
            mensaje += `*ᰔᩚ* *Lanzamiento:* ${lanzamiento}\n`;
            mensaje += `─────────────────\n\n`;
            mensaje += `${letraCorta}`;
            
            if (imagen) {
                try {
                    const imgResponse = await axios.get(imagen, {
                        responseType: 'arraybuffer',
                        timeout: 15000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const imgBuffer = Buffer.from(imgResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: imgBuffer,
                        caption: mensaje,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                } catch (imgError) {
                    console.log('Error descargando imagen:', imgError.message);
                    await replyWithContext(mensaje);
                }
            } else {
                await replyWithContext(mensaje);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Lyrics buscado: ${titulo} - ${artista} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en lyrics:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message || 'No se pudo obtener la letra'}`);
            } catch (e) {}
        }
    }
};