import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { connectMongoDB } from '../lib/mongoose.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============ ESQUEMA Y MODELO PARA HISTORIAL ============
let HistorialModel = null;
let mongoose = null;

async function getHistorialModel() {
    if (HistorialModel) return HistorialModel;
    
    const { default: mongooseMod } = await import('mongoose');
    mongoose = mongooseMod;
    
    await connectMongoDB();
    
    const historialSchema = new mongoose.Schema({
        _id: { type: String, required: true },
        conversacion: { type: Array, default: [] },
        ultimaActualizacion: { type: Date, default: Date.now }
    });
    
    HistorialModel = mongoose.model('HistorialDeepSeek', historialSchema);
    return HistorialModel;
}

// ============ FUNCIONES PARA HISTORIAL (igual que antes pero con MongoDB) ============
async function getHistorialUsuario(userNumber) {
    try {
        const model = await getHistorialModel();
        const usuario = await model.findOne({ _id: userNumber });
        if (!usuario) return [];
        return usuario.conversacion || [];
    } catch (error) {
        console.error('Error cargando historial:', error);
        return [];
    }
}

async function addToHistorial(userNumber, role, content) {
    try {
        const model = await getHistorialModel();
        const usuario = await model.findOne({ _id: userNumber });
        
        const nuevoMensaje = {
            role: role,
            content: content,
            timestamp: new Date().toISOString()
        };
        
        if (usuario) {
            usuario.conversacion.push(nuevoMensaje);
            if (usuario.conversacion.length > 20) {
                usuario.conversacion = usuario.conversacion.slice(-20);
            }
            usuario.ultimaActualizacion = new Date();
            await usuario.save();
        } else {
            const nuevoUsuario = new model({
                _id: userNumber,
                conversacion: [nuevoMensaje]
            });
            await nuevoUsuario.save();
        }
        return true;
    } catch (error) {
        console.error('Error guardando historial:', error);
        return false;
    }
}

function construirContexto(historial, nuevaPregunta) {
    let contexto = '';
    
    for (const msg of historial) {
        if (msg.role === 'user') {
            contexto += `Usuario: ${msg.content}\n`;
        } else {
            contexto += `DeepSeek: ${msg.content}\n`;
        }
    }
    
    contexto += `Usuario: ${nuevaPregunta}\nDeepSeek:`;
    
    return contexto;
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}

export default {
    name: 'deepseek',
    alias: ['ds'],
    description: 'Pregunta algo a DeepSeek AI',
    category: 'ai',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const prompt = args.join(' ').trim();
            
            if (!prompt) {
                return await replyWithContext(`[ ★ ] Debes proporcionar una pregunta para DeepSeek`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🤖', key: msg.key } });
            } catch (e) {}
            
            await addToHistorial(userNumber, 'user', prompt);
            
            const historial = await getHistorialUsuario(userNumber);
            const contexto = construirContexto(historial, prompt);
            
            console.log(`📝 Contexto para ${pushName || userNumber}: ${historial.length} mensajes previos`);
            
            let answer = null;
            
            try {
                console.log(`🤖 Consultando API DeepSeek...`);
                
                const apiUrl = `https://api.snova.eu.cc/api/text-generation/deepseek?text=${encodeURIComponent(contexto)}&model=v32`;
                
                const response = await axios.get(apiUrl, {
                    timeout: 60000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'application/json'
                    }
                });
                
                if (response.data?.status && response.data?.result) {
                    answer = response.data.result;
                    console.log(`✅ Respuesta obtenida de API Snova`);
                } else {
                    throw new Error('No se pudo obtener respuesta de la API');
                }
                
            } catch (error) {
                console.log(`⚠️ API Snova falló: ${error.message}`);
                
                const APIS_ALTERNAS = [
                    {
                        name: 'Soonex',
                        url: 'https://api.soonex.biz.id/v1/ai/deepseek',
                        param: 'text',
                        getAnswer: (data) => data?.result
                    },
                    {
                        name: 'ZenZX',
                        url: 'https://api.zenzxz.my.id/ai/deepseek',
                        param: 'prompt',
                        getAnswer: (data) => data?.result?.reply
                    },
                    {
                        name: 'NexRay',
                        url: 'https://api.nexray.web.id/ai/deepseek',
                        param: 'text',
                        getAnswer: (data) => data?.result
                    }
                ];
                
                for (const api of APIS_ALTERNAS) {
                    try {
                        console.log(`🤖 Intentando API alternativa ${api.name}...`);
                        
                        const response = await axios.get(`${api.url}?${api.param}=${encodeURIComponent(contexto)}`, {
                            timeout: 60000,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Accept': 'application/json'
                            }
                        });
                        
                        answer = api.getAnswer(response.data);
                        
                        if (answer) {
                            console.log(`✅ Respuesta obtenida de ${api.name}`);
                            break;
                        }
                        
                    } catch (err) {
                        console.log(`⚠️ API alternativa ${api.name} falló: ${err.message}`);
                        continue;
                    }
                }
            }
            
            if (!answer) {
                throw new Error('Todas las APIs fallaron');
            }
            
            answer = answer.replace(/DeepSeek:/g, '').trim();
            
            await addToHistorial(userNumber, 'assistant', answer);
            
            if (answer.length > 3000) {
                answer = answer.substring(0, 3000) + '\n\n... (respuesta truncada)';
            }
            
            await replyWithContext(`${answer}`);
            
            try {
                await sock.sendMessage(from, { react: { text: '🌟', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ DeepSeek respondió para ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en deepseek:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`[ ★ ] *Error:* No se pudo obtener respuesta. Intenta más tarde.`);
            } catch (e) {}
        }
    }
};