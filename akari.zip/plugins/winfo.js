import { 
    obtenerPersonajePorNombre, 
    obtenerPersonajePorTag,
    verificarReclamo,
    obtenerPersonajesReclamados
} from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

export default {
    name: 'winfo',
    alias: ['infopj'],
    description: 'Muestra información de un personaje del gacha',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando winfo...');
            
            const { config, replyWithContext, userNumber, args } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const nombreBuscado = args.join(' ').trim();
            
            if (!nombreBuscado) {
                return await replyWithContext(
                    `❀ Debes proporcionar el nombre de un personaje\n> Ejemplo › ${config.prefix}winfo Luffy`
                );
            }
            
            // ============ BUSCAR PERSONAJE ============
            let personaje = await obtenerPersonajePorNombre(nombreBuscado);
            
            // Si no se encuentra, buscar por tag
            if (!personaje) {
                const tagLower = nombreBuscado.toLowerCase().replace(/\s+/g, '_');
                personaje = await obtenerPersonajePorTag(tagLower);
            }
            
            // Si no se encuentra, buscar por nombre invertido
            if (!personaje) {
                const palabras = nombreBuscado.trim().split(/\s+/);
                if (palabras.length > 1) {
                    const nombreInvertido = palabras.reverse().join(' ');
                    personaje = await obtenerPersonajePorNombre(nombreInvertido);
                }
            }
            
            // Si no se encuentra, buscar por coincidencia parcial
            if (!personaje) {
                const { obtenerTodosPersonajes } = await import('../lib/gacha.js');
                const todos = await obtenerTodosPersonajes();
                const nombreLower = nombreBuscado.toLowerCase();
                
                for (const pj of todos) {
                    const pjNombreLower = pj.nombre.toLowerCase();
                    if (pjNombreLower.includes(nombreLower) || nombreLower.includes(pjNombreLower)) {
                        personaje = pj;
                        break;
                    }
                }
            }
            
            if (!personaje) {
                return await replyWithContext(`❀ No se encontró el personaje *"${nombreBuscado}"*\n> Verifica que el nombre esté bien escrito`);
            }
            // ================================================================
            
            // ============ VERIFICAR ESTADO ============
            const reclamado = await verificarReclamo(from, personaje.id);
            let estado = '𝖫𝗂𝖻𝗋𝖾';
            
            if (reclamado) {
                const reclamos = await obtenerPersonajesReclamados(from);
                const reclamo = reclamos.find(r => r.personajeId === personaje.id);
                
                if (reclamo) {
                    const usersDb = loadUsersDb();
                    const user = usersDb.find(u => u.number === reclamo.usuarioId);
                    const nombreReclamador = user ? user.pushName : reclamo.usuarioId;
                    estado = `𝖱𝖾𝖼𝗅𝖺𝗆𝖺𝖽𝗈 𝗉𝗈𝗋 ${nombreReclamador}`;
                } else {
                    estado = '𝖱𝖾𝖼𝗅𝖺𝗆𝖺𝖽𝗈';
                }
            }
            // ================================================================
            
            // ============ CREAR MENSAJE ============
            const mensaje = 
`❀ 𝖭𝗈𝗆𝖻𝗋𝖾 › ${personaje.nombre}
⚥ 𝖦𝖾́𝗇𝖾𝗋𝗈 › ${personaje.genero}
✧ 𝖵𝖺𝗅𝗈𝗋 › ${personaje.valor}
♡ 𝖤𝗌𝗍𝖺𝖽𝗈 › ${estado}
❖ 𝖲𝖾𝗋𝗂𝖾 › ${personaje.anime}`;
            // ================================================================
            
            await replyWithContext(mensaje);
            
            console.log(`✅ winfo ejecutado: ${personaje.nombre} (${estado})`);
            
        } catch (error) {
            console.error('❌ Error en winfo:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};