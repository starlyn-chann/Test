import db from '#db';

export default {
    name: 'setbirth',
    alias: ['setfecha', 'setnacimiento'],
    description: 'Establece o elimina tu fecha de nacimiento',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        const currentYear = new Date().getFullYear();
        const input = args.join(' ');

        // Eliminar fecha de nacimiento
        if (input === 'delete' || input === 'eliminar' || input === 'remove') {
            if (!user?.birth) {
                return await replyWithContext(`✎ *No tienes una fecha de nacimiento establecida para eliminar.*`);
            }
            
            await db.updateUser(userNumber, 'birth', null);
            return await replyWithContext(`✎ *Tu fecha de nacimiento ha sido eliminada correctamente.*`);
        }

        if (user?.birth) {
            return await replyWithContext(`✎ Ya tienes una fecha establecida. Usa › *${config.prefix}setbirth delete* para eliminarla.`);
        }

        if (!input) {
            return await replyWithContext('《✧》 Debes ingresar una fecha válida.\n\n*Ejemplos:*' +
                `\n${config.prefix}setbirth 01/01/2000\n${config.prefix}setbirth 01/01\n${config.prefix}setbirth delete`);
        }

        const birth = validarFechaNacimiento(input, currentYear);
        if (!birth) {
            return await replyWithContext(`《✧》 Fecha inválida. Usa › *${config.prefix}setbirth 01/01/2000*`);
        }

        await db.updateUser(userNumber, 'birth', birth);
        return await replyWithContext(`✎ Se ha establecido tu fecha de nacimiento como: *${birth}*`);
    }
};

function validarFechaNacimiento(text, currentYear) {
    const formatos = [
        /^\d{1,2}\/\d{1,2}\/\d{4}$/,
        /^\d{1,2}\/\d{1,2}$/,
        /^\d{1,2} \w+$/,
        /^\d{1,2} \w+ \d{4}$/,
    ];
    if (!formatos.some((r) => r.test(text))) return null;

    let dia, mes, año;
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(text)) {
        [dia, mes, año] = text.split('/').map(Number);
    } else if (/^\d{1,2}\/\d{1,2}$/.test(text)) {
        [dia, mes] = text.split('/').map(Number);
        año = currentYear;
    } else {
        const partes = text.split(' ');
        dia = parseInt(partes[0]);
        mes = new Date(`${partes[1]} 1`).getMonth() + 1;
        año = partes[2] ? parseInt(partes[2]) : currentYear;
    }

    if (año > currentYear) return null;

    const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    const diasPorSemana = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    const diasPorMes = [31, (año % 4 === 0 && año % 100 !== 0) || año % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    while (dia > diasPorMes[mes - 1]) {
        dia -= diasPorMes[mes - 1];
        mes++;
        if (mes > 12) {
            mes = 1;
            año++;
        }
    }

    const fecha = new Date(`${año}-${String(mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`);
    const diaSemana = diasPorSemana[fecha.getUTCDay()];
    return `${diaSemana}, ${dia} de ${meses[mes - 1]}`;
}