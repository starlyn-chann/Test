import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para la verificación de NSFW
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Función para cargar la configuración de los grupos
function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

// Función auxiliar para esperar una cantidad de milisegundos
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export default {
    name: 'pene',
    alias: [],
    description: 'Envía una imagen o video nsfw (pene)',
    category: 'nsfw',
    
    async execute(sock, msg, options) {
        const { config, replyWithContext, isGroup } = options;
        const from = msg.key.remoteJid;

        try {
            // --- VALIDACIÓN NSFW ---
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------

            // Reacción inicial
            try { await sock.sendMessage(from, { react: { text: '🍆', key: msg.key } }); } catch (e) {}

            // --- ESPERA OBLIGATORIA DE 4 A 7 SEGUNDOS ---
            const tiempoEspera = Math.floor(Math.random() * (7000 - 4000 + 1)) + 4000;
            await delay(tiempoEspera);
            // ---------------------------------------------

            // 1. Petición a Vercel forzando recibir JSON
            const apiResponse = await axios.get('https://siriusapi.vercel.app/api/nsfw/pene/', {
                headers: {
                    'Accept': 'application/json'
                },
                responseType: 'text',
                timeout: 15000 // 15 segundos máximo para responder el JSON de Vercel
            });
            
            // Parsear el JSON manualmente
            let info;
            try {
                info = JSON.parse(apiResponse.data);
            } catch (e) {
                throw new Error(`El servidor no envió un JSON válido. Respuesta recibida:\n${String(apiResponse.data).slice(0, 200)}`);
            }

            if (!info || !info.result || !info.result.data || !Array.isArray(info.result.data) || info.result.data.length === 0) {
                throw new Error(`Estructura inesperada en el JSON recibido:\n${JSON.stringify(info, null, 2)}`);
            }

            const mediaData = info.result.data[0];
            
            // 2. Determinar si es video o imagen basándose en el JSON obtenido
            const isVideo = mediaData.video && mediaData.video !== "null" && mediaData.video !== "";
            const mediaUrl = isVideo ? mediaData.video : mediaData.image;

            if (!mediaUrl || mediaUrl === "null") {
                throw new Error(`Los datos llegaron bien, pero las URLs multimedia están en null.\nDatos: ${JSON.stringify(mediaData)}`);
            }

            // 3. Descargar el archivo multimedia directo desde Catbox
            // Le ponemos un timeout de 30 segundos. Si Catbox se congela, el bot saltará al catch en lugar de quedarse callado.
            const response = await axios.get(mediaUrl, {
                responseType: 'arraybuffer',
                timeout: 30000 
            });
            
            const buffer = Buffer.from(response.data);

            if (!buffer || buffer.length === 0) {
                throw new Error('El archivo descargado está completamente vacío (0 bytes).');
            }

            // 4. Contenido del mensaje original (Diseño intacto)
            const messageContent = {
                [isVideo ? 'video' : 'image']: buffer,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            };

            // Enviar a Baileys
            await sock.sendMessage(from, messageContent, { quoted: msg });

            // Reacción de éxito definitivo
            try { await sock.sendMessage(from, { react: { text: '✅', key: msg.key } }); } catch (e) {}

        } catch (error) {
            console.error('❌ Error en pene:', error);
            try {
                // Si falla quita el emoji original y pone la X
                await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                
                if (error.response && error.response.data) {
                    const errData = typeof error.response.data === 'object' ? JSON.stringify(error.response.data) : String(error.response.data).slice(0, 300);
                    await replyWithContext(`❌ Error del Servidor (${error.response.status}): ${errData}`);
                } else {
                    await replyWithContext(`❌ Error: ${error.message || error}`);
                }
            } catch (e) {}
        }
    }
};