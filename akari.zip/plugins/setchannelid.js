import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function getBotConfigPath(sock) {
    let botNumber = '';
    if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    
    if (!botNumber) return null;
    
    // Verificar si es sub-bot
    const subBotPath = path.join(process.cwd(), 'subs', botNumber, 'config.js');
    if (fs.existsSync(subBotPath)) {
        return { path: subBotPath, type: 'sub-bot', number: botNumber };
    }
    
    // Si no, es bot principal
    const mainPath = path.join(process.cwd(), 'config.js');
    if (fs.existsSync(mainPath)) {
        return { path: mainPath, type: 'main', number: botNumber };
    }
    
    return null;
}

export default {
    name: 'setchannelid',
    alias: ['setcanalid'],
    description: 'Cambia el ID del canal del bot (solo dueño del bot)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, userNumber, senderNumber } = options;
            
            const userNumberClean = cleanNumber(senderNumber || userNumber || '');
            const botownerClean = config.botowner ? cleanNumber(config.botowner) : '';
            
            if (!botownerClean || userNumberClean !== botownerClean) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede cambiar el ID del canal*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`🌽 Debes proporcionar el ID de tu canal\n\n> *Uso correcto:* ${config.prefix}setchannelid 120363403616345878@newsletter`);
            }
            
            let newId = args.join(' ');
            
            if (newId.startsWith('+')) {
                newId = newId.substring(1).trim();
            }
            
            if (!newId || newId.length === 0) {
                return await replyWithContext(`🌽 *El ID del canal no puede estar vacío*`);
            }
            
            if (!newId.endsWith('@newsletter')) {
                return await replyWithContext(`🌽 *Formato de ID inválido*\n\n> *El ID debe terminar en:* @newsletter`);
            }
            
            const botConfig = getBotConfigPath(sock);
            if (!botConfig) {
                throw new Error('No se pudo encontrar la configuración del bot');
            }
            
            const configPath = botConfig.path;
            const botTipo = botConfig.type;
            
            if (!fs.existsSync(configPath)) {
                throw new Error(`No se encontró configuración en: ${configPath}`);
            }
            
            // Leer y actualizar usando regex
            let configContent = fs.readFileSync(configPath, 'utf8');
            const canalIdRegex = /(canalId:\s*['"])([^'"]+)(['"])/;
            const match = configContent.match(canalIdRegex);
            
            if (!match) {
                throw new Error('No se encontró el campo canalId en la configuración');
            }
            
            const oldId = match[2];
            const newConfigContent = configContent.replace(canalIdRegex, `$1${newId}$3`);
            fs.writeFileSync(configPath, newConfigContent, 'utf8');
            
            // Actualizar en memoria
            if (options.config) {
                options.config.canalId = newId;
            }
            
            console.log(`📝 ID del canal actualizado para ${botTipo}: "${oldId}" → "${newId}"`);
            
            await replyWithContext(`🎑 ID del canal actualizado con éxito\n\n> *Nuevo ID:* ${newId}`);
            
        } catch (error) {
            console.error('Error en setchannelid:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};