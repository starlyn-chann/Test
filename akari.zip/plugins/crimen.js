import economy from '#economy';

export default {
    name: 'crimen',
    alias: ['crime'],
    description: 'Comete un crimen y gana o pierde dinero',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const cooldownTime = 5 * 60 * 1000;
            
            const lastUsed = await economy.getCooldown(from, userNumber, 'crimen');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes cometer otro crimen en ${minutos}m ${segundos}s`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const exito = Math.random() < 0.6;
            let cantidad = 0;
            let mensaje = '';
            let crimen = '';
            
            const crimenesExito = [
                'Robaste un banco 🏦', 'Asaltaste una joyería 💎',
                'Hiciste un robo a mano armada 🔫', 'Estafaste a un millonario 🎭',
                'Robaste un vehículo de lujo 🚗', 'Atracaste un camión de valores 🚚'
            ];
            
            const crimenesFracaso = [
                'Intentaste robar un banco pero te atraparon 🚔',
                'Fallaste en un asalto y te hirieron 🏥',
                'Te descubrieron en una estafa ⚖️'
            ];
            
            if (exito) {
                cantidad = Math.floor(Math.random() * (15000 - 5000 + 1)) + 5000;
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: cantidad,
                    nombre: pushName || 'Usuario'
                });
                crimen = crimenesExito[Math.floor(Math.random() * crimenesExito.length)];
                mensaje = `❀ *Crimen exitoso* 😈\n> ${crimen}\n> *Ganaste* ${economy.formatNumber(cantidad)} ${moneda}`;
            } else {
                cantidad = Math.floor(Math.random() * (3000 - 500 + 1)) + 500;
                const dineroActual = userEconomy.dinero || 0;
                
                if (dineroActual >= cantidad) {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -cantidad,
                        nombre: pushName || 'Usuario'
                    });
                } else {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -dineroActual,
                        nombre: pushName || 'Usuario'
                    });
                    cantidad = dineroActual;
                }
                
                crimen = crimenesFracaso[Math.floor(Math.random() * crimenesFracaso.length)];
                mensaje = `❀ *Crimen fallido* 😅\n> ${crimen}\n> *Perdiste* ${economy.formatNumber(cantidad)} ${moneda}`;
            }
            
            await economy.setCooldown(from, userNumber, 'crimen');
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`${mensaje}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en crimen:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};