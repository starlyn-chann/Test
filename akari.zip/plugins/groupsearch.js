import axios from 'axios';

export default {
    name: 'groupsearch',
    alias: ['grupsearch', 'groups'],
    description: 'Busca grupos de WhatsApp por nombre',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes proporcionar un término de búsqueda para grupos\n> Ejemplo: ${config.prefix}groupsearch Amigos`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            // Llamar a la API de búsqueda de grupos
            const apiUrl = `https://api.ikyyxd.my.id/search/grupwangcap?text=${encodeURIComponent(query)}`;
            const response = await axios.get(apiUrl, {
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.status || !response.data?.data || response.data.data.length === 0) {
                return await replyWithContext(`《✧》 No se encontraron grupos para *${query}*`);
            }
            
            const allGroups = response.data.data;
            
            // Seleccionar 15 grupos aleatorios
            const shuffled = [...allGroups];
            for (let i = shuffled.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
            }
            const selectedGroups = shuffled.slice(0, 15);
            
            // Construir mensaje
            let message = `★ \`\`\`G R O U P   S E A R C H\`\`\`\n\n`;
            message += `> *${selectedGroups.length} grupos encontrados para:* ${query}\n\n`;
            
            for (let i = 0; i < selectedGroups.length; i++) {
                const group = selectedGroups[i];
                message += `[ ✰ ] *${i + 1}.* ${group.name}\n`;
                if (group.description && group.description !== 'No description') {
                    const desc = group.description.length > 60 ? group.description.substring(0, 60) + '...' : group.description;
                    message += `> *ᰔᩚ* ${desc}\n`;
                }
                message += `> *ᰔᩚ* ${group.join_url}\n\n`;
            }
            
            await replyWithContext(message);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Groupsearch usado por ${pushName || userNumber}: "${query}" - ${selectedGroups.length} grupos mostrados`);
            
        } catch (error) {
            console.error('❌ Error en groupsearch:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                const query = options.args?.join(' ') || 'la búsqueda';
                await replyWithContext(`《✧》 No se encontraron grupos para *${query}*`);
            } catch (e) {}
        }
    }
};