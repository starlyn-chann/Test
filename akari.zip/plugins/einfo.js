import economy from '#economy';

export default {
    name: 'einfo',
    alias: [],
    description: 'Muestra el tiempo restante para usar comandos de economía',
    category: 'economy',
    
    async execute(sock, msg, { replyWithContext, isGroup, userNumber }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Función para obtener tiempo restante
            async function getRemainingTime(groupId, userId, command) {
                try {
                    const lastUsed = await economy.getCooldown(groupId, userId, command);
                    const cooldown = economy.getCooldownTime(command);
                    const now = Date.now();
                    const remaining = (lastUsed + cooldown) - now;
                    
                    if (remaining <= 0) return 'Libre';
                    return economy.formatTime(remaining);
                } catch (error) {
                    return 'Error';
                }
            }
            
            const workTime = await getRemainingTime(from, userNumber, 'work');
            const aventuraTime = await getRemainingTime(from, userNumber, 'aventura');
            const chambearTime = await getRemainingTime(from, userNumber, 'chambear');
            const minarTime = await getRemainingTime(from, userNumber, 'minar');
            const crimenTime = await getRemainingTime(from, userNumber, 'crimen');
            const robTime = await getRemainingTime(from, userNumber, 'rob');
            const dailyTime = await getRemainingTime(from, userNumber, 'daily');
            const huntTime = await getRemainingTime(from, userNumber, 'hunt');
            const fishTime = await getRemainingTime(from, userNumber, 'fish');
            
            const mensaje = `❀ *Información de economía*

*⧖ Work :* ${workTime}
*⧖ Aventura :* ${aventuraTime}
*⧖ Chambear :* ${chambearTime}
*⧖ Minar :* ${minarTime}
*⧖ Crimen :* ${crimenTime}
*⧖ Robar :* ${robTime}
*⧖ Daily :* ${dailyTime}
*⧖ Cazar :* ${huntTime}
*⧖ Pescar :* ${fishTime}`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en einfo:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};