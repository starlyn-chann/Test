import economy from '#economy';

export default {
    name: 'rob',
    alias: ['robar'],
    description: 'Roba coins a otro usuario',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName, args }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let targetUser = null;
            let targetJid = null;
            let mentionedUser = null;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg) {
                const quotedParticipant = msg.message.extendedTextMessage.contextInfo.participant;
                if (quotedParticipant) {
                    mentionedUser = quotedParticipant;
                }
            }
            
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                const mentions = msg.message.extendedTextMessage.contextInfo.mentionedJid;
                if (mentions && mentions.length > 0) {
                    mentionedUser = mentions[0];
                }
            }
            
            if (!mentionedUser && args && args.length > 0) {
                const arg = args[0].replace(/@/g, '').replace(/\D/g, '');
                if (arg) {
                    mentionedUser = `${arg}@s.whatsapp.net`;
                }
            }
            
            if (!mentionedUser) {
                return await replyWithContext(`「✰」 Debes mencionar o responder al usuario que quieres robar\n> Ejemplo: ${config.prefix}rob @usuario`);
            }
            
            targetJid = mentionedUser;
            targetUser = economy.cleanNumber(targetJid);
            
            if (targetUser === userNumber) {
                return await replyWithContext(`❀ *No puedes robarte a ti mismo*`);
            }
            
            const lastUsed = await economy.getCooldown(from, userNumber, 'rob');
            const now = Date.now();
            const cooldownTime = 60 * 60 * 1000;
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes robar de nuevo en ${minutos}m ${segundos}s`);
            }
            
            const targetEconomy = await economy.getUserEconomy(from, targetUser);
            if (!targetEconomy) {
                return await replyWithContext(`❀ *El usuario no tiene dinero en este grupo*`);
            }
            
            const dineroVictima = targetEconomy.dinero || 0;
            
            if (dineroVictima <= 0) {
                return await replyWithContext(`❀ *El usuario no tiene dinero para robar*`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const exito = Math.random() < 0.6;
            let cantidadRobada = 0;
            let mensaje = '';
            
            if (exito) {
                const porcentaje = Math.random() * (0.30 - 0.10) + 0.10;
                cantidadRobada = Math.floor(dineroVictima * porcentaje);
                
                if (cantidadRobada < 100) cantidadRobada = 100;
                if (cantidadRobada > 100000) cantidadRobada = 100000;
                if (cantidadRobada > dineroVictima) cantidadRobada = dineroVictima;
                
                await economy.updateUserEconomy(from, targetUser, {
                    dinero: -cantidadRobada,
                    nombre: targetEconomy.nombre || 'Usuario'
                });
                
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: cantidadRobada,
                    nombre: pushName || 'Usuario'
                });
                
                mensaje = `❀ *Robo exitoso* 🔫\n> Has robado ${economy.formatNumber(cantidadRobada)} ${config.moneda} a @${targetUser}`;
            } else {
                const perdida = Math.floor(Math.random() * (1000 - 100 + 1)) + 100;
                const dineroLadron = userEconomy.dinero || 0;
                
                if (dineroLadron >= perdida) {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -perdida,
                        nombre: pushName || 'Usuario'
                    });
                    mensaje = `❀ *Robo fallido*\n> Intentaste robar a @${targetUser} pero te atraparon\n> Has perdido ${economy.formatNumber(perdida)} ${config.moneda}`;
                } else {
                    mensaje = `❀ *Robo fallido*\n> Intentaste robar a @${targetUser} pero no tenías dinero para perder`;
                }
            }
            
            await economy.setCooldown(from, userNumber, 'rob');
            
            const updatedLadron = await economy.getUserEconomy(from, userNumber);
            const updatedVictima = await economy.getUserEconomy(from, targetUser);
            
            mensaje += `\n\n*Tu billetera:* ${economy.formatNumber(updatedLadron.dinero)} ${config.moneda}\n*Billetera de la víctima:* ${economy.formatNumber(updatedVictima.dinero)} ${config.moneda}`;
            
            await replyWithContext(mensaje, [targetJid]);
            
        } catch (error) {
            console.error('❌ Error en rob:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};