import economy from '#economy';

export default {
    name: 'd',
    alias: ['depositar'],
    description: 'Deposita dinero en el banco',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName, args }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Debes especificar una cantidad\n> Ejemplo: ${config.prefix}d 1000\n> ${config.prefix}d all`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const dineroActual = userEconomy.dinero || 0;
            
            let cantidad = 0;
            if (args[0].toLowerCase() === 'all') {
                cantidad = dineroActual;
            } else {
                cantidad = parseInt(args[0]);
                if (isNaN(cantidad) || cantidad <= 0) {
                    return await replyWithContext(`「✰」 Cantidad inválida\n> Debes ingresar un número positivo`);
                }
            }
            
            if (cantidad === 0) {
                return await replyWithContext(`❀ *No tienes dinero para depositar*`);
            }
            
            if (cantidad > dineroActual) {
                return await replyWithContext(`❀ *No tienes suficiente dinero*\n> Billetera: ${economy.formatNumber(dineroActual)} ${config.moneda}`);
            }
            
            await economy.updateUserEconomy(from, userNumber, {
                dinero: -cantidad,
                banco: cantidad,
                nombre: pushName || 'Usuario'
            });
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`❀ *Depósito exitoso*\n> Has depositado ${economy.formatNumber(cantidad)} ${config.moneda} en el banco\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${config.moneda}\n*Banco:* ${economy.formatNumber(updatedEconomy.banco)} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en d:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};