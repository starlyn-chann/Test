import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `spotify_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatDuration(durationMs) {
    if (!durationMs) return 'N/A';
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

async function descargarYEnviar(sock, downloadUrl, title, artist, album, year, duration, cover, config, senderJid, pushName, userNumber, quotedMsg, targetJid) {
    try {
        await sock.sendMessage(targetJid, { react: { text: '📥', key: quotedMsg.key } });
    } catch (e) {}

    const audioResponse = await axios.get(downloadUrl, {
        responseType: 'arraybuffer',
        timeout: 120000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive'
        }
    });
    
    const audioBuffer = Buffer.from(audioResponse.data);
    const cleanTitle = `${artist} - ${title}`.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    
    let coverBuffer = null;
    if (cover) {
        try {
            const coverResponse = await axios.get(cover, {
                responseType: 'arraybuffer',
                timeout: 10000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });
            coverBuffer = Buffer.from(coverResponse.data);
        } catch (e) {
            console.log('Error descargando cover:', e.message);
        }
    }
    
    const infoText = `ㅤ♡゙  *𝘚𝘱𝘰𝘵𝘪𝘧𝘺-𝘗𝘭𝘢𝘺ᰱ*   🫍::ㅤׁ\n\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Título:* ${title}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Artista:* ${artist}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Álbum:* ${album || 'N/A'}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Año:* ${year || 'N/A'}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Duración:* ${formatDuration(duration)}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Tamaño:* ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB\n> *Disfruta de la canción  ᐡ,,o ·̫ o,,ᐡ*`;
    
    if (coverBuffer) {
        await sock.sendMessage(targetJid, {
            image: coverBuffer,
            caption: infoText,
            contextInfo: {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        }, { quoted: quotedMsg });
    } else {
        await sock.sendMessage(targetJid, {
            text: infoText,
            contextInfo: {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        }, { quoted: quotedMsg });
    }
    
    await sock.sendMessage(targetJid, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        fileName: `${cleanTitle}.mp3`,
        ptt: false,
        contextInfo: {
            mentionedJid: senderJid ? [senderJid] : [],
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: config.canalId || '',
                serverMessageId: 0,
                newsletterName: config.canalNombre || ''
            }
        }
    }, { quoted: quotedMsg });
    
    console.log(`✅ Canción descargada: ${title} - ${artist} por ${pushName || userNumber}`);
}

export default {
    name: 'spotifyplay',
    alias: ['splay'],
    description: 'Busca y descarga canciones de Spotify',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir el nombre de una canción\n> Ejemplo: ${config.prefix}splay Boss Bitch`);
            }
            
            if (query.includes('open.spotify.com/track/')) {
                try {
                    await sock.sendMessage(from, { react: { text: '🕑', key: msg.key } });
                    
                    const apiUrl = `https://apiakari.vercel.app/api/downloader/spotify?url=${encodeURIComponent(query)}&key=starlyndev`;
                    const response = await axios.get(apiUrl, { timeout: 30000 });
                    
                    if (!response.data?.status || !response.data?.data) {
                        throw new Error('No se pudo obtener la canción');
                    }
                    
                    const data = response.data.data;
                    const downloadUrl = data.download || data.raw?.mp3;
                    const title = data.title || data.raw?.name;
                    const artist = data.author || data.raw?.artist;
                    const album = data.album || data.raw?.album;
                    const year = data.year || data.raw?.year;
                    const duration = data.duration || data.raw?.duration;
                    const cover = data.cover || data.raw?.cover;
                    
                    if (!downloadUrl) {
                        throw new Error('No se pudo obtener el enlace de descarga');
                    }
                    
                    await descargarYEnviar(sock, downloadUrl, title, artist, album, year, duration, cover, config, senderJid, pushName, userNumber, msg, from);
                    
                    try {
                        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                    } catch (e) {}
                    
                } catch (error) {
                    console.error('Error descargando:', error);
                    await replyWithContext(`❌ Error: ${error.message}`);
                    try {
                        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                    } catch (e) {}
                }
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // ============ NUEVA API DE BÚSQUEDA (SOLO CAMBIO AQUÍ) ============
            const apiUrl = `https://api.alwayscodex.my.id/api/search/spotify?query=${encodeURIComponent(query)}&limit=10`;
            const response = await axios.get(apiUrl, { timeout: 30000 });
            
            if (!response.data?.status || !response.data?.result || response.data.result.length === 0) {
                await replyWithContext(`「✰」 No se encontraron resultados para "${query}"`);
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            const tracks = response.data.result;
            
            // ============ MISMO DISEÑO ORIGINAL ============
            const rows = tracks.slice(0, 10).map((track) => {
                // Adaptar los campos de la nueva API al formato original
                const artistName = track.artist || 'Artista desconocido';
                const duration = track.duration || 'N/A';
                return {
                    header: `${artistName}`,
                    title: `${track.title}`,
                    description: `⏱️ ${duration}`,
                    id: `${config.prefix}splay ${track.url}`
                };
            });
            
            const sections = [{
                title: "RESULTADOS DE BÚSQUEDA",
                rows: rows
            }];
            
            let imageBuffer = null;
            if (tracks[0]?.thumb) {
                try {
                    const imgUrl = tracks[0].thumb;
                    const imgResponse = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
                    imageBuffer = Buffer.from(imgResponse.data);
                } catch (e) {
                    console.log('Error descargando imagen:', e.message);
                }
            }
            
            const infoText = `✿ 𝘚𝘗𝘖𝘛𝘐𝘍𝘠 𝘋𝘖𝘞𝘕𝘓𝘖𝘈𝘋 ✿\n\n` +
                           `「✰」 Búsqueda › ${query}\n` +
                           `「✰」 Resultados › ${Math.min(tracks.length, 10)}`;
            
            if (imageBuffer) {
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: infoText,
                    interactiveButtons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Opciones",
                            sections: sections
                        })
                    }],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: infoText,
                    interactiveButtons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Opciones",
                            sections: sections
                        })
                    }],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            console.log(`🎵 Spotify buscado: ${query} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en spotifyplay:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};
