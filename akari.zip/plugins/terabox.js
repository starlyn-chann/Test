import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

function getTempFilePath(extension) {
    return path.join(tempFolder, `terabox_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function cleanFilename(name = '') {
    return String(name || '').replace(/[^a-zA-Z0-9._-]/g, '_');
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'terabox',
    alias: ['tbx', 'teradl', 'tera'],
    description: 'Descarga archivos de TeraBox/1024tera usando API de Nanzz',
    category: 'download',
    
    async execute(sock, msg, options) {
        let tempPath = null;
        
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const url = args.join(' ').trim();
            
            if (!url) {
                return await replyWithContext(
                    `「✰」 *USO DEL COMANDO*\n` +
                    `> ✩̶๋۪ׄ .terabox <url>\n\n` +
                    `📌 *Ejemplo:* .terabox https://www.terabox.com/s/xxxxx`
                );
            }
            
            if (!/^https?:\/\//i.test(url) || (!url.includes('terabox') && !url.includes('1024tera'))) {
                return await replyWithContext(`「✰」 *Link inválido*\n> Debes proporcionar un enlace público de TeraBox/1024tera.`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            // ============ CONSULTAR API DE NANZZ ============
            const apiUrl = `https://api-nanzz.my.id/docs/api/downloader/terabox.php?url=${encodeURIComponent(url)}`;
            console.log(`📥 Consultando API Nanzz: ${apiUrl}`);
            
            const response = await axios.get(apiUrl, {
                timeout: 60000,
                headers: {
                    'User-Agent': UA,
                    'Accept': 'application/json'
                }
            });
            
            console.log(`📊 API respuesta: ${JSON.stringify(response.data).substring(0, 200)}...`);
            
            if (!response.data?.status) {
                throw new Error(response.data?.message || 'La API no pudo procesar el enlace.');
            }
            
            const result = response.data.result;
            if (!result?.files || !Array.isArray(result.files) || result.files.length === 0) {
                throw new Error('No se encontraron archivos en el enlace.');
            }
            
            // Obtener el primer archivo (o el único)
            const file = result.files[0];
            if (!file) {
                throw new Error('No se pudo obtener información del archivo.');
            }
            
            if (!file.downloadUrl) {
                throw new Error(`No se pudo obtener enlace de descarga para "${file.name}"`);
            }
            
            // Verificar tamaño (máximo 1.79GB)
            const sizeMatch = String(file.sizeFormatted || '').match(/([0-9]+(?:\.[0-9]+)?)\s*(GB|MB|KB)/i);
            if (sizeMatch) {
                const sizeNum = parseFloat(sizeMatch[1]);
                const unit = sizeMatch[2].toUpperCase();
                let sizeInGB = 0;
                if (unit === 'GB') sizeInGB = sizeNum;
                else if (unit === 'MB') sizeInGB = sizeNum / 1024;
                else if (unit === 'KB') sizeInGB = sizeNum / 1024 / 1024;
                
                if (sizeInGB > 1.79) {
                    return await replyWithContext(`「✰」 *Archivo demasiado grande*\n> El límite es de 1.79 GB por archivo.`);
                }
            }
            
            // Mensaje de inicio de descarga
            await replyWithContext(`「✰」 *DESCARGANDO*\n\n📛 *Nombre:* ${file.name}\n📦 *Peso:* ${file.sizeFormatted || 'Desconocido'}\n\n> ✩̶๋۪ׄ *Enviando archivo...*`);
            
            // ============ DESCARGAR Y ENVIAR ============
            const extension = path.extname(file.name).slice(1) || 'bin';
            tempPath = getTempFilePath(extension);
            
            console.log(`📥 Descargando desde: ${file.downloadUrl}`);
            
            const fileResponse = await axios.get(file.downloadUrl, {
                responseType: 'stream',
                timeout: 120000,
                headers: {
                    'User-Agent': UA,
                    'Accept': '*/*',
                    'Referer': 'https://terabox.com/',
                    'Origin': 'https://terabox.com'
                }
            });
            
            const writer = fs.createWriteStream(tempPath);
            
            await new Promise((resolve, reject) => {
                fileResponse.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
            
            const fileBuffer = fs.readFileSync(tempPath);
            const cleanName = cleanFilename(file.name);
            
            // Determinar mimetype
            let mimeType = 'application/octet-stream';
            const ext = path.extname(file.name).toLowerCase();
            const mimeTypes = {
                '.mp4': 'video/mp4',
                '.mp3': 'audio/mpeg',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.pdf': 'application/pdf',
                '.apk': 'application/vnd.android.package-archive',
                '.zip': 'application/zip',
                '.rar': 'application/x-rar-compressed',
                '.7z': 'application/x-7z-compressed',
                '.mcaddon': 'application/zip',
                '.mcpack': 'application/zip',
                '.webp': 'image/webp',
                '.webm': 'video/webm'
            };
            if (ext in mimeTypes) mimeType = mimeTypes[ext];
            
            await sock.sendMessage(from, {
                document: fileBuffer,
                mimetype: mimeType,
                fileName: cleanName,
                caption: `> Solicitado por: ${pushName || userNumber}\n> 📦 ${file.sizeFormatted || 'Desconocido'}`,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ TeraBox descargado: ${file.name} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en terabox:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                
                if (error.response?.status === 403) {
                    await replyWithContext(`❌ *Error 403:* El enlace de descarga ha expirado o está bloqueado.\n\n> Intenta nuevamente, el enlace se regenerará automáticamente.`);
                } else if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
                    await replyWithContext(`❌ *Timeout:* La descarga tardó demasiado.\n> El archivo puede ser muy grande o el servidor está lento.`);
                } else {
                    await replyWithContext(`❌ *Error:* ${error.message || error}\n\n> Verifica que el enlace sea válido y vuelve a intentarlo.`);
                }
            } catch (e) {}
            
        } finally {
            try { if (tempPath && fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch (e) {}
        }
    }
};