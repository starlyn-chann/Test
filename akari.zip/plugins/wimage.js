import { 
    obtenerPersonajePorNombre, 
    obtenerPersonajePorTag,
    obtenerTodosPersonajes
} from '../lib/gacha.js';
import axios from 'axios';

// ============ DANBOORU SESSION ============
let sessionCookie = null;

async function getDanbooruSession() {
    if (sessionCookie) return sessionCookie;
    try {
        const res = await axios.post('https://danbooru.donmai.us/session', 
            'user[name]=uwudanonino5599&user[password]=danoninoleonel5599', 
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        sessionCookie = res.headers['set-cookie'];
        return sessionCookie;
    } catch (e) {
        console.error('Error obteniendo sesión Danbooru:', e.message);
        return null;
    }
}

async function getDanbooruImage(tag) {
    try {
        const cookie = await getDanbooruSession();
        const url = `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(tag)}&limit=20&random=true`;
        
        const response = await axios.get(url, {
            headers: { 'Cookie': cookie || '' },
            timeout: 15000
        });

        const json = response.data;

        if (!Array.isArray(json) || json.length === 0) {
            return null;
        }

        const mediaList = json
            .filter(p => p?.file_url && /\.(jpe?g|png|gif|webp)$/i.test(p.file_url))
            .map(p => p.file_url);

        if (!mediaList.length) {
            return null;
        }

        return mediaList[Math.floor(Math.random() * mediaList.length)];
    } catch (error) {
        console.error('Error buscando imagen en Danbooru:', error.message);
        return null;
    }
}

// ============ SAFEBOORU ============
async function getSafebooruImage(tag) {
    try {
        const url = `https://safebooru.org/index.php?page=dapi&s=post&q=index&json=1&tags=${encodeURIComponent(tag)}`;
        
        const response = await axios.get(url, {
            headers: { 
                'User-Agent': 'Mozilla/5.0', 
                'Accept': 'application/json' 
            },
            timeout: 15000
        });

        const json = response.data;
        const data = Array.isArray(json) ? json : json?.post || json?.data || [];

        if (!data || data.length === 0) {
            return null;
        }

        const mediaList = data
            .map(i => i?.file_url || i?.large_file_url || i?.image)
            .filter(u => typeof u === 'string' && /\.(jpe?g|png|gif|webp)$/i.test(u));

        if (!mediaList.length) {
            return null;
        }

        return mediaList[Math.floor(Math.random() * mediaList.length)];
    } catch (error) {
        console.error('Error buscando imagen en Safebooru:', error.message);
        return null;
    }
}

// =============================================

export default {
    name: 'wimage',
    alias: ['wimg', 'imgpj'],
    description: 'Muestra la imagen de un personaje del gacha',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando wimage...');
            
            const { config, replyWithContext, userNumber, senderJid, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const nombreBuscado = args.join(' ').trim();
            
            if (!nombreBuscado) {
                return await replyWithContext(
                    `❀ Debes proporcionar el nombre de un personaje\n> Ejemplo › ${config.prefix}wimage Luffy`
                );
            }
            
            // ============ BUSCAR PERSONAJE ============
            let personaje = await obtenerPersonajePorNombre(nombreBuscado);
            
            // Si no se encuentra, buscar por tag
            if (!personaje) {
                const tagLower = nombreBuscado.toLowerCase().replace(/\s+/g, '_');
                personaje = await obtenerPersonajePorTag(tagLower);
            }
            
            // Si no se encuentra, buscar por nombre invertido
            if (!personaje) {
                const palabras = nombreBuscado.trim().split(/\s+/);
                if (palabras.length > 1) {
                    const nombreInvertido = palabras.reverse().join(' ');
                    personaje = await obtenerPersonajePorNombre(nombreInvertido);
                }
            }
            
            // Si no se encuentra, buscar por coincidencia parcial
            if (!personaje) {
                const todos = await obtenerTodosPersonajes();
                const nombreLower = nombreBuscado.toLowerCase();
                
                for (const pj of todos) {
                    const pjNombreLower = pj.nombre.toLowerCase();
                    if (pjNombreLower.includes(nombreLower) || nombreLower.includes(pjNombreLower)) {
                        personaje = pj;
                        break;
                    }
                }
            }
            
            if (!personaje) {
                return await replyWithContext(`❀ No se encontró el personaje *"${nombreBuscado}"*\n> Verifica que el nombre esté bien escrito`);
            }
            // ================================================================
            
            // ============ BUSCAR IMAGEN (DANBOORU → SAFEBOORU) ============
            let imageUrl = null;
            let imageFound = false;
            
            if (personaje.tag) {
                console.log(`🔍 Buscando imagen para: ${personaje.tag}`);
                
                // Primero intentar en Danbooru
                imageUrl = await getDanbooruImage(personaje.tag);
                if (imageUrl) {
                    imageFound = true;
                    console.log(`✅ Imagen encontrada en Danbooru: ${imageUrl}`);
                } else {
                    console.log(`❌ Sin resultados en Danbooru, buscando en Safebooru...`);
                    // Si no hay en Danbooru, buscar en Safebooru
                    imageUrl = await getSafebooruImage(personaje.tag);
                    if (imageUrl) {
                        imageFound = true;
                        console.log(`✅ Imagen encontrada en Safebooru: ${imageUrl}`);
                    } else {
                        console.log(`❌ No se encontró imagen en Danbooru ni Safebooru para: ${personaje.tag}`);
                    }
                }
            }
            
            if (!imageFound) {
                return await replyWithContext(`❀ No se encontró imagen para *"${personaje.nombre}"*\n> Intenta con otro personaje`);
            }
            // ================================================================
            
            // ============ CREAR CAPTION ============
            const caption = 
`❀ 𝖭𝗈𝗆𝖻𝗋𝖾 › ${personaje.nombre}
⚥ 𝖦𝖾́𝗇𝖾𝗋𝗈 › ${personaje.genero}
❖ 𝖲𝖾𝗋𝗂𝖾 › ${personaje.anime}`;
            // ================================================================
            
            // ============ ENVIAR IMAGEN ============
            await sock.sendMessage(from, {
                image: { url: imageUrl },
                caption: caption,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            // ================================================================
            
            console.log(`✅ wimage ejecutado: ${personaje.nombre}`);
            
        } catch (error) {
            console.error('❌ Error en wimage:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};