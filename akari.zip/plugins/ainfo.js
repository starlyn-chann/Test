import { obtenerTodosPersonajes, verificarReclamo, obtenerPersonajesReclamados } from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

export default {
    name: 'ainfo',
    alias: ['serieinfo'],
    description: 'Muestra información de una serie/anime del gacha',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando ainfo...');
            
            const { config, replyWithContext, userNumber, args } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const serieBuscada = args.join(' ').trim();
            
            if (!serieBuscada) {
                return await replyWithContext(
                    `❀ Debes proporcionar el nombre de una serie/anime\n> Ejemplo › ${config.prefix}ainfo One Piece`
                );
            }
            
            // ============ OBTENER TODOS LOS PERSONAJES ============
            const todosPersonajes = await obtenerTodosPersonajes();
            
            console.log(`📊 Total personajes en BD: ${todosPersonajes ? todosPersonajes.length : 0}`);
            
            if (!todosPersonajes || todosPersonajes.length === 0) {
                return await replyWithContext(`❀ No hay personajes en la base de datos\n> Agrega personajes con ${config.prefix}addpj`);
            }
            
            // Filtrar personajes por serie (búsqueda parcial)
            const personajesSerie = todosPersonajes.filter(pj => {
                if (!pj || !pj.anime) return false;
                return pj.anime.toLowerCase().includes(serieBuscada.toLowerCase());
            });
            
            console.log(`📊 Personajes encontrados para "${serieBuscada}": ${personajesSerie.length}`);
            
            if (personajesSerie.length === 0) {
                return await replyWithContext(`❀ No se encontró la serie *"${serieBuscada}"*\n> Verifica que el nombre esté bien escrito`);
            }
            
            // ============ OBTENER NOMBRE EXACTO DE LA SERIE ============
            const nombreSerie = personajesSerie[0].anime || serieBuscada;
            // ================================================================
            
            // ============ VERIFICAR RECLAMOS EN EL GRUPO ============
            const reclamos = await obtenerPersonajesReclamados(from);
            const idsReclamados = new Set(reclamos.map(r => r.personajeId));
            
            // Obtener usuarios reclamadores
            const usersDb = loadUsersDb();
            const reclamoMap = {};
            for (const reclamo of reclamos) {
                reclamoMap[reclamo.personajeId] = reclamo.usuarioId;
            }
            // ================================================================
            
            // ============ CALCULAR ESTADÍSTICAS ============
            let totalReclamados = 0;
            const personajesConEstado = [];
            
            for (const pj of personajesSerie) {
                // Verificar que el personaje tenga los campos necesarios
                if (!pj || !pj.id) continue;
                
                const reclamado = idsReclamados.has(pj.id);
                let estado = 'Libre';
                let nombreReclamador = null;
                
                if (reclamado) {
                    totalReclamados++;
                    const usuarioId = reclamoMap[pj.id];
                    if (usuarioId) {
                        const user = usersDb.find(u => u.number === usuarioId);
                        nombreReclamador = user ? user.pushName : usuarioId;
                        estado = `Reclamado por ${nombreReclamador}`;
                    } else {
                        estado = 'Reclamado';
                    }
                }
                
                personajesConEstado.push({
                    id: pj.id || 'unknown',
                    nombre: pj.nombre || 'Sin nombre',
                    valor: pj.valor || 0,
                    genero: pj.genero || 'Desconocido',
                    anime: pj.anime || 'Desconocido',
                    estado,
                    reclamado,
                    nombreReclamador
                });
            }
            
            // Ordenar por valor (mayor a menor)
            personajesConEstado.sort((a, b) => (b.valor || 0) - (a.valor || 0));
            
            const totalPersonajes = personajesConEstado.length;
            const porcentaje = totalPersonajes > 0 
                ? Math.round((totalReclamados / totalPersonajes) * 100) 
                : 0;
            // ================================================================
            
            // ============ CREAR MENSAJE ============
            let mensaje = `- ꒰ 👒 ੭ *${nombreSerie}*\n\n`;
            mensaje += ` ׂ⁞⁞𖹭̤᪲ ֢𝆬𐑼֢ *Total Waifus › ${totalPersonajes}*\n`;
            mensaje += ` ׂ⁞⁞𖹭̤᪲ ֢𝆬𐑼֢ *Reclamados › ${totalReclamados} (${porcentaje}%)*\n\n`;
            
            for (const pj of personajesConEstado) {
                mensaje += `𖹭.ᐟ ${pj.nombre} *(${pj.valor})*\n`;
                mensaje += `> ✦.˚ *Estado › ${pj.estado}*\n\n`;
            }
            // ================================================================
            
            await replyWithContext(mensaje);
            
            console.log(`✅ ainfo ejecutado: ${nombreSerie} (${totalPersonajes} personajes)`);
            
        } catch (error) {
            console.error('❌ Error en ainfo:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};