import economy from '#economy';

export default {
    name: 'hunt',
    alias: ['cazar'],
    description: 'Caza un animal y gana dinero',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const cooldownTime = 5 * 60 * 1000; // 5 minutos
            
            // Verificar cooldown
            const lastUsed = await economy.getCooldown(from, userNumber, 'hunt');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes cazar de nuevo en ${minutos}m ${segundos}s`);
            }
            
            // Obtener economía del usuario
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            // 70% éxito, 30% fracaso
            const exito = Math.random() < 0.7;
            
            const animales = [
                { nombre: '🐗 Jabalí', min: 2000, max: 8000 },
                { nombre: '🦌 Ciervo', min: 1500, max: 6000 },
                { nombre: '🐇 Conejo', min: 500, max: 2000 },
                { nombre: '🦊 Zorro', min: 1000, max: 4000 },
                { nombre: '🐺 Lobo', min: 3000, max: 10000 },
                { nombre: '🦅 Águila', min: 2500, max: 7500 },
                { nombre: '🐗 Jabalí', min: 2000, max: 8000 },
                { nombre: '🦌 Ciervo', min: 1500, max: 6000 },
                { nombre: '🐇 Conejo', min: 500, max: 2000 },
                { nombre: '🦊 Zorro', min: 1000, max: 4000 },
                { nombre: '🐺 Lobo', min: 3000, max: 10000 },
                { nombre: '🦅 Águila', min: 2500, max: 7500 },
                { nombre: '🐃 Búfalo', min: 4000, max: 12000 },
                { nombre: '🦌 Alce', min: 3500, max: 9000 },
                { nombre: '🐗 Jabalí', min: 2000, max: 8000 }
            ];
            
            const animal = animales[Math.floor(Math.random() * animales.length)];
            const ganancia = Math.floor(Math.random() * (animal.max - animal.min + 1)) + animal.min;
            
            let mensaje = '';
            
            if (exito) {
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: ganancia,
                    nombre: pushName || 'Usuario'
                });
                
                mensaje = `❀ *Caza exitosa* 🏹\n> Has cazado un *${animal.nombre}*\n> *Ganaste* ${economy.formatNumber(ganancia)} ${moneda}`;
            } else {
                const perdida = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
                const dineroActual = userEconomy.dinero || 0;
                
                if (dineroActual >= perdida) {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -perdida,
                        nombre: pushName || 'Usuario'
                    });
                    mensaje = `❀ *Caza fallida* 😔🖕\n> El *${animal.nombre}* escapó y perdiste ${economy.formatNumber(perdida)} ${moneda}`;
                } else {
                    mensaje = `❀ *Caza fallida* 😔🖕\n> El *${animal.nombre}* escapó, pero no tenías dinero para perder`;
                }
            }
            
            // Guardar cooldown
            await economy.setCooldown(from, userNumber, 'hunt');
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`${mensaje}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy?.dinero || 0)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en hunt:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};