import axios from "axios";

export default {
    name: 'xnxxsearch',
    alias: ['xsearch'],
    description: 'Busca videos en xnxx',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, pushName, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            if (!args || args.length === 0) {
                return await replyWithContext(`♡ Por favor, ingresa una búsqueda\n> Uso: ${config.prefix}xnxxsearch [consulta]`);
            }

            const query = args.join(" ");
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}

            // Consulta a la API
            const apiUrl = `https://api.delirius.store/search/xnxxsearch?query=${encodeURIComponent(query)}`;
            const response = await axios.get(apiUrl, { timeout: 30000 });
            const res = response.data;

            if (!res.status || !res.data || res.data.length === 0) {
                try { await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }); } catch (e) {}
                return await replyWithContext("🔞 No se encontraron resultados.");
            }

            // Seleccionar 9 resultados aleatorios
            const allResults = res.data;
            const shuffled = allResults.sort(() => 0.5 - Math.random());
            const random9 = shuffled.slice(0, 9);

            // Construcción del mensaje solo texto
            let albumText = `乂  X N X X - S E A R C H 乂\n\n`;

            random9.forEach((v) => {
                albumText += `*»* Título » ${v.title}\n`;
                albumText += `*»* Vistas » ${v.views || 'N/A'}\n`;
                albumText += `*»* Duración » ${v.duration || 'N/A'}\n`;
                albumText += `*»* Enlace » ${v.link}\n\n`;
            });

            albumText += `> *Búsqueda de:* ${pushName}`;

            // Envío del mensaje como texto con contextInfo para el canal
            await sock.sendMessage(from, {
                text: albumText,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

        } catch (error) {
            console.error("❌ Error en xnxxsearch:", error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`♡ Error en xnxxsearch: ${error.message}`);
            } catch (e) {}
        }
    }
};