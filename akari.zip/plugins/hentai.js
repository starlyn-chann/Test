import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para la verificación de NSFW
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

export default {
    name: 'hentai',
    alias: [],
    description: 'Envía una imagen nsfw (hentai)',
    category: 'nsfw',
    
    async execute(sock, msg, options) {
        const { config, replyWithContext, isGroup } = options;
        const from = msg.key.remoteJid;

        try {
            // --- VALIDACIÓN NSFW ---
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------

            try { await sock.sendMessage(from, { react: { text: '🥵', key: msg.key } }); } catch (e) {}

            const baseUrl = 'https://sakurah.onrender.com/hentai/';
            let mediaUrl = '';
            let buffer = null;
            
            // Creamos una lista con los números del 1 al 1000 de forma aleatoria
            const pool = Array.from({ length: 1000 }, (_, i) => i + 1).sort(() => Math.random() - 0.5);

            // Bucle inteligente: va probando los números al azar hasta encontrar uno que responda 200 OK
            for (let nextIdx of pool) {
                const testUrl = `${baseUrl}image${nextIdx}.jpg`;
                try {
                    // Petición HEAD rápida para verificar la existencia real del archivo sin descargarlo completo
                    const check = await axios.head(testUrl, { timeout: 3000 });
                    if (check.status === 200) {
                        mediaUrl = testUrl;
                        break; // ¡Encontrada! Rompemos el bucle
                    }
                } catch (err) {
                    // Si da error 404 u otro, continúa intentando con el siguiente número disponible
                    continue;
                }
            }

            if (!mediaUrl) {
                throw new Error('No se encontró ninguna imagen disponible del 1 al 1000.');
            }

            // Descargar ahora sí el archivo real que confirmamos que existe
            const response = await axios.get(mediaUrl, {
                responseType: 'arraybuffer',
                timeout: 30000
            });
            
            buffer = Buffer.from(response.data);

            const messageContent = {
                image: buffer,
                caption: `> Contenido extraído de Hentai Archive`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            };

            await sock.sendMessage(from, messageContent, { quoted: msg });

            try { await sock.sendMessage(from, { react: { text: '✅', key: msg.key } }); } catch (e) {}

        } catch (error) {
            console.error('❌ Error en comando hentai:', error);
            try {
                await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`❌ Error: No pude obtener el contenido de Hentai Archive.`);
            } catch (e) {}
        }
    }
};