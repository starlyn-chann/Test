import axios from 'axios';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

// Función para convertir video a WebP animado usando FFmpeg
async function convertVideoToWebp(buffer) {
    return new Promise(async (resolve, reject) => {
        const tempId = Date.now() + Math.random().toString(36).substring(7);
        const inputPath = path.join(tempFolder, `bratv_input_${tempId}.mp4`);
        const outputPath = path.join(tempFolder, `bratv_output_${tempId}.webp`);
        
        try {
            // Guardar video temporal
            fs.writeFileSync(inputPath, buffer);
            
            // Convertir a WebP animado con FFmpeg
            const ffmpeg = spawn('ffmpeg', [
                '-i', inputPath,
                '-vcodec', 'libwebp',
                '-vf', 'fps=15,scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000',
                '-lossless', '0',
                '-compression_level', '6',
                '-q:v', '80',
                '-loop', '0',
                '-an',
                '-vsync', '0',
                '-s', '512:512',
                '-f', 'webp',
                outputPath
            ]);
            
            ffmpeg.on('close', async (code) => {
                try {
                    if (code !== 0) {
                        throw new Error(`FFmpeg falló con código ${code}`);
                    }
                    
                    if (fs.existsSync(outputPath)) {
                        const webpBuffer = fs.readFileSync(outputPath);
                        // Limpiar archivos temporales
                        fs.unlinkSync(inputPath);
                        fs.unlinkSync(outputPath);
                        resolve(webpBuffer);
                    } else {
                        throw new Error('No se generó el archivo WebP');
                    }
                } catch (err) {
                    reject(err);
                }
            });
            
            ffmpeg.on('error', (err) => {
                reject(err);
            });
            
            // Timeout después de 30 segundos
            setTimeout(() => {
                ffmpeg.kill();
                reject(new Error('FFmpeg timeout'));
            }, 30000);
            
        } catch (err) {
            reject(err);
        }
    });
}

// Función para detectar si la respuesta es video válido
function isValidVideo(buffer) {
    if (!buffer || buffer.length < 4) return false;
    
    const hex = buffer.toString('hex', 0, 4).toUpperCase();
    // MP4, MOV, AVI, etc.
    const validSignatures = ['000000', '66747970', '6D6F6F76'];
    
    return validSignatures.some(sig => hex.startsWith(sig));
}

export default {
    name: 'bratv',
    alias: ['bratvideo'],
    description: 'Crea sticker animado con texto estilo brat',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const text = args.join(' ').trim();
            
            if (!text) {
                return await replyWithContext(`❀ Por favor, ingresa un texto para crear el Sticker animado.\n\n> Ejemplo: ${config.prefix}bratv Hola mundo`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } });
            } catch (e) {}
            
            // API de Delirius
            const apiUrl = `https://api.delirius.store/canvas/bratvideo?text=${encodeURIComponent(text)}`;
            console.log(`🔄 Solicitando: ${apiUrl}`);
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 60000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'video/mp4,video/webm,video/*,*/*'
                }
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('No se pudo generar el video');
            }
            
            const videoBuffer = Buffer.from(response.data);
            
            // Verificar si la respuesta es un video válido
            if (!isValidVideo(videoBuffer)) {
                // Si no es video válido, puede ser un error HTML
                const errorText = videoBuffer.toString('utf-8', 0, 200);
                console.error('Respuesta no es video:', errorText);
                throw new Error('La API no devolvió un video válido');
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🎨', key: msg.key } });
            } catch (e) {}
            
            // Convertir a WebP animado
            let stickerBuffer;
            try {
                stickerBuffer = await convertVideoToWebp(videoBuffer);
                console.log('✅ Sticker animado convertido a WebP');
            } catch (convError) {
                console.log('⚠️ Error convirtiendo a WebP:', convError.message);
                throw new Error('No se pudo convertir el video a sticker animado. Asegúrate de tener FFmpeg instalado.');
            }
            
            // Enviar sticker animado
            await sock.sendMessage(from, { 
                sticker: stickerBuffer,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Brat animado creado para ${pushName || userNumber}: "${text}"`);
            
        } catch (error) {
            console.error('❌ Error en bratv:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `⚠︎ Error: ${error.message}`;
            
            if (error.message.includes('FFmpeg')) {
                errorMsg += '\n\n🌴 Para stickers animados necesito FFmpeg instalado en el sistema.';
            } else if (error.response?.status === 404) {
                errorMsg = `⚠︎ La API no está disponible temporalmente`;
            } else if (error.message.includes('ECONNREFUSED')) {
                errorMsg = `⚠︎ No se pudo conectar con la API`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};