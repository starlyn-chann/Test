import db from '#db';

export default {
    name: 'delbirth',
    alias: ['delfecha', 'deletebirth'],
    description: 'Elimina tu fecha de nacimiento',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        
        if (!user?.birth) {
            return await replyWithContext(`✎ *No tienes una fecha de nacimiento establecida para eliminar.*`);
        }
        
        await db.updateUser(userNumber, 'birth', null);
        return await replyWithContext(`✎ *Tu fecha de nacimiento ha sido eliminada correctamente.*`);
    }
};