import { 
    obtenerPersonajesReclamados, 
    obtenerPersonajePorId,
    reclamarPersonaje,
    eliminarReclamo,
    obtenerTodosPersonajes
} from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function getDisplayName(number) {
    const users = loadUsersDb();
    const user = users.find(u => u.number === number);
    return user ? user.pushName : number;
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

// Cache para regalos pendientes
const pendingGive = {};

export default {
    name: 'giveallharem',
    alias: ['giveall'],
    description: 'Regala todos tus personajes a otro usuario',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando giveallharem...');
            
            const { config, replyWithContext, args, userNumber, senderJid, pushName, quotedMsg, quotedMessage, quotedText } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // ============ VERIFICAR SI ES UNA ACEPTACIÓN ============
            const esAceptar = args.length >= 1 && args[0].toLowerCase() === 'aceptar';
            
            if (esAceptar) {
                // Verificar que se está respondiendo a un mensaje
                if (!quotedMsg || !quotedMessage) {
                    return await replyWithContext(`❀ Debes responder al mensaje de confirmación.`);
                }
                
                // Verificar que el mensaje citado contiene la confirmación
                const textoCitado = quotedText || '';
                const esConfirmacion = textoCitado.includes('¿confirmas regalar todo tu harem') || 
                                      textoCitado.includes('confirmas regalar todo tu harem');
                
                if (!esConfirmacion) {
                    return await replyWithContext(`❀ Debes responder al mensaje de confirmación.`);
                }
                
                const pendingKey = `${from}_${userNumber}`;
                const pendingData = pendingGive[pendingKey];
                
                if (!pendingData) {
                    return await replyWithContext(`❀ No hay solicitud de regalo pendiente.`);
                }
                
                // Verificar que el usuario que acepta sea el que inició la solicitud
                if (pendingData.sender !== userNumber) {
                    return await replyWithContext(`ꕥ Solo el usuario que inició la solicitud puede confirmar.`);
                }
                
                // Verificar que el receptor siga existiendo
                const receiverId = pendingData.to;
                
                // ============ REALIZAR TRANSFERENCIA ============
                // Obtener los personajes actuales del usuario
                const reclamados = await obtenerPersonajesReclamados(from, userNumber);
                const idsReclamados = reclamados.map(r => r.personajeId);
                
                // Filtrar solo los personajes que están en la lista de regalo
                const idsToGive = idsReclamados.filter(id => pendingData.ids.includes(id));
                
                if (idsToGive.length === 0) {
                    delete pendingGive[pendingKey];
                    return await replyWithContext(`ꕥ Ya no tienes personajes para regalar.`);
                }
                
                let transferidos = 0;
                let valorTotal = 0;
                
                for (const id of idsToGive) {
                    // Eliminar reclamo del usuario actual
                    const eliminado = await eliminarReclamo(from, id);
                    
                    if (eliminado) {
                        // Crear reclamo para el receptor
                        const reclamado = await reclamarPersonaje(from, id, receiverId);
                        if (reclamado.success) {
                            transferidos++;
                            // Obtener valor del personaje
                            const personaje = await obtenerPersonajePorId(id);
                            if (personaje) {
                                valorTotal += personaje.valor || 0;
                            }
                        }
                    }
                }
                
                // Limpiar cache
                clearTimeout(pendingData.timeout);
                delete pendingGive[pendingKey];
                
                const nameTo = getDisplayName(receiverId);
                
                const mensajeExito = 
`「✿」 Has regalado con éxito todos tus personajes a *${nameTo}*!

> ❏ Personajes regalados: *${transferidos}*
> ⴵ Valor total: *${valorTotal.toLocaleString()}*`;

                await replyWithContext(mensajeExito);
                console.log(`✅ giveallharem completado: ${userNumber} → ${receiverId} (${transferidos} personajes)`);
                return;
            }
            // ================================================================
            
            // ============ CREAR NUEVA SOLICITUD DE REGALO ============
            // Obtener el usuario target (mencionado o respondido)
            let targetNumber = null;
            let targetJid = null;
            
            // Verificar si hay mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (mentionedJid) {
                targetJid = mentionedJid;
                targetNumber = cleanNumber(mentionedJid);
            } else if (quotedMsg && quotedMessage) {
                const quotedParticipant = quotedMsg?.participant || quotedMsg?.remoteJid;
                if (quotedParticipant) {
                    targetJid = quotedParticipant;
                    targetNumber = cleanNumber(quotedParticipant);
                }
            } else if (args && args.length > 0) {
                const possibleNumber = cleanNumber(args[0]);
                if (possibleNumber && possibleNumber.length > 8) {
                    targetNumber = possibleNumber;
                    targetJid = `${possibleNumber}@s.whatsapp.net`;
                }
            }
            
            if (!targetNumber) {
                return await replyWithContext(
                    `❀ Debes mencionar o responder a quien quieras regalarle tus personajes.\n> ✐ Ejemplo: *${config.prefix}giveallharem @usuario*`
                );
            }
            
            if (targetNumber === userNumber) {
                return await replyWithContext(`ꕥ No puedes regalarte personajes a ti mismo.`);
            }
            
            // ============ OBTENER PERSONAJES DEL USUARIO ============
            const reclamados = await obtenerPersonajesReclamados(from, userNumber);
            
            if (!reclamados || reclamados.length === 0) {
                return await replyWithContext(`ꕥ No tienes personajes para regalar.`);
            }
            
            // Obtener información de los personajes
            const list = [];
            let valorTotal = 0;
            
            for (const reclamo of reclamados) {
                const personaje = await obtenerPersonajePorId(reclamo.personajeId);
                if (personaje) {
                    const valor = personaje.valor || 0;
                    valorTotal += valor;
                    list.push({
                        id: personaje.id,
                        nombre: personaje.nombre,
                        valor: valor
                    });
                }
            }
            
            if (list.length === 0) {
                return await replyWithContext(`ꕥ No tienes personajes para regalar.`);
            }
            // ================================================================
            
            // ============ CREAR SOLICITUD ============
            const nameTarget = getDisplayName(targetNumber);
            const nameSender = pushName || userNumber;
            const pendingKey = `${from}_${userNumber}`;
            
            // Guardar solicitud pendiente con timeout
            const timeoutDuration = 60000; // 60 segundos
            const timeoutId = setTimeout(async () => {
                if (pendingGive[pendingKey]) {
                    delete pendingGive[pendingKey];
                    try {
                        await sock.sendMessage(from, { 
                            text: `✘ *La solicitud de regalo ha expirado*`
                        });
                    } catch (e) {}
                    console.log(`⏰ Solicitud de regalo expirada en ${from}`);
                }
            }, timeoutDuration);
            
            pendingGive[pendingKey] = {
                sender: userNumber,
                to: targetNumber,
                ids: list.map(c => c.id),
                value: valorTotal,
                count: list.length,
                chat: from,
                timeout: timeoutId,
                timestamp: Date.now()
            };
            // ================================================================
            
            // ============ ENVIAR MENSAJE DE CONFIRMACIÓN ============
            const mensaje = 
`「✿」 *${nameSender}*, ¿confirmas regalar todo tu harem a *${nameTarget}*?

❏ Personajes a transferir: *${list.length}*
❏ Valor total: *${valorTotal.toLocaleString()}*

✐ Para confirmar responde a este mensaje con *${config.prefix}giveallharem aceptar*
⧖ La solicitud expira en 60 segundos.
⚠ *Esta acción no se puede deshacer.*`;

            await sock.sendMessage(from, {
                text: mensaje,
                mentions: [senderJid, targetJid]
            }, { quoted: msg });
            // ================================================================
            
            console.log(`✅ giveallharem ejecutado: ${nameSender} → ${nameTarget} (${list.length} personajes)`);
            
        } catch (error) {
            console.error('❌ Error en giveallharem:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};