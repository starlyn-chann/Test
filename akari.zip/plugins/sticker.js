import fs from 'fs';
import path from 'path';
import { randomBytes } from 'crypto';
import { exec } from 'child_process';
import { promisify } from 'util';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import webpmux from 'node-webpmux';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execAsync = promisify(exec);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

const METADATA_FILE = path.join(__dirname, '..', 'data', 'metadata.json');

function loadMetadata() {
    try {
        if (fs.existsSync(METADATA_FILE)) {
            const data = fs.readFileSync(METADATA_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

function getMetadata(userNumber) {
    const metadata = loadMetadata();
    return metadata[userNumber] || { packname: '', author: '' };
}

function randomFileName(ext) {
    return `${randomBytes(6).readUIntLE(0, 6).toString(36)}.${ext}`;
}

function getTempFilePath(extension) {
    return path.join(tempFolder, randomFileName(extension));
}

// ============ FUNCIONES DE CONVERSIÓN ============

async function imageToWebp(media) {
    const tmpIn = path.join(tempFolder, randomFileName('jpg'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, media);

    await new Promise((resolve, reject) => {
        exec(`ffmpeg -y -i "${tmpIn}" -vcodec libwebp -vf "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15,pad=320:320:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse" "${tmpOut}"`,
            (err) => err ? reject(err) : resolve());
    });

    const buff = fs.readFileSync(tmpOut);
    try { fs.unlinkSync(tmpIn); } catch (e) {}
    try { fs.unlinkSync(tmpOut); } catch (e) {}
    return buff;
}

async function videoToWebp(media) {
    const tmpIn = path.join(tempFolder, randomFileName('mp4'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, media);

    await new Promise((resolve, reject) => {
        exec(`ffmpeg -y -i "${tmpIn}" -vcodec libwebp -vf "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15,pad=320:320:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse" -loop 0 -ss 00:00:00 -t 00:00:05 -preset default -an -vsync 0 "${tmpOut}"`,
            (err) => err ? reject(err) : resolve());
    });

    const buff = fs.readFileSync(tmpOut);
    try { fs.unlinkSync(tmpIn); } catch (e) {}
    try { fs.unlinkSync(tmpOut); } catch (e) {}
    return buff;
}

async function addExif(webpBuffer, metadata) {
    const tmpIn = path.join(tempFolder, randomFileName('webp'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, webpBuffer);

    let author = metadata.author || '';
    if (author.length > 340) author = author.slice(0, 340);

    const json = {
        "sticker-pack-id": "roxy_migurdia",
        "sticker-pack-name": metadata.packname || '',
        "sticker-pack-publisher": author,
        "emojis": ["✨"]
    };

    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
        0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00
    ]);
    const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8');
    const exif = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);

    const img = new webpmux.Image();
    await img.load(tmpIn);
    img.exif = exif;
    await img.save(tmpOut);
    
    const result = fs.readFileSync(tmpOut);
    try { fs.unlinkSync(tmpIn); } catch (e) {}
    try { fs.unlinkSync(tmpOut); } catch (e) {}
    return result;
}

async function writeExifImg(media, metadata) {
    const wMedia = await imageToWebp(media);
    return await addExif(wMedia, metadata);
}

async function writeExifVid(media, metadata) {
    const wMedia = await videoToWebp(media);
    return await addExif(wMedia, metadata);
}

export default {
    name: 'sticker',
    alias: ['s'],
    description: 'Convierte imagen o video a sticker',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        let inputPath = null;
        let outputPath = null;
        
        try {
            const { config, replyWithContext, userNumber, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            let mediaMessage = null;
            let mediaType = null;
            let isSticker = false;
            
            if (quotedMsg?.quotedMessage) {
                if (quotedMsg.quotedMessage.imageMessage) {
                    mediaMessage = quotedMsg.quotedMessage.imageMessage;
                    mediaType = 'image';
                } else if (quotedMsg.quotedMessage.videoMessage) {
                    mediaMessage = quotedMsg.quotedMessage.videoMessage;
                    mediaType = 'video';
                } else if (quotedMsg.quotedMessage.stickerMessage) {
                    mediaMessage = quotedMsg.quotedMessage.stickerMessage;
                    mediaType = 'sticker';
                    isSticker = true;
                }
            }
            
            if (!mediaMessage) {
                if (msg.message?.imageMessage) {
                    mediaMessage = msg.message.imageMessage;
                    mediaType = 'image';
                } else if (msg.message?.videoMessage) {
                    mediaMessage = msg.message.videoMessage;
                    mediaType = 'video';
                } else if (msg.message?.stickerMessage) {
                    mediaMessage = msg.message.stickerMessage;
                    mediaType = 'sticker';
                    isSticker = true;
                }
            }
            
            if (!mediaMessage || !mediaType) {
                return await replyWithContext(`❀ Debes responder a una imagen/video/sticker`);
            }
            
            if (mediaType === 'video') {
                const duration = mediaMessage.seconds || 0;
                if (duration > 20) {
                    return await replyWithContext(`❀ El video no puede durar más de 20 segundos.\n> Duración: ${duration} segundos`);
                }
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });
            } catch (e) {}
            
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg?.stanzaId || msg.key.id,
                    participant: quotedMsg?.participant || from,
                    fromMe: false
                },
                message: {
                    [mediaType + 'Message']: mediaMessage
                }
            };
            
            const mediaBuffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                { logger: console, reuploadRequest: sock.updateMediaMessage }
            );
            
            if (!mediaBuffer || mediaBuffer.length === 0) {
                throw new Error('No se pudo descargar el archivo');
            }
            
            const userMetadata = getMetadata(userNumber);
            const fullArgs = args.join(' ');
            
            let customPackname = '';
            let customAuthor = '';
            
            if (userMetadata) {
                customPackname = userMetadata.packname || '';
                customAuthor = userMetadata.author || '';
            } else if (fullArgs) {
                if (fullArgs.includes('|')) {
                    const parts = fullArgs.split('|');
                    customPackname = parts[0].trim();
                    customAuthor = parts.slice(1).join('|').trim();
                    if (fullArgs.startsWith('|')) customPackname = '';
                } else {
                    customPackname = fullArgs.trim();
                    customAuthor = '';
                }
            }
            
            let stickerBuffer;
            const metadata = { packname: customPackname, author: customAuthor };
            
            if (isSticker) {
                stickerBuffer = await addExif(mediaBuffer, metadata);
            } else if (mediaType === 'image') {
                stickerBuffer = await writeExifImg(mediaBuffer, metadata);
            } else {
                stickerBuffer = await writeExifVid(mediaBuffer, metadata);
            }
            
            await sock.sendMessage(from, {
                sticker: stickerBuffer,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Sticker creado por ${pushName || userNumber} (${mediaType})`);
            
        } catch (error) {
            console.error('❌ Error en sticker:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❀ Error: ${error.message}`);
            } catch (e) {}
            
        } finally {
            try { if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch (e) {}
            try { if (outputPath && fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
        }
    }
};