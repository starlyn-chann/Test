import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `chazam_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

async function uploadFile(fileBuffer) {
    const tempPath = getTempFilePath('audio');
    fs.writeFileSync(tempPath, fileBuffer);
    
    try {
        const form = new FormData();
        form.append('files[]', fs.createReadStream(tempPath));
        
        const res = await axios.post('https://uguu.se/upload.php', form, {
            headers: form.getHeaders(),
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });
        
        return res.data;
    } catch (error) {
        console.error('Error subiendo archivo:', error);
        throw error;
    } finally {
        try { fs.unlinkSync(tempPath); } catch (e) {}
    }
}

export default {
    name: 'chazam',
    alias: ['shazam'],
    description: 'Reconoce la canción de un audio o video',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage) {
                return await replyWithContext(`「✰」 Responde a un *Audio/Video*`);
            }
            
            let mediaBuffer = null;
            
            // Verificar si es audio
            if (quotedMessage.audioMessage) {
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        audioMessage: quotedMessage.audioMessage
                    }
                };
                
                mediaBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            }
            // Verificar si es video
            else if (quotedMessage.videoMessage) {
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        videoMessage: quotedMessage.videoMessage
                    }
                };
                
                mediaBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            }
            else {
                return await replyWithContext(`「✰」 Responde a un *Audio/Video*`);
            }
            
            if (!mediaBuffer || mediaBuffer.length === 0) {
                throw new Error('No se pudo descargar el archivo');
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🎵', key: msg.key } });
            } catch (e) {}
            
            // Subir archivo
            const upload = await uploadFile(mediaBuffer);
            
            if (!upload || !upload.files || !upload.files[0] || !upload.files[0].url) {
                throw new Error('Error al subir el archivo');
            }
            
            // Llamar a la API de Shazam
            const shazamResponse = await axios.get(`https://apis-starlights-team.koyeb.app/starlight/shazam?url=${encodeURIComponent(upload.files[0].url)}`, {
                timeout: 30000
            });
            
            const json = shazamResponse.data;
            
            if (json.error) {
                throw new Error('No se pudo reconocer la canción');
            }
            
            const app = {
                title: json.data?.title || json.title || 'Desconocido',
                artist: json.data?.artist || json.artist || 'Desconocido',
                type: json.data?.type || json.type || 'Desconocido',
                url: json.data?.url || json.url || 'No disponible',
                avatar: json.data?.avatar || json.avatar || 'No disponible',
                gender: json.data?.gender || json.gender || 'No disponible',
                thumbnail: json.data?.thumbnail || json.thumbnail || 'No disponible'
            };
            
            const txt = `*\`-• C H A Z A M - M U S I C •-\`*\n\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Nombre:* ${app.title}\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Artista:* ${app.artist}\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Género:* ${app.gender}\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Tipo:* ${app.type}\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Link:* ${app.url}\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Avatar:* ${app.avatar}\n` +
                `𓈒㌡۪𝆬🌸ٜ֯᱙ׅ֗ *Thumbnail:* ${app.thumbnail}`;
            
            await replyWithContext(txt);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Chazam usado por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en chazam:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};