import economy from '#economy';

export default {
    name: 'pay',
    alias: ['pagar', 'dar'],
    description: 'Regala dinero a otro usuario desde tu banco',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName, args, senderJid }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length < 2) {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Ejemplo: ${config.prefix}pay 1000 @usuario`);
            }
            
            let cantidad = 0;
            let targetJid = null;
            let targetUser = null;
            
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
                targetUser = economy.cleanNumber(targetJid);
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!targetJid && quotedMsg?.participant) {
                targetJid = quotedMsg.participant;
                targetUser = economy.cleanNumber(targetJid);
            }
            
            if (!targetJid) {
                for (const arg of args) {
                    if (arg.includes('@') || arg.includes('s.whatsapp.net')) {
                        targetJid = arg;
                        targetUser = economy.cleanNumber(targetJid);
                        break;
                    }
                }
            }
            
            if (!targetJid) {
                return await replyWithContext(`「✰」 Debes mencionar a quien quieres pagar\n> Ejemplo: ${config.prefix}pay 1000 @usuario`);
            }
            
            targetUser = economy.cleanNumber(targetJid);
            const targetJidClean = targetUser + '@s.whatsapp.net';
            const senderCleanJid = economy.cleanNumber(senderJid) + '@s.whatsapp.net';
            
            if (targetJidClean === senderCleanJid) {
                return await replyWithContext(`❀ *No puedes pagarte a ti mismo*`);
            }
            
            for (const arg of args) {
                const num = parseInt(arg);
                if (!isNaN(num) && num > 0) {
                    cantidad = num;
                    break;
                }
            }
            
            if (cantidad <= 0) {
                return await replyWithContext(`「✰」 Debes especificar una cantidad válida\n> Ejemplo: ${config.prefix}pay 1000 @usuario`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const bancoRemitente = userEconomy.banco || 0;
            
            if (cantidad > bancoRemitente) {
                return await replyWithContext(`❀ *No tienes suficiente dinero en el banco*\n> Banco: ${economy.formatNumber(bancoRemitente)} ${config.moneda}`);
            }
            
            let targetName = 'Usuario';
            try {
                const contact = await sock.contactQuery(targetJidClean);
                if (contact) {
                    targetName = contact.notify || contact.name || 'Usuario';
                }
            } catch (e) {
                targetName = targetUser;
            }
            
            let targetEconomy = await economy.getUserEconomy(from, targetUser);
            if (!targetEconomy) {
                await economy.setUserEconomy(from, targetUser, {
                    dinero: 0,
                    banco: 0,
                    nombre: targetName
                });
                targetEconomy = await economy.getUserEconomy(from, targetUser);
            }
            
            await economy.updateUserEconomy(from, userNumber, {
                banco: -cantidad,
                nombre: pushName || 'Usuario'
            });
            
            await economy.updateUserEconomy(from, targetUser, {
                banco: cantidad,
                nombre: targetName
            });
            
            const updatedRemitente = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(
                `✧ Has pagado ${economy.formatNumber(cantidad)} ${config.moneda} a @${targetUser}\n\n*Tu banco:* ${economy.formatNumber(updatedRemitente.banco)} ${config.moneda}`,
                [targetJidClean]
            );
            
        } catch (error) {
            console.error('❌ Error en pay:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};