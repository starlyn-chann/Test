import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';
import db from '#db';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function loadSelfStatus(sock, isSubBot) {
    try {
        let selfFilePath;
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        if (!botNumber) return false;
        const subBotDir = path.join(process.cwd(), 'subs', botNumber);
        if (isSubBot || fs.existsSync(subBotDir)) {
            selfFilePath = path.join(subBotDir, 'self.json');
        } else {
            const imgDir = path.join(process.cwd(), 'img');
            selfFilePath = path.join(imgDir, 'self.json');
        }
        if (fs.existsSync(selfFilePath)) {
            const data = fs.readFileSync(selfFilePath, 'utf-8');
            const parsed = JSON.parse(data);
            return parsed.enabled === true;
        }
    } catch (e) {}
    return false;
}

export default {
    name: 'botinfo',
    alias: ['infobot'],
    description: 'Muestra información del bot',
    category: 'main',
    
    async execute(sock, msg, { config, pushName, userNumber, replyWithContext, isOwner, isSubBot, plugins }) {
        try {
            const from = msg.key.remoteJid;
            
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // Obtener total de registros desde MongoDB
            const allUsers = await db.getAllUsers();
            const totalRegistros = allUsers ? allUsers.length : 0;
            
            let totalSubBots = 0;
            try {
                const { getConnectionStatus } = await import('../lib/sub.js');
                const status = getConnectionStatus();
                totalSubBots = status.active || 0;
            } catch (e) {
                totalSubBots = 0;
            }
            
            const isSelfMode = loadSelfStatus(sock, isSubBot);
            const selfStatus = isSelfMode ? 'Activado' : 'Desactivado';
            
            const platform = os.platform();
            const plataformas = {
                'linux': '🐧 Linux',
                'win32': '🪟 Windows',
                'darwin': '🍎 macOS',
                'android': '🤖 Android',
                'freebsd': '🔵 FreeBSD'
            };
            const plataforma = plataformas[platform] || platform;
            
            let duenoInfo = '';
            const botownerClean = config.botowner ? cleanNumber(config.botowner) : '';
            
            // Verificar si el usuario que ejecuta es el botowner
            const userNumberClean = cleanNumber(userNumber || '');
            const esBotOwner = botownerClean === userNumberClean;
            
            if (esBotOwner) {
                duenoInfo = `@${botownerClean}`;
            } else {
                duenoInfo = '*Oculto por seguridad*';
            }
            
            const bannerUrl = config.banner || '';
            const link = 'https://moonstaff.onrender.com/';
            
            let infoText = `𑇛᮫۪ᜒׁໍꤦ🍀 *Nombre* › *${config.nombre || 'No definido'}*\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ🪴 *Nombre2* › *${config.nombre2 || 'No definido'}*\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ🍟 *Moneda* › *${config.moneda}*\n\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ☁️ *Tipo* › *${config.tipo || 'principal'}*\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ🧃 *Modo Self* › *${selfStatus}*\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ⭐ *Dueño* › ${duenoInfo}\n\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ🍁 *Plataforma* › *${plataforma}*\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ🎑 *Sub-bots* › *${totalSubBots}*\n`;
            infoText += `𑇛᮫۪ᜒׁໍꤦ🍄 *Registros* › *${totalRegistros}*\n\n\n`;
            infoText += `> *Moon:* ${link}`;
            
            const ownerMention = esBotOwner && botownerClean ? [`${botownerClean}@s.whatsapp.net`] : [];
            
            if (bannerUrl) {
                try {
                    const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                    if (!uploadMethod) {
                        throw new Error('No hay método de upload disponible');
                    }
                    const { imageMessage } = await prepareWAMessageMedia(
                        { image: { url: bannerUrl } },
                        { 
                            upload: uploadMethod, 
                            mediaTypeOverride: 'thumbnail-link' 
                        }
                    );
                    const linkPreview = {
                        'canonical-url': link,
                        'matched-text': link,
                        title: config.nombre || config.name || "Sirius",
                        description: `🐝 Información del bot ${config.nombre2}`,
                        jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                        highQualityThumbnail: imageMessage || undefined
                    };
                    await sock.sendMessage(from, {
                        text: infoText,
                        linkPreview: linkPreview,
                        contextInfo: {
                            mentionedJid: ownerMention,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: '0',
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (error) {
                    console.error('Error con banner en botinfo:', error);
                    await sock.sendMessage(from, {
                        text: infoText,
                        contextInfo: {
                            mentionedJid: ownerMention,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: '0',
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            } else {
                await sock.sendMessage(from, {
                    text: infoText,
                    contextInfo: {
                        mentionedJid: ownerMention,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: '0',
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
        } catch (error) {
            console.error('Error en botinfo:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};