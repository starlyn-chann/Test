import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'leave',
    alias: ['salir', 'abandonar'],
    description: 'Hace que el bot abandone el grupo (solo dueño del bot)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { config, senderNumber, replyWithContext, isSubBot, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Limpiar números
            let userNumberClean = (senderNumber || userNumber || '').toString().replace(/\D/g, '');
            let botownerClean = config.botowner ? config.botowner.toString().replace(/\D/g, '') : '';
            
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER
            if (!botownerClean || userNumberClean !== botownerClean) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede usar este comando*`);
            }
            
            // Verificar que sea un grupo
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`《✧》 *Este comando solo puede ser usado desde un grupo*`);
            }
            
            try {
                let botName = config.nombre || config.name || 'Bot';
                
                await replyWithContext(`《✧》 *${botName} se está retirando del grupo...*`);
                
                await sock.groupLeave(from);
                
                console.log(`[LEAVE] Bot ${botName} se retiró del grupo ${from} por su dueño ${userNumberClean}`);
                
            } catch (error) {
                console.error('[LEAVE] Error:', error);
                await replyWithContext(`《✧》 *No se pudo retirar al bot del grupo*\n> ${error.message}`);
            }
            
        } catch (error) {
            console.error('Error en leave:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};