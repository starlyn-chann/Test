// ============ COMANDO PARA VER USUARIOS REGISTRADOS EN EL GRUPO ============
export default {
    name: 'grupo',
    alias: ['groupusers', 'integrantes', 'miembrosdb'],
    description: 'Muestra los usuarios registrados en la base de datos que están en este grupo',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { replyWithContext, isOwner, pushName, userNumber, args } = options;
            
            if (!isOwner) {
                return await replyWithContext('❌ *Comando restringido a propietario*');
            }
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '📊', key: msg.key } });
            } catch (e) {}
            
            // Obtener ID del grupo
            const groupId = msg.key.remoteJid;
            
            // Verificar si es un grupo
            if (!groupId.endsWith('@g.us')) {
                return await replyWithContext('❌ *Este comando solo funciona en grupos*');
            }
            
            // Obtener metadata del grupo (miembros)
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(groupId);
            } catch (error) {
                return await replyWithContext(`❌ *Error obteniendo miembros del grupo:*\n${error.message}`);
            }
            
            const miembros = groupMetadata.participants || [];
            const numerosGrupo = miembros.map(m => m.id.split('@')[0]);
            
            // Importar la base de datos
            const { getAllUsers } = await import('../lib/db.js');
            
            // Obtener todos los usuarios registrados en DB
            const allUsers = await getAllUsers();
            
            if (!allUsers || allUsers.length === 0) {
                return await replyWithContext('📊 *Base de datos vacía*\n\nNo hay usuarios registrados en la DB.');
            }
            
            // Filtrar solo los que están en el grupo
            const usuariosEnGrupo = allUsers.filter(user => {
                const numero = user.number || user._id;
                return numerosGrupo.includes(numero);
            });
            
            if (usuariosEnGrupo.length === 0) {
                return await replyWithContext(
                    `📊 *Sin usuarios registrados en este grupo*\n\n` +
                    `👥 *Miembros del grupo:* ${miembros.length}\n` +
                    `📝 *Registrados en DB:* 0\n\n` +
                    `💡 Los usuarios deben interactuar con el bot para registrarse.`
                );
            }
            
            // Ordenar por experiencia (mayor a menor)
            const sorted = [...usuariosEnGrupo].sort((a, b) => (b.exp || 0) - (a.exp || 0));
            
            // Estadísticas
            const totalMiembros = miembros.length;
            const totalRegistrados = usuariosEnGrupo.length;
            const noRegistrados = totalMiembros - totalRegistrados;
            const totalExp = usuariosEnGrupo.reduce((acc, u) => acc + (u.exp || 0), 0);
            const nivelPromedio = Math.round(usuariosEnGrupo.reduce((acc, u) => acc + (u.nivel || 1), 0) / totalRegistrados);
            
            let mensaje = `📊 *USUARIOS REGISTRADOS EN ESTE GRUPO*\n\n`;
            mensaje += `👥 *Miembros totales:* ${totalMiembros}\n`;
            mensaje += `✅ *Registrados:* ${totalRegistrados}\n`;
            mensaje += `❌ *No registrados:* ${noRegistrados}\n`;
            mensaje += `⭐ *Nivel promedio:* ${nivelPromedio}\n`;
            mensaje += `📈 *EXP total:* ${totalExp.toLocaleString()}\n\n`;
            mensaje += `━━━━━━━━━━━━━━━━━━\n\n`;
            
            // Determinar cuántos mostrar
            const mostrarTodos = args.includes('all') || args.includes('todos');
            const mostrar = mostrarTodos ? sorted : sorted.slice(0, 15);
            
            mostrar.forEach((user, i) => {
                const name = user.pushName || user.number || user._id || 'Desconocido';
                const exp = user.exp || 0;
                const nivel = user.nivel || 1;
                const cmds = user.cmds || 0;
                const number = user.number || user._id || 'N/A';
                
                const emoji = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '👤';
                
                mensaje += `${emoji} *${name}*\n`;
                mensaje += `   📱 \`${number}\`\n`;
                mensaje += `   ⭐ Nivel ${nivel} | EXP: ${exp.toLocaleString()}\n`;
                mensaje += `   📝 Comandos: ${cmds}\n\n`;
            });
            
            if (!mostrarTodos && sorted.length > 15) {
                mensaje += `\n... y ${sorted.length - 15} usuarios más.\n`;
                mensaje += `📌 Usa *${options.config?.prefix || '.'}grupo all* para ver todos.`;
            }
            
            // Lista de no registrados (opcional)
            if (args.includes('no') || args.includes('noreg')) {
                const noRegistradosLista = miembros
                    .filter(m => !usuariosEnGrupo.some(u => (u.number || u._id) === m.id.split('@')[0]))
                    .map(m => {
                        const name = m.id.split('@')[0];
                        return `• @${name}`;
                    })
                    .join('\n');
                
                mensaje += `\n\n━━━━━━━━━━━━━━━━━━\n`;
                mensaje += `❌ *NO REGISTRADOS (${noRegistrados}):*\n`;
                mensaje += noRegistradosLista || '• Todos están registrados ✅';
            }
            
            await replyWithContext(mensaje);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
        } catch (error) {
            console.error('❌ Error en grupo:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:*\n\`\`\`\n${error.stack || error.message}\n\`\`\``);
            } catch (e) {}
        }
    }
};