import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `an1_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'an1',
    alias: [],
    description: 'Busca y descarga APKs de AN1',
    category: 'download',
    
    async execute(sock, msg, options) {
        let tempPath = null;
        
        try {
            const { args, config, replyWithContext, pushName, userNumber, senderJid, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir el nombre de una aplicación\n> Ejemplo: ${config.prefix}an1 Roblox`);
            }
            
            // Verificar si es un ID (solo números)
            const isId = /^\d+$/.test(query);
            
            if (isId) {
                // Descargar directamente por ID
                try {
                    await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
                    
                    const detailUrl = `https://api-nanzz.my.id/docs/api/downloader/an1.php?id=${query}`;
                    const detailResponse = await axios.get(detailUrl, {
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    if (!detailResponse.data?.status || !detailResponse.data?.result) {
                        throw new Error('No se pudieron obtener los detalles');
                    }
                    
                    const data = detailResponse.data.result;
                    const downloadUrl = data.download_url;
                    const title = data.title || 'Sin título';
                    const version = data.version || 'N/A';
                    const developer = data.developer || 'Desconocido';
                    const size = data.size || 'N/A';
                    const androidReq = data.android_requirement || 'N/A';
                    const description = data.description || '';
                    const thumbnail = data.thumbnail || '';
                    
                    if (!downloadUrl) {
                        throw new Error('No se pudo obtener el enlace de descarga');
                    }
                    
                    const infoText = `「✰」 *${title}*\n\n` +
                                   `「✰」 *Versión:* ${version}\n` +
                                   `「✰」 *Desarrollador:* ${developer}\n` +
                                   `「✰」 *Tamaño:* ${size}\n` +
                                   `「✰」 *Android:* ${androidReq}\n` +
                                   `「✰」 *Descripción:* ${description.substring(0, 200)}...\n\n` +
                                   `「✰」 *Descargando...*`;
                    
                    if (thumbnail) {
                        try {
                            const imgResponse = await axios.get(thumbnail, {
                                responseType: 'arraybuffer',
                                timeout: 15000,
                                headers: {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                                }
                            });
                            const imgBuffer = Buffer.from(imgResponse.data);
                            
                            await sock.sendMessage(from, {
                                image: imgBuffer,
                                caption: infoText,
                                contextInfo: {
                                    mentionedJid: senderJid ? [senderJid] : [],
                                    forwardingScore: 9999999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: 0,
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        } catch (e) {
                            await replyWithContext(infoText);
                        }
                    } else {
                        await replyWithContext(infoText);
                    }
                    
                    // Descargar APK
                    const apkResponse = await axios.get(downloadUrl, {
                        responseType: 'stream',
                        timeout: 120000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                            'Referer': 'https://an1.com/'
                        }
                    });
                    
                    const extension = 'apk';
                    tempPath = getTempFilePath(extension);
                    const writer = fs.createWriteStream(tempPath);
                    
                    await new Promise((resolve, reject) => {
                        apkResponse.data.pipe(writer);
                        writer.on('finish', resolve);
                        writer.on('error', reject);
                    });
                    
                    const fileBuffer = fs.readFileSync(tempPath);
                    const cleanTitle = title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 40);
                    
                    await sock.sendMessage(from, {
                        document: fileBuffer,
                        mimetype: 'application/vnd.android.package-archive',
                        fileName: `${cleanTitle}.apk`,
                        caption: `> *${title}* (${size})`,
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    try {
                        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                    } catch (e) {}
                    
                    console.log(`✅ AN1 descargado: ${title} (${size}) por ${pushName || userNumber}`);
                    
                } catch (error) {
                    console.error('Error descargando:', error);
                    await replyWithContext(`❌ Error: ${error.message}`);
                    try {
                        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                    } catch (e) {}
                }
                return;
            }
            
            // Buscar aplicación (como spotifyplay)
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            const searchUrl = `https://api-nanzz.my.id/docs/api/search/an1.php?query=${encodeURIComponent(query)}`;
            const searchResponse = await axios.get(searchUrl, {
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                timeout: 30000
            });
            
            if (!searchResponse.data?.status || !searchResponse.data?.result?.results?.length) {
                await replyWithContext(`「✰」 No se encontraron aplicaciones para "${query}"`);
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            const results = searchResponse.data.result.results;
            
            // Crear secciones para botones (como spotifyplay)
            const rows = results.slice(0, 10).map((app) => {
                const rating = app.rating || 'N/A';
                return {
                    header: `${app.developer || 'Desconocido'}`,
                    title: `${app.title}`,
                    description: `⭐ ${rating} | ID: ${app.id}`,
                    id: `${config.prefix}an1 ${app.id}`
                };
            });
            
            const sections = [{
                title: `RESULTADOS PARA: ${query.toUpperCase()}`,
                rows: rows
            }];
            
            // Enviar thumbnail del primer resultado si existe
            const firstApp = results[0];
            if (firstApp.thumbnail) {
                try {
                    const imgResponse = await axios.get(firstApp.thumbnail, {
                        responseType: 'arraybuffer',
                        timeout: 15000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    const imgBuffer = Buffer.from(imgResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: imgBuffer,
                        caption: `「✰」 *Resultados para: ${query}*\n\nSelecciona una aplicación para descargar:`,
                        interactiveButtons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Seleccionar",
                                sections: sections
                            })
                        }],
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (e) {
                    await sock.sendMessage(from, {
                        text: `「✰」 *Resultados para: ${query}*\n\nSelecciona una aplicación para descargar:`,
                        interactiveButtons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Seleccionar",
                                sections: sections
                            })
                        }],
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            } else {
                await sock.sendMessage(from, {
                    text: `「✰」 *Resultados para: ${query}*\n\nSelecciona una aplicación para descargar:`,
                    interactiveButtons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Seleccionar",
                            sections: sections
                        })
                    }],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`📱 AN1 buscado: ${query} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en an1:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message || 'No se pudo completar la búsqueda'}`);
            } catch (e) {}
            
        } finally {
            try { if (tempPath && fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch (e) {}
        }
    }
};