import count from '#count';

export default {
    name: 'topinactive',
    alias: ['topinactivos'],
    description: 'Ver el top de usuarios más inactivos del grupo.',
    category: 'group',
    
    async execute(sock, msg, { args, config, replyWithContext, isGroup, usedPrefix }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let daysArg = args[0] ? parseInt(args[0]) : 30;
            if (daysArg < 1) daysArg = 30;
            
            // Obtener usuarios del chat
            const users = await count.getChatUsers(from);
            
            if (!users || users.length === 0) {
                return await replyWithContext(`「✎」 No hay usuarios registrados en este grupo.`);
            }
            
            const ranking = [];
            
            for (const user of users) {
                const userId = user.userId || user._id;
                if (!userId) continue;
                
                const stats = user.stats || {};
                const { totalMsgs } = count.calculateStats(stats, daysArg);
                
                ranking.push({
                    userId: userId,
                    totalMsgs
                });
            }
            
            ranking.sort((a, b) => a.totalMsgs - b.totalMsgs);
            
            const inactiveRanking = ranking.filter(u => u.totalMsgs === 0);
            
            if (inactiveRanking.length === 0) {
                return await replyWithContext(`「✎」 No hay usuarios inactivos en los últimos ${daysArg} días.`);
            }
            
            const page = parseInt(args[1]) || 1;
            const perPage = 10;
            const totalPages = Math.ceil(inactiveRanking.length / perPage);
            
            if (page < 1 || page > totalPages) {
                return await replyWithContext(`「✎」 Página inválida. Solo hay ${totalPages} páginas disponibles.`);
            }
            
            const start = (page - 1) * perPage;
            const end = Math.min(start + perPage, inactiveRanking.length);
            const pageRanking = inactiveRanking.slice(start, end);
            
            let report = `❀ Top de usuarios inactivos ❀\n`;
            report += `> » Días: \`${daysArg}\`\n`;
            report += `> » Página: \`${page}\` de \`${totalPages}\`\n\n`;
            
            const mentions = [];
            for (let i = 0; i < pageRanking.length; i++) {
                const u = pageRanking[i];
                const name = await count.getUserName(u.userId);
                const jid = u.userId + '@s.whatsapp.net';
                mentions.push(jid);
                report += `*${start + i + 1}.* ${name}\n`;
                report += `   » Mensajes: \`${count.formatNumber(u.totalMsgs)}\`\n\n`;
            }
            
            if (page < totalPages) {
                report += `\n> Para ver la siguiente página › *${config.prefix}topinactive ${daysArg} ${page + 1}*`;
            }
            
            await replyWithContext(report, mentions);
            
        } catch (error) {
            console.error('❌ Error en topinactive:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};