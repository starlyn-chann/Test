import economy from '#economy';

export default {
    name: 'chambear',
    alias: ['chamba'],
    description: 'Haz una chamba aleatoria y gana dinero',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const cooldownTime = 3 * 60 * 1000;
            
            const lastUsed = await economy.getCooldown(from, userNumber, 'chambear');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes chambear de nuevo en ${minutos}m ${segundos}s`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const ganancia = Math.floor(Math.random() * (3000 - 10 + 1)) + 10;
            
            const chambas = [
                'Caminaste perros en el parque 🐕',
                'Cuidaste niños por unas horas 👶',
                'Ayudaste a una señora a cruzar la calle 🚶‍♀️',
                'Lavaste carros en la esquina 🚗'
            ];
            
            const chamba = chambas[Math.floor(Math.random() * chambas.length)];
            
            await economy.updateUserEconomy(from, userNumber, {
                dinero: ganancia,
                nombre: pushName || 'Usuario'
            });
            
            await economy.setCooldown(from, userNumber, 'chambear');
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`❀ *Chamba realizada*\n> ${chamba}\n> *Ganaste* ${economy.formatNumber(ganancia)} ${moneda}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en chambear:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};