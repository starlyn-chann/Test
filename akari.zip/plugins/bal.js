import economy from '#economy';
import db from '#db';
import axios from 'axios';

export default {
    name: 'bal',
    alias: ['bank'],
    description: 'Ver el balance de un usuario',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, senderJid, pushName, args }) {
        try {
            const from = msg.key.remoteJid;
            
            let targetUser = userNumber;
            let targetName = pushName || 'Usuario';
            let targetJid = senderJid;
            let mentionedUser = null;
            
            // Obtener mención
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg) {
                const quotedParticipant = msg.message.extendedTextMessage.contextInfo.participant;
                if (quotedParticipant) {
                    mentionedUser = quotedParticipant;
                }
            }
            
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                const mentions = msg.message.extendedTextMessage.contextInfo.mentionedJid;
                if (mentions && mentions.length > 0) {
                    mentionedUser = mentions[0];
                }
            }
            
            if (!mentionedUser && args && args.length > 0) {
                const arg = args[0].replace(/@/g, '').replace(/\D/g, '');
                if (arg) {
                    mentionedUser = `${arg}@s.whatsapp.net`;
                }
            }
            
            if (mentionedUser) {
                let cleanMentioned = economy.cleanNumber(mentionedUser);
                targetUser = cleanMentioned;
                targetJid = mentionedUser;
                
                // Buscar el nombre en la base de datos
                const userData = await db.getUser(targetUser);
                if (userData && userData.pushName) {
                    targetName = userData.pushName;
                } else {
                    // Si no está en la DB, intentar obtener el nombre de contacto
                    try {
                        const contact = await sock.contactQuery(targetJid);
                        if (contact) {
                            targetName = contact.notify || contact.name || cleanMentioned;
                        }
                    } catch (e) {
                        targetName = cleanMentioned;
                    }
                }
            }
            
            let userEconomy = await economy.getUserEconomy(from, targetUser);
            if (!userEconomy) {
                await economy.setUserEconomy(from, targetUser, {
                    dinero: 0,
                    banco: 0,
                    nombre: targetName
                });
                userEconomy = await economy.getUserEconomy(from, targetUser);
            }
            
            const dinero = userEconomy.dinero || 0;
            const banco = userEconomy.banco || 0;
            const total = dinero + banco;
            const moneda = config.moneda || '💰';
            
            let profilePic = 'https://files.catbox.moe/kt6drf.jpeg';
            if (targetJid) {
                try {
                    const ppUrl = await sock.profilePictureUrl(targetJid, 'image');
                    if (ppUrl) profilePic = ppUrl;
                } catch (e) {}
            }
            
            let imageBuffer;
            try {
                const response = await axios.get(profilePic, { responseType: 'arraybuffer' });
                imageBuffer = Buffer.from(response.data);
            } catch (e) {
                const defaultResponse = await axios.get('https://files.catbox.moe/kt6drf.jpeg', { responseType: 'arraybuffer' });
                imageBuffer = Buffer.from(defaultResponse.data);
            }
            
            const caption = `⡞   ⃟̸̷⃨★᪲᪲᪲ *Balance :* ${targetName}

🦦ᩧ͚┸ *Billetera :* ${economy.formatNumber(dinero)} *${moneda}*
🦦ᩧ͚┸ *Banco :* ${economy.formatNumber(banco)} ${moneda}

   ᮫ׁ🌈ᩚִ𑇓𑇖ֹׁ *Total :* ${economy.formatNumber(total)} ${moneda}`;
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: caption,
                contextInfo: {
                    mentionedJid: [targetJid].filter(Boolean),
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en bal:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};