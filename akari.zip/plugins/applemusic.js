import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

// APIs de Apple Music
const API_THERESAV = 'https://api.theresav.biz.id/download/applemusic';
const API_NEXRAY = 'https://api.nexray.eu.cc/downloader/applemusic';
const API_KEY_THERESAV = 'mah7R';

export default {
    name: 'applemusic',
    alias: ['apple'],
    description: 'Descarga canciones de Apple Music',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const url = args.join(' ').trim();

            if (!url) {
                return await replyWithContext(`「✰」Debes proporcionar un link de Apple Music\n> Ejemplo: ${config.prefix}applemusic https://music.apple.com/id/album/boss-bitch/1493581254?i=1493581255`);
            }

            if (!url.includes('music.apple.com')) {
                return await replyWithContext(`《✧》El enlace proporcionado no es válido.`);
            }

            try {
                await sock.sendMessage(from, { react: { text: '🎵', key: msg.key } });
            } catch (e) {}

            let songInfo = {};
            let downloadUrl = '';

            try {
                // Intentar con API Theresav
                try {
                    const response = await axios.get(`${API_THERESAV}?url=${encodeURIComponent(url)}&apikey=${API_KEY_THERESAV}`, {
                        timeout: 60000,
                        headers: { 'User-Agent': 'Mozilla/5.0' }
                    });

                    if (response.data?.status && response.data?.result?.metadata && response.data?.result?.download?.url) {
                        const result = response.data.result;
                        songInfo = {
                            name: result.metadata.title || 'Sin título',
                            album: result.metadata.album || 'Sin álbum',
                            artist: result.metadata.artist || 'Artista desconocido',
                            type: result.type || 'song',
                            thumbnail: result.metadata.thumbnail || '',
                            duration: result.metadata.duration || 'N/A',
                            url: result.download.url || ''
                        };
                        downloadUrl = result.download.url;
                        console.log(`✅ Apple Music (Theresav): ${songInfo.name}`);
                    } else {
                        throw new Error('Theresav falló');
                    }
                } catch (theresavError) {
                    console.log('Theresav falló, usando NexRay...');
                    // Respaldo con API NexRay
                    const response = await axios.get(`${API_NEXRAY}?url=${encodeURIComponent(url)}`, {
                        timeout: 60000,
                        headers: { 'User-Agent': 'Mozilla/5.0' }
                    });

                    if (!response.data?.status || !response.data?.result) {
                        throw new Error('Respuesta inválida de NexRay');
                    }

                    const result = response.data.result;
                    songInfo = {
                        name: result.name || 'Sin título',
                        album: result.album_name || 'Sin álbum',
                        artist: result.artist || 'Artista desconocido',
                        type: result.type || 'song',
                        thumbnail: result.thumbnail || '',
                        duration: result.duration || 'N/A',
                        url: result.url || ''
                    };
                    downloadUrl = result.url;
                    console.log(`✅ Apple Music (NexRay): ${songInfo.name}`);
                }

                if (!downloadUrl) {
                    throw new Error('No se pudo obtener el enlace de descarga');
                }

            } catch (apiError) {
                console.error('❌ Error con API:', apiError.message);
                throw new Error(`No se pudo obtener la canción: ${apiError.message}`);
            }

            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}

            const audioResponse = await axios.get(downloadUrl, {
                responseType: 'arraybuffer',
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'audio/*'
                }
            });

            const audioBuffer = Buffer.from(audioResponse.data);
            const cleanTitle = songInfo.name.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
            
            let infoText = `「✰」Título: ${songInfo.name}\n`;
            infoText += `「✰」Artista: ${songInfo.artist}\n`;
            infoText += `「✰」Álbum: ${songInfo.album}\n`;
            infoText += `「✰」Duración: ${songInfo.duration}\n`;
            infoText += `「✰」Tamaño: ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB\n\n`;
            infoText += `> *Solicitado por:* ${pushName || userNumber}`;

            if (songInfo.thumbnail) {
                try {
                    const imgResponse = await axios.get(songInfo.thumbnail, { 
                        responseType: 'arraybuffer', 
                        timeout: 15000 
                    });
                    const imgBuffer = Buffer.from(imgResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: imgBuffer,
                        caption: infoText,
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (e) {
                    await sock.sendMessage(from, { text: infoText }, { quoted: msg });
                }
            } else {
                await sock.sendMessage(from, { text: infoText }, { quoted: msg });
            }

            await sock.sendMessage(from, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${cleanTitle}.mp3`,
                ptt: false,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

            console.log(`✅ Canción enviada: ${songInfo.name} por ${pushName || userNumber}`);

        } catch (error) {
            console.error('❌ Error en applemusic:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `❌ *Error:* ${error.message}`;
            if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                errorMsg += `\n\n⏰ La solicitud tardó demasiado. Por favor, intenta de nuevo.`;
            } else if (error.response?.status === 404) {
                errorMsg += `\n\n🔍 No se encontró la canción. Verifica el enlace.`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};