import db from '#db';

export default {
    name: 'delgenre',
    alias: ['delgenero', 'deletegenre'],
    description: 'Elimina tu género',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        
        if (!user?.genre) {
            return await replyWithContext(`ꕥ *No tienes un género establecido para eliminar.*`);
        }
        
        await db.updateUser(userNumber, 'genre', null);
        return await replyWithContext(`✎ *Tu género ha sido eliminado correctamente.*`);
    }
};