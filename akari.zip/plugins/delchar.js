import { 
    obtenerPersonajePorNombre, 
    obtenerPersonajePorId,
    obtenerPersonajesReclamados,
    eliminarReclamo
} from '../lib/gacha.js';

export default {
    name: 'delchar',
    alias: ['delwaifu'],
    description: 'Elimina un personaje reclamado de tu harem',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando delchar...');
            
            const { config, replyWithContext, args, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // Obtener personajes reclamados del usuario en este grupo
            const reclamados = await obtenerPersonajesReclamados(from, userNumber);
            
            if (!reclamados || reclamados.length === 0) {
                return await replyWithContext(`❀ No tienes personajes reclamados en tu harem.`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes especificar un personaje para eliminar.\n> Ejemplo » *${config.prefix}delchar Goku*`
                );
            }
            
            const nombreBuscado = args.join(' ').trim();
            
            // ============ BUSCAR PERSONAJE ============
            let personaje = await obtenerPersonajePorNombre(nombreBuscado);
            
            // Si no se encuentra, buscar por nombre invertido
            if (!personaje) {
                const palabras = nombreBuscado.trim().split(/\s+/);
                if (palabras.length > 1) {
                    const nombreInvertido = palabras.reverse().join(' ');
                    personaje = await obtenerPersonajePorNombre(nombreInvertido);
                }
            }
            
            // Si no se encuentra, buscar por coincidencia parcial
            if (!personaje) {
                const { obtenerTodosPersonajes } = await import('../lib/gacha.js');
                const todos = await obtenerTodosPersonajes();
                const nombreLower = nombreBuscado.toLowerCase();
                
                for (const pj of todos) {
                    const pjNombreLower = pj.nombre.toLowerCase();
                    if (pjNombreLower.includes(nombreLower) || nombreLower.includes(pjNombreLower)) {
                        personaje = pj;
                        break;
                    }
                }
            }
            
            if (!personaje) {
                return await replyWithContext(
                    `ꕥ No se ha encontrado ningún personaje con el nombre *${nombreBuscado}*`
                );
            }
            // ================================================================
            
            // Verificar que el personaje esté reclamado por el usuario
            const reclamo = reclamados.find(r => r.personajeId === personaje.id);
            
            if (!reclamo) {
                return await replyWithContext(`ꕥ *${personaje.nombre}* no está reclamado por ti.`);
            }
            
            // ============ ELIMINAR RECLAMO ============
            const eliminado = await eliminarReclamo(from, personaje.id);
            
            if (!eliminado) {
                return await replyWithContext(`❌ Error al eliminar el personaje.`);
            }
            // ================================================================
            
            await replyWithContext(`❀ *${personaje.nombre}* ha sido eliminado de tu lista de reclamados.`);
            
            console.log(`✅ delchar ejecutado: ${pushName || userNumber} eliminó a ${personaje.nombre}`);
            
        } catch (error) {
            console.error('❌ Error en delchar:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};