import economy from '#economy';

export default {
    name: 'with',
    alias: ['retirar'],
    description: 'Retira dinero del banco',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName, args }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Debes especificar una cantidad\n> Ejemplo: ${config.prefix}with 1000\n> ${config.prefix}with all`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const bancoActual = userEconomy.banco || 0;
            
            let cantidad = 0;
            if (args[0].toLowerCase() === 'all') {
                cantidad = bancoActual;
            } else {
                cantidad = parseInt(args[0]);
                if (isNaN(cantidad) || cantidad <= 0) {
                    return await replyWithContext(`「✰」 Cantidad inválida\n> Debes ingresar un número positivo`);
                }
            }
            
            if (cantidad === 0) {
                return await replyWithContext(`❀ *No tienes dinero en el banco para retirar*`);
            }
            
            if (cantidad > bancoActual) {
                return await replyWithContext(`❀ *No tienes suficiente dinero en el banco*\n> Banco: ${economy.formatNumber(bancoActual)} ${config.moneda}`);
            }
            
            await economy.updateUserEconomy(from, userNumber, {
                banco: -cantidad,
                dinero: cantidad,
                nombre: pushName || 'Usuario'
            });
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`❀ *Retiro exitoso*\n> Has retirado ${economy.formatNumber(cantidad)} ${config.moneda} del banco\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${config.moneda}\n*Banco:* ${economy.formatNumber(updatedEconomy.banco)} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en with:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};