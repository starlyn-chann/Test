import count from '#count';

export default {
    name: 'topcount',
    alias: ['topmensajes'],
    description: 'Ver el top de usuarios con más mensajes en el grupo.',
    category: 'group',
    
    async execute(sock, msg, { args, config, replyWithContext, isGroup, usedPrefix }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const daysArg = args[0] ? parseInt(args[0]) : 7;
            if (daysArg < 1) {
                return await replyWithContext(`「✎」 El número de días debe ser mayor a 0.`);
            }
            
            // Obtener usuarios del chat
            const users = await count.getChatUsers(from);
            
            if (!users || users.length === 0) {
                return await replyWithContext(`「✎」 No hay usuarios registrados en este grupo.`);
            }
            
            const ranking = [];
            
            for (const user of users) {
                const userId = user.userId || user._id;
                if (!userId) continue;
                
                const stats = user.stats || {};
                const { totalMsgs, totalCmds } = count.calculateStats(stats, daysArg);
                
                if (totalMsgs > 0) {
                    ranking.push({
                        userId: userId,
                        totalMsgs,
                        totalCmds
                    });
                }
            }
            
            ranking.sort((a, b) => b.totalMsgs - a.totalMsgs);
            
            if (ranking.length === 0) {
                return await replyWithContext(`「✎」 No hay actividad registrada en los últimos ${daysArg} días.`);
            }
            
            const page = parseInt(args[1]) || 1;
            const perPage = 10;
            const totalPages = Math.ceil(ranking.length / perPage);
            
            if (page < 1 || page > totalPages) {
                return await replyWithContext(`「✎」 Página inválida. Solo hay ${totalPages} páginas disponibles.`);
            }
            
            const start = (page - 1) * perPage;
            const end = Math.min(start + perPage, ranking.length);
            const pageRanking = ranking.slice(start, end);
            
            let report = `❀ Top de mensajes en los últimos *${daysArg}* día${daysArg > 1 ? 's' : ''}\n\n`;
            
            const mentions = [];
            for (let i = 0; i < pageRanking.length; i++) {
                const u = pageRanking[i];
                const name = await count.getUserName(u.userId);
                const jid = u.userId + '@s.whatsapp.net';
                mentions.push(jid);
                report += `*${start + i + 1}.* ${name}\n`;
                report += `   » Mensajes: \`${count.formatNumber(u.totalMsgs)}\`, Comandos: \`${count.formatNumber(u.totalCmds)}\`\n\n`;
            }
            
            report += `> *Página ${page} de ${totalPages}*`;
            
            if (page < totalPages) {
                report += `\n> Para ver la siguiente página › *${config.prefix}topcount ${daysArg} ${page + 1}*`;
            }
            
            await replyWithContext(report, mentions);
            
        } catch (error) {
            console.error('❌ Error en topcount:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};