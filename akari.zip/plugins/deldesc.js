import db from '#db';

export default {
    name: 'deldescription',
    alias: ['deldesc', 'deletedescription'],
    description: 'Elimina tu descripción',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        
        if (!user?.description) {
            return await replyWithContext(`✐ *No tienes una descripción establecida para eliminar.*`);
        }
        
        await db.updateUser(userNumber, 'description', null);
        return await replyWithContext(`✐ *Tu descripción ha sido eliminada correctamente.*`);
    }
};