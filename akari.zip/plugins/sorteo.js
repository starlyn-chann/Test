export default {
    name: 'sorteo',
    alias: ['sortear', 'raffle'],
    description: 'Realiza un sorteo aleatorio entre los participantes del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, pushName, userNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Verificar que se haya proporcionado qué sortear
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Debes especificar qué quieres sortear\n> Ejemplo: ${config.prefix}sorteo Una suscripción de Netflix`);
            }
            
            const cosaSorteada = args.join(' ');
            
            try {
                await sock.sendMessage(from, { react: { text: '🎲', key: msg.key } });
            } catch (e) {}
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Obtener participantes (excluyendo al bot)
            const botJid = sock.user?.id?.split(':')[0] + '@s.whatsapp.net' || '';
            const participants = groupMetadata.participants
                .filter(p => p.id !== botJid)
                .map(p => p.id);
            
            if (participants.length === 0) {
                return await replyWithContext(`「✰」 No hay participantes en el grupo`);
            }
            
            // Seleccionar ganador aleatorio
            const ganadorJid = participants[Math.floor(Math.random() * participants.length)];
            const ganadorName = groupMetadata.participants.find(p => p.id === ganadorJid)?.name || ganadorJid.split('@')[0];
            
            // Construir mensaje
            const mensaje = `「 𝗦𝗼𝗿𝘁𝗲𝗼 」\n\n` +
                          `*Sorteado ›* ${cosaSorteada}\n` +
                          `*Ganador ›* @${ganadorJid.split('@')[0]}`;
            
            // Enviar mensaje con mención
            await sock.sendMessage(from, {
                text: mensaje,
                mentions: [ganadorJid],
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '🎉', key: msg.key } });
            } catch (e) {}
            
            console.log(`🎲 Sorteo realizado por ${pushName || userNumber}: "${cosaSorteada}" - Ganador: ${ganadorName}`);
            
        } catch (error) {
            console.error('❌ Error en sorteo:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};