import { obtenerPersonajePorNombre, obtenerPersonajePorTag } from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROLES_FILE = path.join(__dirname, '..', 'data', 'roles.json');

function loadRoles() {
    try {
        if (fs.existsSync(ROLES_FILE)) {
            const data = fs.readFileSync(ROLES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando roles:', error);
    }
    return {};
}

function tieneRol(userNumber, rolesPermitidos) {
    const roles = loadRoles();
    const userData = roles[userNumber];
    if (!userData) return false;
    return rolesPermitidos.includes(userData.rol);
}

export default {
    name: 'tags',
    alias: ['settags', 'cambiartag', 'editartag'],
    description: 'Cambia el tag de uno o varios personajes (Owners, Sub-owners y Mods)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando tags...');
            
            const { args, config, replyWithContext, userNumber, isOwner } = options;
            
            // Verificar si es owner o tiene rol permitido
            const tieneRolPermitido = tieneRol(userNumber, ['sub-owner', 'mod']);
            
            if (!isOwner && !tieneRolPermitido) {
                return; // No responder nada, silencioso
            }
            
            if (args.length === 0) {
                return await replyWithContext(
                    `❀ *CAMBIAR TAG DE PERSONAJE(S)*\n\n` +
                    `📌 *Formato (1 personaje):*\n` +
                    `${config.prefix}tags <nombre del personaje> / <nuevo tag>\n\n` +
                    `📌 *Formato (múltiples personajes):*\n` +
                    `${config.prefix}tags <nombre> / <nuevo tag>\n` +
                    `<nombre> / <nuevo tag>\n` +
                    `<nombre> / <nuevo tag>\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}tags Goku / goku_ssj\n` +
                    `Shinobu Kochou / shinobu_kochou\n\n` +
                    `📌 *El tag se usa para buscar imágenes en Danbooru*`
                );
            }
            
            const texto = args.join(' ');
            const lineas = texto.split('\n').filter(line => line.trim());
            
            const resultados = [];
            const errores = [];
            let actualizados = 0;
            let fallidos = 0;
            
            for (const linea of lineas) {
                const partes = linea.split('/').map(p => p.trim());
                
                if (partes.length !== 2) {
                    errores.push(`❌ Formato incorrecto: "${linea}"`);
                    fallidos++;
                    continue;
                }
                
                const [nombreBuscado, nuevoTag] = partes;
                
                if (!nombreBuscado || !nuevoTag) {
                    errores.push(`❌ Datos incompletos: "${linea}"`);
                    fallidos++;
                    continue;
                }
                
                // ============ BUSCAR PERSONAJE ============
                let personaje = await obtenerPersonajePorNombre(nombreBuscado);
                
                // Si no se encuentra, buscar por nombre invertido
                if (!personaje) {
                    const palabras = nombreBuscado.trim().split(/\s+/);
                    if (palabras.length > 1) {
                        const nombreInvertido = palabras.reverse().join(' ');
                        personaje = await obtenerPersonajePorNombre(nombreInvertido);
                    }
                }
                
                // Si no se encuentra, buscar por coincidencia parcial
                if (!personaje) {
                    const { obtenerTodosPersonajes } = await import('../lib/gacha.js');
                    const todos = await obtenerTodosPersonajes();
                    const nombreLower = nombreBuscado.toLowerCase();
                    
                    for (const pj of todos) {
                        const pjNombreLower = pj.nombre.toLowerCase();
                        if (pjNombreLower.includes(nombreLower) || nombreLower.includes(pjNombreLower)) {
                            personaje = pj;
                            break;
                        }
                    }
                }
                
                if (!personaje) {
                    errores.push(`❌ No se encontró el personaje: "${nombreBuscado}"`);
                    fallidos++;
                    continue;
                }
                // ================================================================
                
                // ============ VERIFICAR QUE EL NUEVO TAG NO ESTÉ EN USO ============
                const tagLower = nuevoTag.toLowerCase().replace(/\s+/g, '_');
                const existeTag = await obtenerPersonajePorTag(tagLower);
                
                if (existeTag && existeTag.id !== personaje.id) {
                    errores.push(`❌ Tag "${tagLower}" ya está en uso por "${existeTag.nombre}"`);
                    fallidos++;
                    continue;
                }
                // ================================================================
                
                // ============ ACTUALIZAR TAG ============
                const { actualizarTagPersonaje } = await import('../lib/gacha.js');
                const actualizado = await actualizarTagPersonaje(personaje.id, tagLower);
                
                if (actualizado) {
                    actualizados++;
                    resultados.push(`✅ "${personaje.nombre}" → ${tagLower}`);
                } else {
                    fallidos++;
                    errores.push(`❌ Error al actualizar tag de "${personaje.nombre}"`);
                }
                // ================================================================
            }
            
            // ============ CREAR MENSAJE DE RESPUESTA ============
            let mensaje = `❀ *RESULTADOS*\n\n`;
            
            if (resultados.length > 0) {
                mensaje += `✅ *Actualizados:*\n${resultados.join('\n')}\n\n`;
            }
            
            if (errores.length > 0) {
                mensaje += `❌ *Errores:*\n${errores.join('\n')}\n\n`;
            }
            
            mensaje += `📊 *Resumen:*\n`;
            mensaje += `✅ Actualizados: ${actualizados}\n`;
            if (fallidos > 0) mensaje += `❌ Fallidos: ${fallidos}`;
            
            await replyWithContext(mensaje);
            
            const rol = isOwner ? 'OWNER' : (tieneRolPermitido ? 'MOD/SUB-OWNER' : '');
            console.log(`✅ tags ejecutado por ${rol}: ${actualizados} actualizados, ${fallidos} fallidos`);
            // ================================================================
            
        } catch (error) {
            console.error('❌ Error en tags:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};