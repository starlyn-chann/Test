import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    name: 'tag',
    alias: [],
    description: 'Menciona a todos los miembros del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, senderJid, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Verificar si el usuario que ejecuta el comando es administrador
            const senderCleanJid = senderJid.split(':')[0].split('@')[0];
            const senderParticipant = groupMetadata.participants.find(p => p.id.includes(senderCleanJid));
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            if (!isSenderAdmin) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para poder usar este comando`);
            }
            
            // Verificar si hay un mensaje citado
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            // Si NO hay mensaje citado Y NO hay texto
            if (!quotedMsg && args.length === 0) {
                return await replyWithContext(`「✰」 Debes proporcionar un texto o responder a un mensaje`);
            }
            
            // Obtener todos los participantes del grupo (excluyendo al bot)
            const botJid = sock.user?.id.split(':')[0].split('@')[0];
            const participants = groupMetadata.participants
                .filter(p => !p.id.includes(botJid))
                .map(p => p.id.split(':')[0].split('@')[0] + '@s.whatsapp.net');
            
            if (quotedMsg) {
                // ============ REENVIAR EXACTAMENTE EL MENSAJE CITADO CON MENCIONES ============
                
                // Texto plano
                if (quotedMsg.conversation) {
                    const originalText = quotedMsg.conversation;
                    
                    await sock.sendMessage(from, {
                        text: originalText,
                        mentions: participants
                    });
                }
                // Texto extendido
                else if (quotedMsg.extendedTextMessage?.text) {
                    const originalText = quotedMsg.extendedTextMessage.text;
                    
                    await sock.sendMessage(from, {
                        text: originalText,
                        mentions: participants
                    });
                }
                // Imagen
                else if (quotedMsg.imageMessage) {
                    const mediaBuffer = await downloadMediaMessage(
                        { message: { imageMessage: quotedMsg.imageMessage } },
                        'buffer',
                        { logger: console }
                    );
                    const originalCaption = quotedMsg.imageMessage.caption || '';
                    
                    await sock.sendMessage(from, {
                        image: mediaBuffer,
                        caption: originalCaption,
                        mentions: participants
                    });
                }
                // Video
                else if (quotedMsg.videoMessage) {
                    const mediaBuffer = await downloadMediaMessage(
                        { message: { videoMessage: quotedMsg.videoMessage } },
                        'buffer',
                        { logger: console }
                    );
                    const originalCaption = quotedMsg.videoMessage.caption || '';
                    
                    await sock.sendMessage(from, {
                        video: mediaBuffer,
                        caption: originalCaption,
                        mimetype: quotedMsg.videoMessage.mimetype,
                        mentions: participants
                    });
                }
                // Audio
                else if (quotedMsg.audioMessage) {
                    const mediaBuffer = await downloadMediaMessage(
                        { message: { audioMessage: quotedMsg.audioMessage } },
                        'buffer',
                        { logger: console }
                    );
                    
                    await sock.sendMessage(from, {
                        audio: mediaBuffer,
                        mimetype: quotedMsg.audioMessage.mimetype,
                        ptt: quotedMsg.audioMessage.ptt || false,
                        mentions: participants
                    });
                }
                // Documento
                else if (quotedMsg.documentMessage) {
                    const mediaBuffer = await downloadMediaMessage(
                        { message: { documentMessage: quotedMsg.documentMessage } },
                        'buffer',
                        { logger: console }
                    );
                    const originalCaption = quotedMsg.documentMessage.caption || '';
                    
                    await sock.sendMessage(from, {
                        document: mediaBuffer,
                        caption: originalCaption,
                        mimetype: quotedMsg.documentMessage.mimetype,
                        fileName: quotedMsg.documentMessage.fileName,
                        mentions: participants
                    });
                }
                // Sticker
                else if (quotedMsg.stickerMessage) {
                    const mediaBuffer = await downloadMediaMessage(
                        { message: { stickerMessage: quotedMsg.stickerMessage } },
                        'buffer',
                        { logger: console }
                    );
                    
                    await sock.sendMessage(from, {
                        sticker: mediaBuffer,
                        mentions: participants
                    });
                }
                // Contacto
                else if (quotedMsg.contactMessage) {
                    await sock.sendMessage(from, {
                        contacts: {
                            displayName: quotedMsg.contactMessage.displayName,
                            contacts: quotedMsg.contactMessage.vcards || []
                        },
                        mentions: participants
                    });
                }
                // Ubicación
                else if (quotedMsg.locationMessage) {
                    await sock.sendMessage(from, {
                        location: {
                            degreesLatitude: quotedMsg.locationMessage.degreesLatitude,
                            degreesLongitude: quotedMsg.locationMessage.degreesLongitude
                        },
                        mentions: participants
                    });
                }
                // Si no se reconoce el tipo, solo enviar menciones
                else {
                    await sock.sendMessage(from, {
                        text: ' ',
                        mentions: participants
                    });
                }
                
            } else if (args.length > 0) {
                // ============ ENVIAR TEXTO CON MENCIONES ============
                const originalText = args.join(' ');
                
                await sock.sendMessage(from, {
                    text: originalText,
                    mentions: participants
                });
            }
            
            console.log(`✅ Tag enviado por ${pushName || userNumber} en grupo ${from} - ${participants.length} miembros mencionados`);
            
        } catch (error) {
            console.error('❌ Error en tag:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};