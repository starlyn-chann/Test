import economy from '#economy';

export default {
    name: 'aventura',
    alias: ['av', 'adventure'],
    description: 'Ve de aventura y gana o pierde dinero',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const cooldownTime = 3 * 60 * 1000;
            
            const lastUsed = await economy.getCooldown(from, userNumber, 'aventura');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes ir de aventura de nuevo en ${minutos}m ${segundos}s`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const esGanancia = Math.random() < 0.7;
            let cantidad = 0;
            
            const aventurasGanar = [
                'Encontraste un tesoro escondido en una cueva 🏴‍☠️',
                'Un comerciante te regaló una bolsa de monedas 💰',
                'Ganaste una apuesta en el casino 🎲'
            ];
            
            const aventurasPerder = [
                'Te robaron en un callejón oscuro 🦹',
                'Perdiste una apuesta en el póker 🎲',
                'Tuviste un accidente y pagaste reparaciones 🚗'
            ];
            
            let aventura = '';
            let resultado = '';
            
            if (esGanancia) {
                cantidad = Math.floor(Math.random() * (5000 - 50 + 1)) + 50;
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: cantidad,
                    nombre: pushName || 'Usuario'
                });
                aventura = aventurasGanar[Math.floor(Math.random() * aventurasGanar.length)];
                resultado = `★ *Ganaste* ${economy.formatNumber(cantidad)} ${config.moneda}`;
            } else {
                cantidad = Math.floor(Math.random() * (2000 - 10 + 1)) + 10;
                const dineroActual = userEconomy.dinero || 0;
                if (dineroActual >= cantidad) {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -cantidad,
                        nombre: pushName || 'Usuario'
                    });
                } else {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -dineroActual,
                        nombre: pushName || 'Usuario'
                    });
                    cantidad = dineroActual;
                }
                aventura = aventurasPerder[Math.floor(Math.random() * aventurasPerder.length)];
                resultado = `★ *Perdiste* ${economy.formatNumber(cantidad)} ${config.moneda}`;
            }
            
            await economy.setCooldown(from, userNumber, 'aventura');
            
            await replyWithContext(`❀ *Aventura*\n> ${aventura}\n> ${resultado}`);
            
        } catch (error) {
            console.error('❌ Error en aventura:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};