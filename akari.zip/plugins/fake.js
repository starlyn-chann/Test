function copy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

export default {
    name: 'fake',
    alias: ['fakereply'],
    description: 'Crea una respuesta falsa',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, senderJid, isGroup, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const text = args.join(' ');
            
            if (!text) {
                return await replyWithContext(`「✰」 Uso del comando\n\n*${config.prefix}fake* hola que? @${senderJid.split('@')[0]} nada y tu`);
            }
            
            let cm = copy(msg);
            let who;
            
            if (text.includes('@0')) {
                who = '0@s.whatsapp.net';
            } else if (isGroup) {
                const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
                if (mentionedJid && mentionedJid.length > 0) {
                    who = mentionedJid[0];
                } else {
                    who = senderJid;
                }
            } else {
                who = from;
            }
            
            if (!who) {
                return await replyWithContext(`「✰」 Uso del comando\n\n*${config.prefix}fake* hola que? @${senderJid.split('@')[0]} nada y tu`);
            }
            
            cm.key.fromMe = false;
            cm.message = { ...msg.message };
            
            const sp = '@' + who.split('@')[0];
            const [fake, ...real] = text.split(sp);
            
            // Crear respuesta falsa
            await sock.sendMessage(from, {
                text: real.join(sp).trimStart(),
                contextInfo: {
                    mentionedJid: [who],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: { key: { remoteJid: from, fromMe: false, participant: who, id: 'fake_' + Date.now() }, message: { conversation: fake.trimEnd() } } });
            
            console.log(`✅ Fake reply creado por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en fake:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};