import axios from 'axios';

export default {
    name: 'fb',
    alias: ['facebook', 'fbdl'],
    description: 'Descarga videos de publicaciones de Facebook',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            if (!args || !args.length) {
                return await replyWithContext(`「✰」 *Debes proporcionar un enlace de Facebook*\n> Ejemplo: ${config.prefix}fb https://facebook.com/...`);
            }
            
            const url = args[0].trim();
            
            if (!url.match(/facebook\.com|fb\.watch|video\.fb\.com|fb\.com/)) {
                return await replyWithContext(`「✰」 *Enlace inválido*\n\n> Envía un enlace de Facebook válido`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // ============ API NEXRAY ============
            const apiUrl = `https://api.nexray.eu.cc/downloader/facebook?url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl, { timeout: 30000 });
            
            if (!response.data?.status) {
                return await replyWithContext(`🌽 No se pudo obtener contenido del enlace`);
            }
            
            const result = response.data.result;
            const titulo = result.title || 'Sin título';
            const videoHd = result.video_hd;
            const videoSd = result.video_sd;
            const audio = result.audio;
            
            // Seleccionar mejor calidad (HD > SD)
            const videoUrl = videoHd || videoSd;
            const calidad = videoHd ? 'HD' : 'SD';
            
            if (!videoUrl) {
                return await replyWithContext(`🌽 No se pudo obtener el video`);
            }
            
            // Enviar información primero
            const infoText = `「✰」Título » ${titulo}\n「✰」Calidad » ${calidad}`;
            
            await replyWithContext(infoText);
            
            // Descargar y enviar el video
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            const videoResponse = await axios.get(videoUrl, { responseType: 'arraybuffer', timeout: 120000 });
            const videoBuffer = Buffer.from(videoResponse.data);
            
            await sock.sendMessage(from, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: `【 ✰ 】 *Calidad* » ${calidad}\n【 ✰ 】 *Plataforma* » Facebook`,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Facebook video descargado por ${pushName || userNumber} (${calidad})`);
            
        } catch (error) {
            console.error('❌ Error en fb:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};