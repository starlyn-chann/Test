import economy from '#economy';

export default {
    name: 'w',
    alias: ['work'],
    description: 'Trabaja y gana dinero en el grupo',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const cooldownTime = 3 * 60 * 1000;
            
            const lastUsed = await economy.getCooldown(from, userNumber, 'work');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes trabajar de nuevo en ${minutos}m ${segundos}s`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const ganancia = Math.floor(Math.random() * (3000 - 10 + 1)) + 10;
            
            const trabajos = [
                'Trabajaste como desarrollador web',
                'Trabajaste como diseñador gráfico',
                'Trabajaste como escritor creativo',
                'Trabajaste como profesor de matemáticas'
            ];
            
            const trabajo = trabajos[Math.floor(Math.random() * trabajos.length)];
            
            await economy.updateUserEconomy(from, userNumber, {
                dinero: ganancia,
                nombre: pushName || 'Usuario'
            });
            
            await economy.setCooldown(from, userNumber, 'work');
            
            await replyWithContext(`❀ *Trabajaste*\n> ${trabajo}\n> *Ganaste* ${economy.formatNumber(ganancia)} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en w:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};