import { downloadMediaMessage } from '@whiskeysockets/baileys';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `gpbanner_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function getCleanJid(jid) {
    if (!jid) return '';
    const number = jid.split(':')[0].split('@')[0].replace(/\D/g, '');
    return `${number}@s.whatsapp.net`;
}

export default {
    name: 'setgpbanner',
    alias: ['setgppic', 'gpbanner'],
    description: 'Cambia la foto del grupo (solo admins)',
    category: 'group',
    
    async execute(sock, msg, options) {
        let inputPath = null;
        
        try {
            const { config, isGroup, senderJid, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Verificar si hay imagen (respondida o enviada directamente)
            let imageMessage = null;
            let stanzaId = null;
            let participant = null;
            
            // Caso 1: Mensaje citado con imagen
            if (quotedMessage) {
                const messageType = Object.keys(quotedMessage)[0];
                if (messageType === 'imageMessage') {
                    imageMessage = quotedMessage.imageMessage;
                    stanzaId = quotedMsg.stanzaId;
                    participant = quotedMsg.participant || senderJid;
                }
            }
            
            // Caso 2: Mensaje enviado directamente con imagen
            if (!imageMessage) {
                const msgType = Object.keys(msg.message || {})[0];
                if (msgType === 'imageMessage') {
                    imageMessage = msg.message.imageMessage;
                    stanzaId = msg.key.id;
                    participant = senderJid;
                }
            }
            
            if (!imageMessage) {
                return await replyWithContext(`《✧》 Te faltó la imagen para cambiar el perfil del grupo.\n> Responde a una imagen con ${config.prefix}setgpbanner`);
            }
            
            // Verificar admin del usuario
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            const senderCleanJid = getCleanJid(senderJid);
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid || p.id === senderCleanJid);
            const isAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            if (!isAdmin) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para cambiar la foto`);
            }
            
            // Verificar que el bot sea admin
            const botJid = sock.user?.id;
            const botCleanJid = getCleanJid(botJid);
            const botParticipant = groupMetadata.participants.find(p => p.id === botJid || p.id === botCleanJid);
            const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
            
            if (!isBotAdmin) {
                return await replyWithContext(`「✰」 El bot debe ser administrador del grupo para cambiar la foto`);
            }
            
            // Descargar imagen
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: stanzaId || msg.key.id,
                    participant: participant || senderJid,
                    fromMe: false
                },
                message: {
                    imageMessage: imageMessage
                }
            };
            
            const imgBuffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            if (!imgBuffer || imgBuffer.length === 0) {
                return await replyWithContext(`《✧》 No se pudo descargar la imagen.`);
            }
            
            // Cambiar la foto del grupo directamente sin redimensionar
            await sock.updateProfilePicture(from, imgBuffer);
            
            await replyWithContext(`✿ La imagen del grupo se actualizó con éxito.`);
            
        } catch (error) {
            console.error('❌ Error en setgpbanner:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`> Error: ${error.message}`);
            } catch (e) {}
            
        } finally {
            try { if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch (e) {}
        }
    }
};