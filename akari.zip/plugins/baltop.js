import economy from '#economy';

export default {
    name: 'baltop',
    alias: ['topcoins', 'rank'],
    description: 'Muestra el top de usuarios con más coins en el grupo',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, args }) {
        try {
            const from = msg.key.remoteJid;
            const moneda = config.moneda || '💰';
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const economyData = await economy.getAllEconomyUsers(from);
            if (!economyData || Object.keys(economyData).length === 0) {
                return await replyWithContext(`❀ *No hay usuarios registrados en este grupo*`);
            }
            
            let pagina = 1;
            if (args && args.length > 0) {
                const num = parseInt(args[0]);
                if (!isNaN(num) && num > 0) {
                    pagina = num;
                }
            }
            
            const USUARIOS_POR_PAGINA = 10;
            
            const usuarios = [];
            for (const [userId, data] of Object.entries(economyData)) {
                const total = (data.dinero || 0) + (data.banco || 0);
                usuarios.push({
                    id: userId,
                    nombre: data.nombre || userId,
                    total: total
                });
            }
            
            usuarios.sort((a, b) => b.total - a.total);
            
            const totalUsuarios = usuarios.length;
            const totalPaginas = Math.ceil(totalUsuarios / USUARIOS_POR_PAGINA);
            
            if (pagina > totalPaginas) {
                return await replyWithContext(`❀ *Página no válida*\n> Hay ${totalPaginas} páginas disponibles`);
            }
            
            const inicio = (pagina - 1) * USUARIOS_POR_PAGINA;
            const fin = Math.min(inicio + USUARIOS_POR_PAGINA, totalUsuarios);
            const usuariosPagina = usuarios.slice(inicio, fin);
            
            let mensaje = `❀ 𝗧𝗼𝗽 𝗖𝗼𝗶𝗻𝘀\n\n`;
            
            for (let i = 0; i < usuariosPagina.length; i++) {
                const user = usuariosPagina[i];
                const posicion = inicio + i + 1;
                mensaje += `♡ ${posicion} » ${user.nombre}\n`;
                mensaje += `> *${economy.formatNumber(user.total)} ${moneda}*\n\n`;
            }
            
            mensaje += `> *Lista (${pagina}) de (${totalPaginas})*`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en baltop:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};