import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para la verificación de NSFW
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Función para cargar la configuración de los grupos
function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

export default {
    name: 'xnxx',
    alias: ['xxx'],
    description: 'Descarga videos de xnxx',
    category: 'nsfw',

    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, isGroup } = options;
            const from = msg.key.remoteJid;
            const url = args[0];

            // --- VALIDACIÓN NSFW ---
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------

            if (!url) {
                return await replyWithContext(`♡ Por favor, ingresa un enlace de XNXX\n> Uso: ${config.prefix}xnxx [enlace]`);
            }

            // 1. Reacción de búsqueda
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}

            console.log(`🔍 Consultando API Delirius para XNXX...`);

            // 2. Consulta a la API de descarga (xnxxdl)
            const apiUrl = `https://api.delirius.store/download/xnxxdl?url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const res = response.data;

            if (!res.status || !res.data) {
                throw new Error('La API no devolvió datos válidos.');
            }

            const videoData = res.data;
            const downloadUrl = videoData.download.low; 
            const thumb = videoData.gallery.thumb69;
            const title = videoData.title || 'Video XNXX';
            const quality = videoData.quality || 'N/A';

            // 3. Enviar primero la información con la thumb
            const infoText = `🌼 *XNXX DOWNLOADER*\n\n` +
                          `「✰」Título » ${title}\n` +
                          `「✰」Calidad » ${quality}\n\n` +
                          `> *Enviando video...*`;

            if (thumb) {
                try {
                    const thumbResponse = await axios.get(thumb, { responseType: 'arraybuffer', timeout: 15000 });
                    const thumbBuffer = Buffer.from(thumbResponse.data);

                    await sock.sendMessage(from, {
                        image: thumbBuffer,
                        caption: infoText,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (thumbError) {
                    await replyWithContext(infoText);
                }
            } else {
                await replyWithContext(infoText);
            }

            // 4. ENVÍO DEL VIDEO
            await sock.sendMessage(from, {
                video: { url: downloadUrl },
                mimetype: 'video/mp4',
                caption: `[ ★ ] ${title}`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

            console.log(`✅ XNXX descargado por ${pushName || userNumber}`);

        } catch (error) {
            console.error('❌ Error en xnxx:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                const { replyWithContext } = options;
                await replyWithContext(`♡ Ocurrió un error: ${error.message}`);
            } catch (e) {}
        }
    }
};