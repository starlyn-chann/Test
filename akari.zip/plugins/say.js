import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    name: 'say',
    alias: ['decir'],
    description: 'Repite un mensaje o reenvía multimedia en el grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Obtener todos los miembros del grupo para menciones
            let allMentions = [];
            if (isGroup) {
                try {
                    const groupMetadata = await sock.groupMetadata(from);
                    allMentions = groupMetadata.participants.map(p => p.id);
                } catch (err) {
                    console.log('Error obteniendo participantes del grupo:', err.message);
                }
            }
            
            const userText = args.join(' ').trim();
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            let hasImage = false;
            let hasVideo = false;
            let hasAudio = false;
            let hasSticker = false;
            let mediaBuffer = null;
            let originalText = '';
            
            if (quotedMessage) {
                if (quotedMessage.imageMessage) {
                    hasImage = true;
                    originalText = quotedMessage.imageMessage.caption || '';
                } else if (quotedMessage.videoMessage) {
                    hasVideo = true;
                    originalText = quotedMessage.videoMessage.caption || '';
                } else if (quotedMessage.audioMessage) {
                    hasAudio = true;
                } else if (quotedMessage.stickerMessage) {
                    hasSticker = true;
                } else if (quotedMessage.conversation) {
                    originalText = quotedMessage.conversation;
                } else if (quotedMessage.extendedTextMessage?.text) {
                    originalText = quotedMessage.extendedTextMessage.text;
                }
            }
            
            const textToCheck = userText || originalText || '';
            
            // Buscar menciones en el texto
            const explicitMentions = [];
            if (textToCheck && allMentions.length > 0) {
                for (const jid of allMentions) {
                    const number = jid.split('@')[0];
                    if (textToCheck.includes(number)) {
                        explicitMentions.push(jid);
                    }
                }
            }
            
            const optionsMessage = {
                contextInfo: {
                    mentionedJid: explicitMentions.length ? explicitMentions : (isGroup ? [] : [senderJid]),
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            };
            
            // Si hay imagen o video citado
            if (hasImage || hasVideo) {
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        [hasImage ? 'imageMessage' : 'videoMessage']: hasImage ? quotedMessage.imageMessage : quotedMessage.videoMessage
                    }
                };
                
                mediaBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
                
                if (hasImage) {
                    await sock.sendMessage(from, {
                        image: mediaBuffer,
                        caption: textToCheck || '',
                        ...optionsMessage
                    }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, {
                        video: mediaBuffer,
                        mimetype: 'video/mp4',
                        caption: textToCheck || '',
                        ...optionsMessage
                    }, { quoted: msg });
                }
                return;
            }
            
            // Si hay audio citado
            if (hasAudio) {
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        audioMessage: quotedMessage.audioMessage
                    }
                };
                
                mediaBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
                
                await sock.sendMessage(from, {
                    audio: mediaBuffer,
                    mimetype: 'audio/mp4',
                    fileName: 'audio.mp3',
                    ...optionsMessage
                }, { quoted: msg });
                return;
            }
            
            // Si hay sticker citado
            if (hasSticker) {
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        stickerMessage: quotedMessage.stickerMessage
                    }
                };
                
                mediaBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
                
                await sock.sendMessage(from, {
                    sticker: mediaBuffer,
                    ...optionsMessage
                }, { quoted: msg });
                return;
            }
            
            // Si hay texto
            if (textToCheck) {
                await sock.sendMessage(from, {
                    text: textToCheck,
                    ...optionsMessage
                }, { quoted: msg });
                return;
            }
            
            // Si no hay nada
            await replyWithContext(`《✧》 Por favor, escribe el texto que deseas repetir.`);
            
        } catch (error) {
            console.error('❌ Error en say:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};