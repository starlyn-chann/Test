import db from '#db';

export default {
    name: 'setdescription',
    alias: ['setdesc'],
    description: 'Establece o elimina tu descripción',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        const input = args.join(' ');

        // Eliminar descripción
        if (input === 'delete' || input === 'eliminar' || input === 'remove') {
            if (!user?.description) {
                return await replyWithContext(`✐ *No tienes una descripción establecida para eliminar.*`);
            }
            
            await db.updateUser(userNumber, 'description', null);
            return await replyWithContext(`✐ *Tu descripción ha sido eliminada correctamente.*`);
        }

        if (user?.description) {
            return await replyWithContext(`✐ Ya tienes una descripción. Usa › *${config.prefix}setdescription delete* para eliminarla.`);
        }

        if (!input) {
            return await replyWithContext('《✧》 Debes especificar una descripción válida.');
        }

        await db.updateUser(userNumber, 'description', input);
        return await replyWithContext(`✐ Se ha establecido tu descripción:\n> *${input}*`);
    }
};