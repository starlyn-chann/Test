import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para la verificación de NSFW
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Función para cargar la configuración de los grupos
function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

export default {
    name: 'onlyfans',
    alias: [],
    description: 'Envía contenido aleatorio de OnlyFans',
    category: 'nsfw',

    async execute(sock, msg, options) {
        const { config, pushName, userNumber, replyWithContext, isGroup } = options;
        const from = msg.key.remoteJid;

        try {
            // --- VALIDACIÓN NSFW ---
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------

            // 1. Reacción inicial
            try {
                await sock.sendMessage(from, { react: { text: '🔞', key: msg.key } });
            } catch (e) {}

            // 2. URL de la API (Al ser imagen directa, la usamos directamente en el mensaje)
            const apiUrl = `https://api.theresav.biz.id/asupan/onlyfans?apikey=mah7R`;

            // 3. Envío del mensaje
            // Usamos un timestamp para evitar que WhatsApp use una imagen en caché y siempre mande una nueva
            await sock.sendMessage(from, {
                image: { url: `${apiUrl}&t=${Date.now()}` },
                caption: `> Solicitado por ${pushName || 'usuario'}`,
                footer: config.canalNombre || 'Made By StarLyn',
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // 4. Reacción de éxito
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

        } catch (error) {
            console.error('❌ Error en comando onlyfans:', error);
            try {
                await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`❌ Error al obtener la imagen. Inténtalo de nuevo.`);
            } catch (e) {}
        }
    }
};