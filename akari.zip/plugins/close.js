export default {
    name: 'close',
    alias: ['cerrar'],
    description: 'Cerrar el grupo para que solo admins puedan enviar mensajes',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { isGroup, replyWithContext, config } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            const senderParticipant = groupMetadata.participants.find(p => p.id === options.senderJid);
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            if (!isSenderAdmin) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para poder usar este comando`);
            }
            
            if (groupMetadata.announce === true) {
                return await replyWithContext(`《✧》 El grupo ya estaba cerrado`);
            }
            
            try {
                await sock.groupSettingUpdate(from, 'announcement');
                await replyWithContext(`✿ El grupo ha sido cerrado correctamente.`);
                console.log(`✅ Grupo ${from} cerrado por ${options.pushName || options.userNumber}`);
            } catch (error) {
                return await replyWithContext(`✿ *${config.nombre}* debe ser administrador del grupo`);
            }
            
        } catch (error) {
            console.error('❌ Error en close:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};