export default {
    name: 'ping',
    alias: ['p'],
    description: 'Mide la latencia del bot',
    category: 'info',
    
    async execute(sock, msg, { replyWithContext }) {
        try {
            const start = Date.now();
            
            // Enviar mensaje inicial
            const sent = await sock.sendMessage(msg.key.remoteJid, { 
                text: '`★ ¡Pong!`' 
            }, { quoted: msg });
            
            // Calcular latencia
            const latency = Date.now() - start;
            
            // Editar el mensaje con la latencia
            await sock.sendMessage(msg.key.remoteJid, {
                text: `✿ *Pong!*\n> Tiempo ⴵ ${latency}ms`,
                edit: sent.key
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en ping:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};