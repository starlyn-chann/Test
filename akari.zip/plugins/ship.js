export default {
    name: 'ship',
    alias: ['calcularamor'],
    description: 'Calcula el amor entre dos personas (solo en grupos)',
    category: 'fun',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber, senderJid, isGroup } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos.`);
            }
            
            // Obtener el usuario mencionado
            let targetUserJid = null;
            let targetUserNumber = null;
            
            // Verificar mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetUserJid = mentionedJid[0];
                targetUserNumber = targetUserJid.split('@')[0];
            }
            
            // Verificar mensaje citado
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!targetUserJid && quotedMsg) {
                targetUserJid = msg.message.extendedTextMessage.contextInfo.participant;
                targetUserNumber = targetUserJid?.split('@')[0];
            }
            
            if (!targetUserJid) {
                return await replyWithContext(`「✰」 Debes mencionar a un usuario con @ para calcular el amor.\n\nEjemplo: ${config.prefix}ship @usuario`);
            }
            
            // Obtener nombres
            const user1Name = pushName || userNumber;
            
            let user2Name = targetUserNumber;
            try {
                const contactName = await sock.getName(targetUserJid);
                user2Name = contactName || targetUserNumber;
            } catch (e) {
                user2Name = targetUserNumber;
            }
            
            // Calcular porcentaje de amor (aleatorio)
            const lovePercentage = Math.floor(Math.random() * 101);
            
            // Determinar mensaje según el porcentaje
            let mensajeAmor = "";
            if (lovePercentage <= 10) {
                mensajeAmor = "💔 Mejor ni lo intenten...";
            } else if (lovePercentage <= 20) {
                mensajeAmor = "💔 Son como agua y aceite";
            } else if (lovePercentage <= 30) {
                mensajeAmor = "💔 Muy difícil que funcione";
            } else if (lovePercentage <= 40) {
                mensajeAmor = "💗 Hay una pequeña posibilidad";
            } else if (lovePercentage <= 50) {
                mensajeAmor = "💗 Podrían intentarlo";
            } else if (lovePercentage <= 60) {
                mensajeAmor = "💖 Tienen potencial";
            } else if (lovePercentage <= 70) {
                mensajeAmor = "💖 Se llevan bastante bien";
            } else if (lovePercentage <= 80) {
                mensajeAmor = "💕 Son una linda pareja";
            } else if (lovePercentage <= 90) {
                mensajeAmor = "💕 Casi el amor perfecto";
            } else {
                mensajeAmor = "💞 ¡Almas gemelas! 💞";
            }
            
            // Construir mensaje
            const loveMessage = `💖 *${user1Name}* tu oportunidad de enamorarte de *${user2Name}* es de *${lovePercentage}%* 💖\n\n> ${mensajeAmor}`;
            
            // Enviar resultado
            await sock.sendMessage(from, {
                text: loveMessage,
                mentions: [senderJid, targetUserJid],
                contextInfo: {
                    mentionedJid: [senderJid, targetUserJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`💖 Ship calculado por ${pushName || userNumber}: ${user1Name} y ${user2Name} = ${lovePercentage}%`);
            
        } catch (error) {
            console.error('❌ Error en ship:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`🌸 Error al calcular el amor: ${error.message}`);
            } catch (e) {}
        }
    }
};