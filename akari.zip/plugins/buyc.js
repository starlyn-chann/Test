import { 
    obtenerPersonajePorId,
    reclamarPersonaje,
    eliminarReclamo
} from '../lib/gacha.js';
import economy from '#economy';
import db from '#db';

export default {
    name: 'buyc',
    alias: ['buycharacter', 'buychar', 'comprar'],
    description: 'Comprar un personaje en venta',
    category: 'gacha',
    
    async execute(sock, msg, { config, replyWithContext, args, userNumber, senderJid, pushName }) {
        try {
            console.log('🚀 Ejecutando comando buyc...');
            
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes especificar un personaje para comprar.\n> Ejemplo: ${config.prefix}buyc Goku`
                );
            }
            
            const nombrePersonaje = args.join(' ').trim();
            
            // ============ OBTENER VENTAS DEL GRUPO ============
            const chat = await db.getChat(from);
            const sales = chat?.sales || {};
            
            if (!sales || Object.keys(sales).length === 0) {
                return await replyWithContext(`ꕥ No hay personajes en venta en este grupo.`);
            }
            
            let ventaEncontrada = null;
            let idEncontrado = null;
            
            for (const [id, venta] of Object.entries(sales)) {
                if (venta.nombre && venta.nombre.toLowerCase() === nombrePersonaje.toLowerCase()) {
                    ventaEncontrada = venta;
                    idEncontrado = id;
                    break;
                }
            }
            
            if (!ventaEncontrada) {
                return await replyWithContext(`ꕥ No se encontró el personaje *${nombrePersonaje}* en venta.`);
            }
            
            // ============ VERIFICAR QUE NO SEA SU PROPIO PERSONAJE ============
            if (ventaEncontrada.usuario === userNumber) {
                return await replyWithContext(`ꕥ No puedes comprar tu propio personaje.`);
            }
            
            // ============ VERIFICAR EXPIRACIÓN (3 DÍAS) ============
            const ahora = Date.now();
            const expiracion = 3 * 86400000;
            
            if (ahora - ventaEncontrada.tiempo >= expiracion) {
                delete sales[idEncontrado];
                await db.updateChat(from, 'sales', sales);
                return await replyWithContext(`ꕥ La venta de *${ventaEncontrada.nombre}* ha expirado.`);
            }
            
            // ============ VERIFICAR SALDO DEL COMPRADOR ============
            let compradorEconomy = await economy.getUserEconomy(from, userNumber);
            if (!compradorEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                compradorEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const saldo = compradorEconomy.dinero || 0;
            
            if (saldo < ventaEncontrada.precio) {
                return await replyWithContext(
                    `ꕥ No tienes suficiente *${config.moneda}* para comprar a *${ventaEncontrada.nombre}*.\n` +
                    `> Necesitas *${economy.formatNumber(ventaEncontrada.precio)} ${config.moneda}*`
                );
            }
            
            // ============ OBTENER NOMBRE DEL VENDEDOR ============
            let vendedorNombre = ventaEncontrada.usuario;
            const vendedorUser = await db.getUser(ventaEncontrada.usuario);
            if (vendedorUser) {
                vendedorNombre = vendedorUser.pushName || ventaEncontrada.usuario;
            }
            
            // ============ REALIZAR COMPRA ============
            // Transferir dinero (restar al comprador)
            await economy.updateUserEconomy(from, userNumber, {
                dinero: -ventaEncontrada.precio,
                nombre: pushName || 'Usuario'
            });
            
            // Transferir dinero (sumar al vendedor)
            await economy.updateUserEconomy(from, ventaEncontrada.usuario, {
                dinero: ventaEncontrada.precio,
                nombre: vendedorNombre
            });
            
            // Transferir personaje
            await eliminarReclamo(from, idEncontrado);
            await reclamarPersonaje(from, idEncontrado, userNumber);
            
            // Eliminar de ventas
            delete sales[idEncontrado];
            await db.updateChat(from, 'sales', sales);
            
            const compradorNombre = pushName || userNumber;
            
            const mensaje = 
`❀ *${ventaEncontrada.nombre}* ha sido comprado por *${compradorNombre}*!
> Se han transferido *${economy.formatNumber(ventaEncontrada.precio)} ${config.moneda}* a *${vendedorNombre}*`;

            await replyWithContext(mensaje);
            
            console.log(`✅ buyc ejecutado: ${compradorNombre} compró ${ventaEncontrada.nombre} por ${ventaEncontrada.precio}`);
            
        } catch (error) {
            console.error('❌ Error en buyc:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};