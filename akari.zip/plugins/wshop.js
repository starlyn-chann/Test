import { obtenerPersonajePorId } from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SALES_FILE = path.join(__dirname, '..', 'data', 'sales.json');

function loadSales() {
    try {
        if (fs.existsSync(SALES_FILE)) {
            const data = fs.readFileSync(SALES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando ventas:', e);
    }
    return {};
}

function saveSales(sales) {
    try {
        fs.writeFileSync(SALES_FILE, JSON.stringify(sales, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando ventas:', e);
        return false;
    }
}

function loadUsersDb() {
    try {
        const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function getDisplayName(number) {
    const users = loadUsersDb();
    const user = users.find(u => u.number === number);
    return user ? user.pushName : number;
}

export default {
    name: 'wshop',
    alias: ['tienda', 'haremshop'],
    description: 'Ver los personajes en venta en el grupo',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando wshop...');
            
            const { config, replyWithContext, args } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const sales = loadSales();
            
            if (!sales[from] || Object.keys(sales[from]).length === 0) {
                return await replyWithContext(`ꕥ No hay personajes en venta en este grupo.`);
            }
            
            // ============ LIMPIAR VENTAS EXPIRADAS (3 DIAS) ============
            const ahora = Date.now();
            const expiracion = 3 * 86400000; // 3 días
            let cambios = false;
            
            for (const [id, venta] of Object.entries(sales[from])) {
                if (ahora - venta.tiempo >= expiracion) {
                    delete sales[from][id];
                    cambios = true;
                }
            }
            
            if (cambios) {
                saveSales(sales);
            }
            // ================================================================
            
            const ventas = Object.entries(sales[from] || {});
            
            if (ventas.length === 0) {
                return await replyWithContext(`ꕥ No hay personajes en venta en este grupo.`);
            }
            
            // ============ PAGINACIÓN ============
            const page = parseInt(args[0]) || 1;
            const porPagina = 10;
            const totalPaginas = Math.ceil(ventas.length / porPagina);
            
            if (page < 1 || page > totalPaginas) {
                return await replyWithContext(`ꕥ Página inválida. Solo hay *${totalPaginas}* páginas disponibles.`);
            }
            
            const inicio = (page - 1) * porPagina;
            const fin = Math.min(inicio + porPagina, ventas.length);
            const ventasPagina = ventas.slice(inicio, fin);
            // ================================================================
            
            let mensaje = `*☆ HaremShop \\≧◠ᴥ◠≦/*\n`;
            mensaje += `❏ Personajes en venta <${ventas.length}>:\n\n`;
            
            for (const [id, venta] of ventasPagina) {
                const personaje = await obtenerPersonajePorId(id);
                const valor = personaje ? personaje.valor : 0;
                const tiempoRestante = expiracion - (ahora - venta.tiempo);
                const d = Math.floor(tiempoRestante / 86400000);
                const h = Math.floor((tiempoRestante % 86400000) / 3600000);
                const m = Math.floor((tiempoRestante % 3600000) / 60000);
                const s = Math.floor((tiempoRestante % 60000) / 1000);
                const vendedor = getDisplayName(venta.usuario);
                
                mensaje += `❀ *${venta.nombre}* (✰ ${valor.toLocaleString()}):\n`;
                mensaje += `⛁ Precio » *${venta.precio.toLocaleString()} ${config.moneda}*\n`;
                mensaje += `❖ Vendedor » *${vendedor}*\n`;
                mensaje += `ⴵ Expira en » *${d}d ${h}h ${m}m ${s}s*\n\n`;
            }
            
            mensaje += `> • Paginá *${page}* de *${totalPaginas}*`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en wshop:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};