import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

async function uploadToUguu(buffer, filename) {
    const form = new FormData();
    form.append('files[]', buffer, filename);

    try {
        const res = await axios.post('https://uguu.se/upload', form, {
            headers: {
                ...form.getHeaders()
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            timeout: 60000
        });

        if (res.data && res.data.success && res.data.files && res.data.files[0]) {
            return res.data.files[0].url;
        }

        throw new Error('Respuesta inválida de uguu.se');
    } catch (error) {
        console.error('Error subiendo a uguu.se:', error.response?.data || error.message);
        throw error;
    }
}

async function uploadToCatboxByUrl(url) {
    try {
        const form = new FormData();
        form.append('reqtype', 'urlupload');
        form.append('userhash', '0c3e78aeb2c067f3520f900de');
        form.append('url', url);

        const res = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 60000
        });

        if (typeof res.data === 'string' && res.data.startsWith('https://')) {
            return res.data.trim();
        }

        throw new Error(`Respuesta inválida: ${JSON.stringify(res.data)}`);
    } catch (error) {
        console.error('Error subiendo a Catbox por URL:', error.response?.data || error.message);
        throw error;
    }
}

export default {
    name: 'tourl',
    alias: ['toupload', 'upload', 'subir'],
    description: 'Sube imágenes, GIFs o videos a Catbox (vía uguu.se)',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!quotedMsg?.quotedMessage) {
                return await replyWithContext(`⭐ Responde a una imagen, GIF o video\n\n> Ejemplo: Responde a una imagen con ${config.prefix}tourl`);
            }

            const quotedMessage = quotedMsg.quotedMessage;
            const isImage = quotedMessage.imageMessage;
            const isVideo = quotedMessage.videoMessage;
            
            if (!isImage && !isVideo) {
                return await replyWithContext(`⭐ Solo se permiten imágenes, GIFs o videos`);
            }
            
            const media = isImage || isVideo;
            let type = 'image';
            let mime = 'image/jpeg';
            let filename = 'image.jpg';
            
            if (isImage) {
                type = 'image';
                mime = media.mimetype || 'image/jpeg';
                const ext = mime.split('/')[1] || 'jpg';
                filename = `image_${Date.now()}.${ext}`;
            } else if (isVideo) {
                const videoMime = media.mimetype || 'video/mp4';
                if (videoMime.includes('gif')) {
                    type = 'gif';
                    mime = videoMime;
                    filename = `gif_${Date.now()}.gif`;
                } else {
                    type = 'video';
                    mime = videoMime;
                    const ext = videoMime.split('/')[1] || 'mp4';
                    filename = `video_${Date.now()}.${ext}`;
                }
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
            } catch (e) {}
            
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg.stanzaId,
                    participant: quotedMsg.participant || from,
                    fromMe: false
                },
                message: {
                    [isVideo ? 'videoMessage' : 'imageMessage']: media
                }
            };
            
            const buffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            if (!buffer || buffer.length === 0) {
                throw new Error('No se pudo descargar el archivo');
            }
            
            const maxSize = 100 * 1024 * 1024;
            
            if (buffer.length > maxSize) {
                return await replyWithContext(`⭐ El archivo es demasiado grande (${formatSize(buffer.length)})\n> Máx: 100MB para uguu.se`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '☁️', key: msg.key } });
            } catch (e) {}
            
            console.log(`📤 Subiendo archivo a uguu.se (tipo: ${type}, tamaño: ${formatSize(buffer.length)})`);
            const uguuUrl = await uploadToUguu(buffer, filename);
            console.log(`✅ Subido a uguu.se: ${uguuUrl}`);
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            console.log(`📥 Subiendo a Catbox desde URL...`);
            const catboxUrl = await uploadToCatboxByUrl(uguuUrl);
            console.log(`✅ Subido a Catbox: ${catboxUrl}`);
            
            const emoji = type === 'image' ? '📷' : type === 'gif' ? '🎞️' : '🎬';
            const tipoTexto = type === 'image' ? 'Imagen' : type === 'gif' ? 'GIF' : 'Video';
            
            const desc = `﹒︵͡⏜ ᅟ︵͡⏜
﹒ ─ ‎ ‎‎ ‎ 사랑 ‎ *TOURL* ‎ ‎‎ ‎ ‎ᰍ ׅ

✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *URL* » ${catboxUrl}
✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *Servidor* » Catbox (vía uguu.se)
✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *Tipo* » ${emoji} ${tipoTexto}
✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *Tamaño* » ${formatSize(buffer.length)}`;

            if (type === 'image') {
                await sock.sendMessage(from, { 
                    image: buffer, 
                    caption: desc,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { 
                    video: buffer, 
                    gifPlayback: type === 'gif',
                    caption: desc,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Tourl: ${type} subido a Catbox (vía uguu.se) (${formatSize(buffer.length)}) por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en tourl:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}`);
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};