import economy from '#economy';

export default {
    name: 'fish',
    alias: ['pescar'],
    description: 'Pesca un pez y gana dinero',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const cooldownTime = 4 * 60 * 1000; // 4 minutos
            
            // Verificar cooldown
            const lastUsed = await economy.getCooldown(from, userNumber, 'fish');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes pescar de nuevo en ${minutos}m ${segundos}s`);
            }
            
            // Obtener economía del usuario
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            // 75% éxito, 25% fracaso
            const exito = Math.random() < 0.75;
            
            const peces = [
                { nombre: '🐟 Trucha', min: 500, max: 2000 },
                { nombre: '🐠 Salmón', min: 800, max: 3000 },
                { nombre: '🐡 Pez globo', min: 300, max: 1500 },
                { nombre: '🐋 Atún', min: 2000, max: 7000 },
                { nombre: '🐊 Pez espada', min: 3000, max: 8000 },
                { nombre: '🐟 Trucha', min: 500, max: 2000 },
                { nombre: '🐠 Salmón', min: 800, max: 3000 },
                { nombre: '🐡 Pez globo', min: 300, max: 1500 },
                { nombre: '🐋 Atún', min: 2000, max: 7000 },
                { nombre: '🐊 Pez espada', min: 3000, max: 8000 },
                { nombre: '🐬 Delfín', min: 4000, max: 10000 },
                { nombre: '🐙 Pulpo', min: 1500, max: 4000 },
                { nombre: '🦈 Tiburón', min: 5000, max: 15000 },
                { nombre: '🐟 Trucha', min: 500, max: 2000 },
                { nombre: '🐠 Salmón', min: 800, max: 3000 }
            ];
            
            const pez = peces[Math.floor(Math.random() * peces.length)];
            const ganancia = Math.floor(Math.random() * (pez.max - pez.min + 1)) + pez.min;
            
            let mensaje = '';
            
            if (exito) {
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: ganancia,
                    nombre: pushName || 'Usuario'
                });
                
                mensaje = `❀ *Pesca exitosa* 🎣\n> Has pescado un *${pez.nombre}*\n> *Ganaste* ${economy.formatNumber(ganancia)} ${moneda}`;
            } else {
                const perdida = Math.floor(Math.random() * (300 - 50 + 1)) + 50;
                const dineroActual = userEconomy.dinero || 0;
                
                if (dineroActual >= perdida) {
                    await economy.updateUserEconomy(from, userNumber, {
                        dinero: -perdida,
                        nombre: pushName || 'Usuario'
                    });
                    mensaje = `❀ *Pesca fallida* 😔👉👈\n> El *${pez.nombre}* se escapó y perdiste ${economy.formatNumber(perdida)} ${moneda}`;
                } else {
                    mensaje = `❀ *Pesca fallida* 😔👉👈\n> El *${pez.nombre}* se escapó, pero no tenías dinero para perder`;
                }
            }
            
            // Guardar cooldown
            await economy.setCooldown(from, userNumber, 'fish');
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`${mensaje}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy?.dinero || 0)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en fish:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};