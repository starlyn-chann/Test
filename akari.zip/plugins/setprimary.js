import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const cleanNumber = (num) => num ? num.toString().replace(/[^0-9]/g, '') : '';
const PRIMARIOS_FILE = path.join(process.cwd(), 'databases', 'primarios.json');

if (!fs.existsSync(path.join(process.cwd(), 'databases'))) {
    fs.mkdirSync(path.join(process.cwd(), 'databases'), { recursive: true });
}

function getBotName(botNumber) {
    try {
        const subDir = path.join(process.cwd(), 'subs', botNumber);
        const subConfigPath = path.join(subDir, 'config.js');
        if (fs.existsSync(subConfigPath)) {
            const content = fs.readFileSync(subConfigPath, 'utf8');
            const match = content.match(/nombre:\s*['"]([^'"]+)['"]/);
            if (match && match[1]) return match[1];
        }
        return 'Bot';
    } catch (error) {
        return 'Bot';
    }
}

function getPrimaryBot(groupId) {
    try {
        if (fs.existsSync(PRIMARIOS_FILE)) {
            const data = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
            return data[groupId] || null;
        }
    } catch (e) {}
    return null;
}

function savePrimaryBot(groupId, botNumber, botName) {
    try {
        let data = {};
        if (fs.existsSync(PRIMARIOS_FILE)) {
            data = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
        }
        data[groupId] = {
            botNumber: botNumber,
            botName: botName,
            updated: Date.now()
        };
        fs.writeFileSync(PRIMARIOS_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando bot primario:', e);
        return false;
    }
}

function deletePrimaryBot(groupId) {
    try {
        if (fs.existsSync(PRIMARIOS_FILE)) {
            const data = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
            if (data[groupId]) {
                delete data[groupId];
                fs.writeFileSync(PRIMARIOS_FILE, JSON.stringify(data, null, 2));
                return true;
            }
        }
    } catch (e) {}
    return false;
}

export default {
    name: 'setprimary',
    alias: ['primary', 'botprimario'],
    description: 'Establece un bot primario en el grupo (solo administradores)',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, senderJid, pushName, userNumber, args } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid);
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            const isOwner = config.owner?.some(owner => cleanNumber(owner) === cleanNumber(userNumber));
            
            if (!isSenderAdmin && !isOwner) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para usar este comando`);
            }
            
            // Obtener sub-bots activos
            let activeSubBots = [];
            try {
                const { getSubs } = await import('../lib/sub.js');
                const subs = getSubs();
                if (subs) {
                    subs.forEach((_, number) => {
                        activeSubBots.push(cleanNumber(number));
                    });
                }
            } catch (e) {}
            
            // Obtener premium bots activos
            let activePremiumBots = [];
            try {
                const premModule = await import('../lib/prem.js');
                if (premModule && premModule.getPremiums) {
                    const prems = premModule.getPremiums();
                    if (prems) {
                        prems.forEach((_, number) => {
                            activePremiumBots.push(cleanNumber(number));
                        });
                    }
                }
            } catch (e) {}
            
            // También buscar premiums en carpeta
            try {
                const premsSessionsPath = path.join(process.cwd(), 'Sessions', 'prems');
                if (fs.existsSync(premsSessionsPath)) {
                    const premFolders = fs.readdirSync(premsSessionsPath).filter(folder => {
                        const folderPath = path.join(premsSessionsPath, folder);
                        return fs.statSync(folderPath).isDirectory() && /^\d+$/.test(folder);
                    });
                    for (const folder of premFolders) {
                        const credsPath = path.join(premsSessionsPath, folder, 'creds.json');
                        if (fs.existsSync(credsPath)) {
                            const number = cleanNumber(folder);
                            if (!activePremiumBots.includes(number)) {
                                activePremiumBots.push(number);
                            }
                        }
                    }
                }
            } catch (e) {}
            
            // Obtener número del bot actual
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // Identificar bots en el grupo
            const botsInGroup = [];
            const processedNumbers = new Set();
            
            for (const participant of groupMetadata.participants) {
                const participantNumber = cleanNumber(participant.id);
                
                if (processedNumbers.has(participantNumber)) continue;
                
                const isSubBot = activeSubBots.includes(participantNumber);
                const isPremiumBot = activePremiumBots.includes(participantNumber);
                const isMainBot = participantNumber === currentBotNumber;
                
                if (isSubBot || isPremiumBot || isMainBot) {
                    let botName = getBotName(participantNumber);
                    let botType = 'Bot';
                    
                    if (isMainBot) {
                        botType = 'Principal';
                    } else if (isPremiumBot) {
                        botType = 'Premium ⭐';
                    } else if (isSubBot) {
                        botType = 'Sub';
                    }
                    
                    botsInGroup.push({
                        number: participantNumber,
                        jid: participant.id,
                        name: botName,
                        type: botType,
                        isCurrent: isMainBot
                    });
                    
                    processedNumbers.add(participantNumber);
                }
            }
            
            if (botsInGroup.length === 0) {
                return await replyWithContext(`「✰」 No hay bots disponibles en este grupo`);
            }
            
            // Verificar si se quiere eliminar el bot primario
            const argsLower = args[0]?.toLowerCase();
            if (argsLower === 'off' || argsLower === 'remove' || argsLower === 'eliminar') {
                const currentPrimary = getPrimaryBot(from);
                if (!currentPrimary) {
                    return await replyWithContext(`「✰」 No hay un bot primario configurado en este grupo`);
                }
                
                deletePrimaryBot(from);
                return await replyWithContext(`《✧》 Bot primario eliminado\n> Ahora todos los bots pueden responder en el grupo`);
            }
            
            // Obtener el usuario objetivo
            let targetJid = null;
            let targetNumber = null;
            
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
                targetNumber = cleanNumber(targetJid);
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!targetJid && quotedMsg?.participant) {
                targetJid = quotedMsg.participant;
                targetNumber = cleanNumber(targetJid);
            }
            
            if (!targetJid && args && args.length > 0) {
                const searchNumber = cleanNumber(args[0]);
                const foundBot = botsInGroup.find(b => b.number === searchNumber);
                if (foundBot) {
                    targetNumber = foundBot.number;
                    targetJid = foundBot.jid;
                }
            }
            
            if (targetJid && targetNumber) {
                const targetBot = botsInGroup.find(b => b.number === targetNumber);
                
                if (!targetBot) {
                    return await replyWithContext(`「✰」 El bot ${targetNumber} no está en este grupo`);
                }
                
                savePrimaryBot(from, targetBot.number, targetBot.name);
                
                const typeLabel = targetBot.type;
                
                await replyWithContext(`《✧》 @${targetBot.number} (${typeLabel}) ha sido establecido como bot primario\n> Solo este bot responderá en el grupo`, 
                    [`${targetBot.number}@s.whatsapp.net`]);
                
                console.log(`✅ Bot primario ${targetBot.number} (${typeLabel}) establecido en grupo ${cleanNumber(from)} por ${pushName || userNumber}`);
                return;
            }
            
            // Mostrar lista desplegable de bots
            const rows = botsInGroup.map(bot => ({
                title: `${bot.type} ${bot.name} | ${bot.number}`,
                description: bot.isCurrent ? `✅ Bot actual` : `🔄 Establecer como primario`,
                id: `${config.prefix}setprimary ${bot.number}`
            }));
            
            const sections = [{
                title: "🤖 BOTS EN ESTE GRUPO",
                rows: rows
            }];
            
            await sock.sendMessage(from, {
                text: "🏮 *Selecciona el bot primario*\n\nElige qué bot será el único que responderá en este grupo.\n\n*Para eliminar el bot primario usa:*\n> `setprimary off`",
                footer: config.nombre || config.name,
                interactiveButtons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "🤖 Ver bots disponibles",
                            sections: sections
                        })
                    }
                ]
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en setprimary:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};