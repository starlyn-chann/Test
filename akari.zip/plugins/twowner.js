import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERHASH = '7eac01ee208c76d5f57056c68';

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `twowner_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime, filename) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', USERHASH);
    form.append('fileToUpload', buffer, { filename: filename || generateUniqueFilename(mime) });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    if (typeof res.data !== 'string' || !res.data.startsWith('https://')) {
        throw new Error('Respuesta inválida de Catbox');
    }
    return res.data;
}

const APIS = [
    {
        name: 'OotaIzumi',
        url: 'https://api.ootaizumi.web.id/downloader/twitter',
        getMedia: (data) => {
            if (!data.status || !data.result || data.result.length === 0) return null;
            return data.result.map(item => ({
                type: item.type === 'image' ? 'photo' : item.type,
                link: item.link
            }));
        }
    },
    {
        name: 'NexRay',
        url: 'https://api.nexray.web.id/downloader/twitter',
        getMedia: (data) => {
            if (!data.status || !data.result) return null;
            const downloadUrls = data.result.download_url || [];
            if (downloadUrls.length === 0) return null;
            return downloadUrls.map(item => ({
                type: item.type === 'image' ? 'photo' : 'video',
                link: item.url
            }));
        }
    }
];

export default {
    name: 'twowner',
    alias: ['xtwitter', 'xowner'],
    description: 'Descarga imágenes y videos de Twitter/X y los sube a Catbox (solo owner)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, pushName, userNumber, isOwner } = options;
            const from = msg.key.remoteJid;
            
            // Solo owner puede usar este comando
            if (!isOwner) {
                return await replyWithContext(`๑ֵ݊🍀 El comando \`${config.prefix}twowner\` no existe.\n> Usa ${config.prefix}help para ver mis comandos`);
            }
            
            const url = args.join(' ').trim();
            
            if (!url) {
                return await replyWithContext(`「✰」 Debes proporcionar un enlace de Twitter/X\n> Ejemplo: ${config.prefix}twowner https://twitter.com/...`);
            }
            
            if (!url.includes('twitter.com') && !url.includes('x.com')) {
                return await replyWithContext(`「✰」 Eso no parece ser un enlace de Twitter/X válido`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            let mediaItems = null;
            
            for (const api of APIS) {
                try {
                    const response = await axios.get(api.url, {
                        params: { url: url },
                        timeout: 30000,
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    mediaItems = api.getMedia(response.data);
                    
                    if (mediaItems && mediaItems.length > 0) {
                        console.log(`✅ ${mediaItems.length} archivos encontrados con ${api.name}`);
                        break;
                    }
                    
                } catch (error) {
                    console.log(`⚠️ API ${api.name} falló: ${error.message}`);
                    continue;
                }
            }
            
            if (!mediaItems || mediaItems.length === 0) {
                throw new Error('No se pudo obtener el contenido');
            }
            
            // Separar imágenes y videos
            const photos = mediaItems.filter(item => (item.type === 'photo' || item.type === 'image') && item.link);
            const videos = mediaItems.filter(item => item.type === 'video' && item.link);
            
            if (photos.length === 0 && videos.length === 0) {
                return await replyWithContext(`「✰」 No se encontraron imágenes ni videos en este enlace`);
            }
            
            const totalItems = photos.length + videos.length;
            await replyWithContext(`☁️ *Subiendo ${totalItems} archivos a Catbox...*`);
            
            const uploadedItems = [];
            
            // Subir imágenes
            for (let i = 0; i < photos.length; i++) {
                const photoUrl = photos[i].link;
                try {
                    const imageResponse = await axios.get(photoUrl, {
                        responseType: 'arraybuffer',
                        timeout: 30000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const imageBuffer = Buffer.from(imageResponse.data);
                    const mime = 'image/jpeg';
                    
                    if (imageBuffer.length > 10 * 1024 * 1024) {
                        uploadedItems.push(`❌ Imagen ${i + 1}: Demasiado grande (${formatSize(imageBuffer.length)})`);
                        continue;
                    }
                    
                    const link = await uploadCatbox(imageBuffer, mime, `image_${Date.now()}_${i}.jpg`);
                    uploadedItems.push({ type: '📷 Imagen', link });
                    
                } catch (err) {
                    console.log(`Error subiendo imagen ${i + 1}:`, err.message);
                    uploadedItems.push({ type: '📷 Imagen', link: `❌ Error: ${err.message}` });
                }
            }
            
            // Subir videos
            for (let i = 0; i < videos.length; i++) {
                const videoUrl = videos[i].link;
                try {
                    const videoResponse = await axios.get(videoUrl, {
                        responseType: 'arraybuffer',
                        timeout: 60000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const videoBuffer = Buffer.from(videoResponse.data);
                    const mime = 'video/mp4';
                    
                    if (videoBuffer.length > 200 * 1024 * 1024) {
                        uploadedItems.push({ type: '🎬 Video', link: `❌ Demasiado grande (${formatSize(videoBuffer.length)}) - Máx 200MB` });
                        continue;
                    }
                    
                    const link = await uploadCatbox(videoBuffer, mime, `video_${Date.now()}_${i}.mp4`);
                    uploadedItems.push({ type: '🎬 Video', link });
                    
                } catch (err) {
                    console.log(`Error subiendo video ${i + 1}:`, err.message);
                    uploadedItems.push({ type: '🎬 Video', link: `❌ Error: ${err.message}` });
                }
            }
            
            const successful = uploadedItems.filter(item => !item.link.startsWith('❌'));
            
            if (successful.length === 0) {
                return await replyWithContext(`❌ Error: No se pudieron subir los archivos`);
            }
            
            let resultado = `《✧》Archivos subidos » ${successful.length}/${totalItems}\n\n`;
            for (const item of successful) {
                resultado += `${item.type} » ${item.link}\n`;
            }
            
            await replyWithContext(resultado);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Twitter procesado por OWNER ${pushName || userNumber} - ${successful.length} archivos subidos a Catbox`);
            
        } catch (error) {
            console.error('❌ Error en twowner:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}`);
            } catch (e) {}
        }
    }
};