import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

function getPossibleNumberVariants(number) {
    const clean = cleanNumber(number);
    const variants = new Set();
    
    variants.add(clean);
    
    if (clean.startsWith('521')) {
        variants.add('52' + clean.substring(3));
    }
    
    if (clean.startsWith('52') && !clean.startsWith('521')) {
        variants.add('521' + clean.substring(2));
    }
    
    if (clean.length === 12 && clean.startsWith('52')) {
        variants.add('521' + clean.substring(2));
    }
    
    return Array.from(variants);
}

function compareNumbers(num1, num2) {
    if (!num1 || !num2) return false;
    const variants1 = getPossibleNumberVariants(num1);
    const variants2 = getPossibleNumberVariants(num2);
    
    for (const v1 of variants1) {
        for (const v2 of variants2) {
            if (v1 === v2) return true;
        }
    }
    return false;
}

function getBotConfigPath(sock) {
    let botNumber = '';
    if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    
    if (!botNumber) return null;
    
    const variants = getPossibleNumberVariants(botNumber);
    console.log(`🔍 Buscando config para variantes: ${variants.join(', ')}`);
    
    for (const variant of variants) {
        const subBotPath = path.join(process.cwd(), 'subs', variant, 'config.js');
        if (fs.existsSync(subBotPath)) {
            console.log(`📁 Config encontrada en: ${subBotPath}`);
            return { path: subBotPath, type: 'sub-bot', number: variant };
        }
    }
    
    const mainPath = path.join(process.cwd(), 'config.js');
    if (fs.existsSync(mainPath)) {
        console.log(`📁 Config principal encontrada en: ${mainPath}`);
        return { path: mainPath, type: 'main', number: botNumber };
    }
    
    console.log('❌ No se encontró archivo de configuración');
    return null;
}

// ============ BUSCAR BOTOWNER CON COMILLAS SIMPLES O DOBLES ============
function extractBotowner(content) {
    // Buscar botowner con comillas simples o dobles
    const patterns = [
        /botowner\s*:\s*['"]([^'"]*)['"]/,  // botowner: 'valor' o "valor"
        /botowner\s*:\s*([0-9]+)/,          // botowner: 521999...
        /"botowner"\s*:\s*['"]([^'"]*)['"]/, // "botowner": 'valor'
        /'botowner'\s*:\s*['"]([^'"]*)['"]/, // 'botowner': 'valor'
    ];
    
    for (const pattern of patterns) {
        const match = content.match(pattern);
        if (match) {
            return match[1];
        }
    }
    return null;
}

// ============ AGREGAR BOTOWNER SI NO EXISTE ============
function addBotownerToConfig(content, botNumber) {
    // Buscar dónde insertar botowner (después de la primera propiedad)
    const lines = content.split('\n');
    let insertIndex = -1;
    
    // Buscar la primera propiedad que no sea export default {
    for (let i = 0; i < lines.length; i++) {
        if (lines[i].includes(':') && !lines[i].includes('export default')) {
            insertIndex = i + 1;
            break;
        }
    }
    
    if (insertIndex === -1) {
        // Si no encuentra, insertar después de la primera línea
        insertIndex = 1;
    }
    
    // Crear la línea de botowner con el formato correcto
    const botownerLine = `  botowner: '${botNumber}',`;
    
    // Insertar la línea
    lines.splice(insertIndex, 0, botownerLine);
    
    return lines.join('\n');
}

function diagnosticConfig(content, configPath) {
    const diagnostics = {
        hasBotowner: false,
        hasOwner: false,
        botownerValue: null,
        ownerValue: null,
        contentLines: [],
        errors: []
    };
    
    try {
        diagnostics.contentLines = content.split('\n').map((line, i) => `${i+1}: ${line}`);
        
        // Buscar botowner con múltiples formatos
        const botownerValue = extractBotowner(content);
        if (botownerValue) {
            diagnostics.hasBotowner = true;
            diagnostics.botownerValue = botownerValue;
            console.log(`✅ botowner encontrado: ${diagnostics.botownerValue}`);
        } else {
            diagnostics.errors.push('No se encontró el campo "botowner"');
            console.log('❌ No se encontró botowner');
        }
        
        // Buscar owner (array)
        const ownerRegex = /owner\s*:\s*\[([^\]]*)\]/;
        const ownerMatch = content.match(ownerRegex);
        if (ownerMatch) {
            diagnostics.hasOwner = true;
            const owners = ownerMatch[1].split(',').map(o => o.trim().replace(/['"]/g, ''));
            diagnostics.ownerValue = owners;
            console.log(`✅ owner encontrado: ${JSON.stringify(owners)}`);
        } else {
            diagnostics.errors.push('No se encontró el campo "owner"');
            console.log('❌ No se encontró owner');
        }
        
        if (!content.includes('export default')) {
            diagnostics.errors.push('El archivo no contiene "export default"');
            console.log('❌ No es un módulo export default');
        }
        
    } catch (error) {
        diagnostics.errors.push(`Error en diagnóstico: ${error.message}`);
        console.error('❌ Error en diagnóstico:', error);
    }
    
    return diagnostics;
}

async function readConfigFile(configPath, botNumber) {
    try {
        const content = fs.readFileSync(configPath, 'utf8');
        console.log(`📄 Archivo leído: ${configPath}`);
        
        const diagnostics = diagnosticConfig(content, configPath);
        
        // Buscar botowner
        let botowner = extractBotowner(content);
        
        // Si no hay botowner, agregarlo
        if (!botowner) {
            console.log('⚠️ botowner no encontrado, agregando...');
            const newContent = addBotownerToConfig(content, botNumber);
            fs.writeFileSync(configPath, newContent, 'utf8');
            console.log(`✅ botowner agregado: ${botNumber}`);
            
            // Volver a leer el archivo
            const updatedContent = fs.readFileSync(configPath, 'utf8');
            botowner = extractBotowner(updatedContent);
            
            if (botowner) {
                console.log(`✅ botowner agregado exitosamente: ${botowner}`);
                return { botowner, content: updatedContent, diagnostics, wasAdded: true };
            } else {
                return { botowner: null, content: updatedContent, diagnostics, error: 'No se pudo agregar botowner' };
            }
        }
        
        return { botowner, content, diagnostics };
    } catch (error) {
        console.error('❌ Error leyendo config:', error);
        return { botowner: null, content: null, error: error.message };
    }
}

function writeConfigFile(configPath, content, newBotowner) {
    try {
        let updatedContent = content;
        
        // Buscar y reemplazar botowner con cualquier formato
        const patterns = [
            /botowner\s*:\s*['"][^'"]*['"]/,
            /botowner\s*:\s*[0-9]+/,
            /"botowner"\s*:\s*['"][^'"]*['"]/,
            /'botowner'\s*:\s*['"][^'"]*['"]/,
        ];
        
        let replaced = false;
        for (const pattern of patterns) {
            if (content.match(pattern)) {
                updatedContent = content.replace(pattern, `botowner: '${newBotowner}'`);
                replaced = true;
                break;
            }
        }
        
        if (!replaced) {
            // Si no encuentra, agregar al principio
            updatedContent = addBotownerToConfig(content, newBotowner);
        }
        
        return updatedContent;
    } catch (error) {
        console.error('❌ Error escribiendo config:', error);
        throw error;
    }
}

export default {
    name: 'setbotowner',
    alias: ['botowner'],
    description: 'Transfiere la propiedad del bot a otro usuario (solo dueño actual)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderNumber } = options;
            
            const senderNumberClean = cleanNumber(senderNumber || userNumber || '');
            
            const botConfig = getBotConfigPath(sock);
            if (!botConfig) {
                throw new Error('No se pudo encontrar la configuración del bot');
            }
            
            const configPath = botConfig.path;
            const botNumber = botConfig.number;
            
            if (!fs.existsSync(configPath)) {
                throw new Error(`No se encontró configuración en: ${configPath}`);
            }
            
            // ============ LEER CONFIG Y AGREGAR BOTOWNER SI NO EXISTE ============
            const { botowner: currentBotowner, content, diagnostics, error, wasAdded } = await readConfigFile(configPath, botNumber);
            
            // Si se agregó botowner, mostrar mensaje
            if (wasAdded) {
                await replyWithContext(
                    `✅ *Configuración reparada*\n\n` +
                    `Se agregó el campo "botowner" al archivo:\n` +
                    `${configPath}\n\n` +
                    `Valor: ${botNumber}\n\n` +
                    `Ahora puedes usar el comando nuevamente.`
                );
                return;
            }
            
            if (!currentBotowner || error) {
                let errorMsg = `❌ *Error de Configuración*\n\n`;
                errorMsg += `📁 Archivo: ${configPath}\n\n`;
                
                if (diagnostics) {
                    errorMsg += `📊 *Diagnóstico:*\n`;
                    errorMsg += `• botowner: ${diagnostics.hasBotowner ? '✅ Encontrado' : '❌ No encontrado'}\n`;
                    errorMsg += `• owner: ${diagnostics.hasOwner ? '✅ Encontrado' : '❌ No encontrado'}\n`;
                    
                    if (diagnostics.botownerValue) {
                        errorMsg += `• botowner valor: ${diagnostics.botownerValue}\n`;
                    }
                    if (diagnostics.ownerValue) {
                        errorMsg += `• owner valor: ${JSON.stringify(diagnostics.ownerValue)}\n`;
                    }
                    
                    if (diagnostics.errors.length > 0) {
                        errorMsg += `\n⚠️ *Errores detectados:*\n`;
                        diagnostics.errors.forEach(err => {
                            errorMsg += `• ${err}\n`;
                        });
                    }
                }
                
                errorMsg += `\n📄 *Primeras líneas del archivo:*\n`;
                if (diagnostics && diagnostics.contentLines) {
                    const lines = diagnostics.contentLines.slice(0, 10);
                    lines.forEach(line => {
                        errorMsg += `  ${line}\n`;
                    });
                }
                
                errorMsg += `\n💡 *Solución:* Ejecuta el comando nuevamente para agregar el campo automáticamente.`;
                
                return await replyWithContext(errorMsg);
            }
            
            const currentOwnerClean = cleanNumber(currentBotowner);
            
            if (!compareNumbers(senderNumberClean, currentOwnerClean)) {
                return await replyWithContext(`❀ *Solo el dueño actual del bot puede transferir la propiedad*`);
            }
            
            let newOwnerJid = null;
            let newOwnerNumber = null;
            
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                newOwnerJid = mentionedJid[0];
                newOwnerNumber = cleanNumber(newOwnerJid);
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!newOwnerJid && quotedMsg?.participant) {
                newOwnerJid = quotedMsg.participant;
                newOwnerNumber = cleanNumber(newOwnerJid);
            }
            
            if (!newOwnerJid || !newOwnerNumber) {
                return await replyWithContext(`「✰」 Debes mencionar o responder al usuario que será el nuevo dueño`);
            }
            
            if (compareNumbers(newOwnerNumber, senderNumberClean)) {
                return await replyWithContext(`❀ *No puedes transferir la propiedad a ti mismo*`);
            }
            
            const updatedContent = writeConfigFile(configPath, content, newOwnerNumber);
            fs.writeFileSync(configPath, updatedContent, 'utf8');
            
            if (options.config) {
                options.config.botowner = newOwnerNumber;
                if (options.config.owner && Array.isArray(options.config.owner)) {
                    options.config.owner[0] = newOwnerNumber;
                }
            }
            
            console.log(`👑 Botowner transferido de ${currentOwnerClean} a ${newOwnerNumber}`);
            await replyWithContext(
                `「✰」 Propiedad transferida a @${newOwnerNumber} con éxito`,
                [newOwnerJid]
            );
            
        } catch (error) {
            console.error('❌ Error en setbotowner:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}`);
            } catch (e) {}
        }
    }
};