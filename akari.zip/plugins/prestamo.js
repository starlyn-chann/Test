import economy from '#economy';
import db from '#db';

export default {
    name: 'prestamo',
    alias: ['loan'],
    description: 'Pide un préstamo o paga tu préstamo',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName, args }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Pedir préstamo: ${config.prefix}prestamo 500000\n> Pagar préstamo: ${config.prefix}prestamo pagar`);
            }
            
            const moneda = config.moneda || '💰';
            const now = Date.now();
            
            const user = await db.getUser(userNumber);
            let prestamoData = user?.prestamo || {
                debe: 0,
                totalPedido: 0,
                fechaPrestamo: 0,
                grupoPrestamo: ''
            };
            
            let debeActual = prestamoData.debe || 0;
            const fechaPrestamo = prestamoData.fechaPrestamo || 0;
            const grupoPrestamo = prestamoData.grupoPrestamo || '';
            
            if (debeActual > 0 && fechaPrestamo > 0 && grupoPrestamo === from) {
                const horasSinPagar = (now - fechaPrestamo) / (60 * 60 * 1000);
                
                if (horasSinPagar >= 24) {
                    let userEconomy = await economy.getUserEconomy(from, userNumber);
                    if (!userEconomy) {
                        await economy.setUserEconomy(from, userNumber, {
                            dinero: 0,
                            banco: 0,
                            nombre: pushName || 'Usuario'
                        });
                        userEconomy = await economy.getUserEconomy(from, userNumber);
                    }
                    
                    const dineroActual = userEconomy.dinero || 0;
                    let cobrado = 0;
                    
                    if (dineroActual >= 500) {
                        cobrado = 500;
                        await economy.updateUserEconomy(from, userNumber, {
                            dinero: -500,
                            nombre: pushName || 'Usuario'
                        });
                    } else {
                        cobrado = dineroActual;
                        await economy.updateUserEconomy(from, userNumber, {
                            dinero: -dineroActual,
                            nombre: pushName || 'Usuario'
                        });
                    }
                    
                    prestamoData.debe -= cobrado;
                    prestamoData.fechaPrestamo = now;
                    
                    if (prestamoData.debe < 0) {
                        const excedente = Math.abs(prestamoData.debe);
                        prestamoData.debe = 0;
                        await economy.updateUserEconomy(from, userNumber, {
                            dinero: excedente,
                            nombre: pushName || 'Usuario'
                        });
                    }
                    
                    if (prestamoData.debe === 0) {
                        prestamoData.grupoPrestamo = '';
                    }
                    
                    await db.updateUser(userNumber, 'prestamo', prestamoData);
                    
                    if (prestamoData.debe > 0) {
                        await replyWithContext(`❀ *Cobro automático*\n> Se te han cobrado ${economy.formatNumber(cobrado)} ${moneda}\n> Deuda restante: ${economy.formatNumber(prestamoData.debe)} ${moneda}\n> Siguiente cobro en 24 horas`);
                    } else {
                        await replyWithContext(`❀ *Préstamo liquidado*\n> Se te han cobrado ${economy.formatNumber(cobrado)} ${moneda} y has liquidado tu deuda\n> 🎉 *¡Préstamo pagado completamente!*`);
                    }
                    return;
                }
            }
            
            if (args[0].toLowerCase() === 'pagar' || args[0].toLowerCase() === 'pay') {
                if (debeActual <= 0) {
                    return await replyWithContext(`❀ *No tienes ningún préstamo pendiente*`);
                }
                
                let userEconomy = await economy.getUserEconomy(from, userNumber);
                if (!userEconomy) {
                    await economy.setUserEconomy(from, userNumber, {
                        dinero: 0,
                        banco: 0,
                        nombre: pushName || 'Usuario'
                    });
                    userEconomy = await economy.getUserEconomy(from, userNumber);
                }
                
                const dineroActual = userEconomy.dinero || 0;
                
                if (debeActual > dineroActual) {
                    return await replyWithContext(`❀ *No tienes suficiente dinero para pagar el préstamo*\n> Debes: ${economy.formatNumber(debeActual)} ${moneda}\n> Billetera: ${economy.formatNumber(dineroActual)} ${moneda}`);
                }
                
                const cantidadPagada = debeActual;
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: -debeActual,
                    nombre: pushName || 'Usuario'
                });
                
                prestamoData.debe = 0;
                prestamoData.totalPedido = 0;
                prestamoData.fechaPrestamo = 0;
                prestamoData.grupoPrestamo = '';
                await db.updateUser(userNumber, 'prestamo', prestamoData);
                
                const updatedEconomy = await economy.getUserEconomy(from, userNumber);
                
                await replyWithContext(`❀ *Préstamo pagado*\n> Has pagado ${economy.formatNumber(cantidadPagada)} ${moneda}\n> Deuda restante: 0 ${moneda}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${moneda}\n\n🎉 *¡Has liquidado tu préstamo completamente!*`);
                return;
            }
            
            if (debeActual > 0) {
                return await replyWithContext(`❀ *Ya tienes un préstamo pendiente*\n> Debes: ${economy.formatNumber(debeActual)} ${moneda}\n> Usa ${config.prefix}prestamo pagar para liquidarlo`);
            }
            
            let cantidad = parseInt(args[0]);
            if (isNaN(cantidad) || cantidad <= 0) {
                return await replyWithContext(`「✰」 Cantidad inválida\n> Debes ingresar un número positivo`);
            }
            
            if (cantidad < 10000) {
                return await replyWithContext(`「✰」 El préstamo mínimo es de 10,000 ${moneda}`);
            }
            
            if (cantidad > 500000) {
                return await replyWithContext(`「✰」 El préstamo máximo es de 500,000 ${moneda}`);
            }
            
            await economy.updateUserEconomy(from, userNumber, {
                dinero: cantidad,
                nombre: pushName || 'Usuario'
            });
            
            prestamoData.debe = cantidad;
            prestamoData.totalPedido = cantidad;
            prestamoData.fechaPrestamo = now;
            prestamoData.grupoPrestamo = from;
            await db.updateUser(userNumber, 'prestamo', prestamoData);
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            const mensaje = `❀ *Préstamo aprobado*\n> Has recibido ${economy.formatNumber(cantidad)} ${moneda}\n> Debes pagar: ${economy.formatNumber(cantidad)} ${moneda}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${moneda}\n\n> ⏰ Tienes 24 horas para pagar\n> Usa ${config.prefix}prestamo pagar para liquidar`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en prestamo:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};