import { 
    obtenerPersonajePorNombre,
    obtenerPersonajePorId,
    verificarReclamo,
    obtenerPersonajesReclamados
} from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SALES_FILE = path.join(__dirname, '..', 'data', 'sales.json');

function loadSales() {
    try {
        if (fs.existsSync(SALES_FILE)) {
            const data = fs.readFileSync(SALES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando ventas:', e);
    }
    return {};
}

function saveSales(sales) {
    try {
        fs.writeFileSync(SALES_FILE, JSON.stringify(sales, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando ventas:', e);
        return false;
    }
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

export default {
    name: 'sell',
    alias: ['vender'],
    description: 'Poner un personaje a la venta',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando sell...');
            
            const { config, replyWithContext, args, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            if (args.length < 2) {
                return await replyWithContext(
                    `❀ Debes especificar un precio y el nombre del personaje.\n> Ejemplo: ${config.prefix}sell 5000 / Goku`
                );
            }
            
            // ============ SEPARAR PRECIO Y NOMBRE CON "/" ============
            const textoCompleto = args.join(' ');
            const partes = textoCompleto.split('/').map(p => p.trim());
            
            if (partes.length !== 2) {
                return await replyWithContext(
                    `❀ Formato incorrecto. Usa "/" para separar el precio del nombre.\n> Ejemplo: ${config.prefix}sell 5000 / Goku`
                );
            }
            
            const precioStr = partes[0];
            const nombrePersonaje = partes[1];
            
            // ============ VALIDAR PRECIO ============
            const precio = parseInt(precioStr.replace(/[^0-9]/g, ''));
            
            if (isNaN(precio) || precio < 2000) {
                return await replyWithContext(`ꕥ El precio mínimo para vender un personaje es de *2,000 ${config.moneda}*.`);
            }
            
            if (precio > 20000000) {
                return await replyWithContext(`ꕥ El precio máximo permitido es de *20,000,000 ${config.moneda}*.`);
            }
            
            if (!nombrePersonaje) {
                return await replyWithContext(`❀ Debes especificar el nombre del personaje a vender.`);
            }
            // ================================================================
            
            // ============ BUSCAR PERSONAJE ============
            let personaje = await obtenerPersonajePorNombre(nombrePersonaje);
            
            if (!personaje) {
                const palabras = nombrePersonaje.trim().split(/\s+/);
                if (palabras.length > 1) {
                    const nombreInvertido = palabras.reverse().join(' ');
                    personaje = await obtenerPersonajePorNombre(nombreInvertido);
                }
            }
            
            if (!personaje) {
                return await replyWithContext(`ꕥ No se encontró el personaje *${nombrePersonaje}*.`);
            }
            // ================================================================
            
            // ============ VERIFICAR QUE EL PERSONAJE ESTÉ RECLAMADO POR EL USUARIO ============
            const reclamados = await obtenerPersonajesReclamados(from, userNumber);
            const reclamo = reclamados.find(r => r.personajeId === personaje.id);
            
            if (!reclamo) {
                return await replyWithContext(`ꕥ *${personaje.nombre}* no está reclamado por ti.`);
            }
            // ================================================================
            
            // ============ VERIFICAR SI EL PERSONAJE YA ESTÁ EN VENTA ============
            const sales = loadSales();
            if (!sales[from]) sales[from] = {};
            
            const yaEnVenta = Object.keys(sales[from]).find(id => id === personaje.id);
            if (yaEnVenta) {
                return await replyWithContext(`ꕥ *${personaje.nombre}* ya está en venta.`);
            }
            // ================================================================
            
            // ============ PONER A LA VENTA ============
            sales[from][personaje.id] = {
                nombre: personaje.nombre,
                usuario: userNumber,
                precio: precio,
                tiempo: Date.now()
            };
            
            saveSales(sales);
            // ================================================================
            
            const mensaje = `✎ *${personaje.nombre}* ha sido puesto a la venta!\n` +
                           `❀ Vendedor » *${pushName || userNumber}*\n` +
                           `⛁ Precio » *${precio.toLocaleString()} ${config.moneda}*\n` +
                           `ⴵ Expira en » *3 dias*\n` +
                           `> Puedes ver los personajes en venta usando *${config.prefix}wshop*`;
            
            await replyWithContext(mensaje);
            
            console.log(`✅ sell ejecutado: ${pushName || userNumber} puso a ${personaje.nombre} por ${precio}`);
            
        } catch (error) {
            console.error('❌ Error en sell:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};