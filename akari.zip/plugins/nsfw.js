import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Asegurar que el archivo existe
if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}
if (!fs.existsSync(NSFW_FILE)) {
    fs.writeFileSync(NSFW_FILE, JSON.stringify({}, null, 2));
}

function loadNsfwConfig() {
    try {
        const data = fs.readFileSync(NSFW_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveNsfwConfig(config) {
    fs.writeFileSync(NSFW_FILE, JSON.stringify(config, null, 2));
}

export default {
    name: 'nsfw',
    alias: [],
    description: 'Activa o desactiva comandos NSFW en el grupo (solo admins)',
    category: 'on / off',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, senderJid, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Función para limpiar JID
            function getCleanJid(jid) {
                if (!jid) return '';
                const number = jid.split(':')[0].split('@')[0].replace(/\D/g, '');
                return `${number}@s.whatsapp.net`;
            }
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Verificar argumento
            if (!args || args.length === 0) {
                return await replyWithContext(`*ᰔᩚ* Uso correcto:\n> ${config.prefix}nsfw on - Activar NSFW\n> ${config.prefix}nsfw off - Desactivar NSFW`);
            }
            
            const action = args[0].toLowerCase();
            
            if (action !== 'on' && action !== 'enable' && action !== 'off' && action !== 'disable') {
                return await replyWithContext(`*ᰔᩚ* Opción inválida.\n> Usa: ${config.prefix}nsfw on o ${config.prefix}nsfw off`);
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Verificar si el usuario es administrador o es el usuario autorizado
            const senderCleanJid = getCleanJid(senderJid);
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid || p.id === senderCleanJid);
            const isAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            // Número autorizado a usar el comando sin ser admin
            const AUTHORIZED_NUMBER = '5219992042946';
            const isAuthorized = userNumber === AUTHORIZED_NUMBER;
            
            if (!isAdmin && !isAuthorized) {
                return await replyWithContext(`*ᰔᩚ* Tienes que ser administrador del grupo para poder usar este comando`);
            }
            
            // Cargar configuración NSFW
            const nsfwConfig = loadNsfwConfig();
            const isActive = nsfwConfig[from] || false;
            
            const isActivating = action === 'on' || action === 'enable';
            const isDeactivating = action === 'off' || action === 'disable';
            
            if (isActivating && isActive) {
                return await replyWithContext(`《✧》 Los comandos nsfw ya estaban activados`);
            }
            
            if (isDeactivating && !isActive) {
                return await replyWithContext(`《✧》 Los comandos nsfw ya estaban desactivados`);
            }
            
            if (isActivating) {
                nsfwConfig[from] = true;
                saveNsfwConfig(nsfwConfig);
                await replyWithContext(`《✧》 Se ha activado los comandos nsfw con éxito`);
                console.log(`🔞 NSFW activado en grupo ${from} por ${pushName || userNumber}`);
            } else {
                nsfwConfig[from] = false;
                saveNsfwConfig(nsfwConfig);
                await replyWithContext(`《✧》 Se ha desactivado los comandos nsfw con éxito`);
                console.log(`🔞 NSFW desactivado en grupo ${from} por ${pushName || userNumber}`);
            }
            
        } catch (error) {
            console.error('❌ Error en nsfw:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};