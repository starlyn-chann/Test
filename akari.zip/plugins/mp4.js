import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execAsync = promisify(exec);

const tempDir = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

function formatDuration(seconds) {
    if (!seconds || seconds === 0) return 'N/A';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export default {
    name: 'mp4',
    alias: ['ytmp4', 'ytvideo'],
    description: 'Descarga videos de YouTube en formato MP4',
    category: 'download',
    
    async execute(sock, msg, options) {
        let outputPath = null;
        let rawPath = null;
        
        try {
            const { config, args, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            const cleanQuery = query.replace(/^["']|["']$/g, '');
            
            if (!cleanQuery) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre o link de un video\n> Ejemplo: ${config.prefix}mp4 https://youtube.com/watch?v=xxx`);
            }
            
            await sock.sendPresenceUpdate('composing', from);
            
            try {
                await sock.sendMessage(from, { react: { text: '🕑', key: msg.key } });
            } catch (e) {}
            
            const isUrl = cleanQuery.includes('youtube.com') || cleanQuery.includes('youtu.be');
            let videoUrl = cleanQuery;
            let videoTitle = 'Sin título';
            let videoChannel = 'Canal desconocido';
            let videoThumbnail = '';
            let duration = 0;
            let durationString = 'N/A';
            let quality = '480';
            let size = 'N/A';
            
            if (!isUrl) {
                console.log('🔍 Buscando:', cleanQuery);
                
                const searchApi = `https://api.ikyyxd.my.id/search/youtube?apikey=kyzz&query=${encodeURIComponent(cleanQuery)}`;
                const searchResponse = await axios.get(searchApi, { timeout: 30000 });
                
                if (!searchResponse.data?.status || !searchResponse.data?.result || searchResponse.data.result.length === 0) {
                    throw new Error('No se encontraron resultados para la búsqueda');
                }
                
                const results = searchResponse.data.result;
                
                if (results.length === 1) {
                    const firstResult = results[0];
                    videoUrl = firstResult.link || firstResult.url;
                    videoTitle = firstResult.title || 'Sin título';
                    videoChannel = firstResult.channel || 'Desconocido';
                    videoThumbnail = firstResult.imageUrl || firstResult.thumbnail || '';
                    duration = firstResult.duration || 0;
                    durationString = firstResult.duration || 'N/A';
                } else {
                    const rows = results.slice(0, 10).map((video) => {
                        const dur = video.duration || 'N/A';
                        const channel = video.channel || 'Desconocido';
                        return {
                            header: channel,
                            title: video.title || 'Sin título',
                            description: `⧖ ${dur}`,
                            id: `${config.prefix}mp4 ${video.link}`
                        };
                    });
                    
                    const sections = [{
                        title: "RESULTADOS DE BÚSQUEDA",
                        rows: rows
                    }];
                    
                    let imageBuffer = null;
                    if (results[0]?.imageUrl || results[0]?.thumbnail) {
                        try {
                            const imgUrl = results[0].imageUrl || results[0].thumbnail;
                            const imgResponse = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
                            imageBuffer = Buffer.from(imgResponse.data);
                        } catch (e) {}
                    }
                    
                    const infoText = ` ꒰ *𝘠𝘛-𝘋𝘖𝘞𝘕𝘓𝘖𝘈𝘋* ꒱
─ ⋅ ⋅ ⋅ ─── ꒰ ♡ ꒱ ─── ⋅ ⋅ ⋅ ─\n\n` +
                                   `˚₊‧꒰ა *b𝗎𝗌𝗊𝗎ᧉdα* › ${cleanQuery}\n` +
                                   `˚₊‧꒰ა *ꭇᧉ𝗌𝗎𝗅ƚαd𖹭* › ${Math.min(results.length, 10)}`;
                    
                    if (imageBuffer) {
                        await sock.sendMessage(from, {
                            image: imageBuffer,
                            caption: infoText,
                            interactiveButtons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "seleccionar",
                                    sections: sections
                                })
                            }],
                            contextInfo: {
                                mentionedJid: senderJid ? [senderJid] : [],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    } else {
                        await sock.sendMessage(from, {
                            text: infoText,
                            interactiveButtons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "seleccionar",
                                    sections: sections
                                })
                            }],
                            contextInfo: {
                                mentionedJid: senderJid ? [senderJid] : [],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                    
                    console.log(`🎬 Video buscado: ${cleanQuery} por ${pushName || userNumber}`);
                    return;
                }
            }
            
            // ============ API DE DESCARGA CON KEY ============
            console.log('📥 Descargando video:', videoUrl);
            
            const downloadApi = `https://apiakari.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(videoUrl)}&quality=480&key=starlyndev`;
            const response = await axios.get(downloadApi, { timeout: 30000 });
            
            if (!response.data?.status || !response.data?.data) {
                throw new Error('No se pudo obtener el video');
            }
            
            const data = response.data.data;
            videoTitle = data.title || videoTitle;
            quality = data.quality || data.format || '480';
            duration = data.duration || 0;
            size = data.size || 'N/A';
            videoThumbnail = data.thumbnail || videoThumbnail;
            const downloadUrl = data.download;
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            durationString = formatDuration(duration);
            
            // ============ DESCARGAR VIDEO ============
            const baseName = `video_${Date.now()}`;
            rawPath = path.join(tempDir, `${baseName}.mp4`);
            
            console.log(`📥 Descargando archivo desde: ${downloadUrl}`);
            
            const videoResponse = await axios.get(downloadUrl, {
                responseType: 'arraybuffer',
                timeout: 180000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': '*/*',
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive'
                }
            });
            
            const videoBuffer = Buffer.from(videoResponse.data);
            fs.writeFileSync(rawPath, videoBuffer);
            
            const stats = fs.statSync(rawPath);
            if (stats.size < 1024 * 50) {
                throw new Error('El archivo descargado es demasiado pequeño');
            }
            
            // ============ CONVERTIR CON CONFIGURACIÓN VERYFAST OPTIMIZADA ============
            outputPath = path.join(tempDir, `${baseName}_converted.mp4`);
            
            // Configuración optimizada para WhatsApp con veryfast y CRF 26
            const convertCommand = `ffmpeg -i "${rawPath}" -c:v libx264 -preset veryfast -crf 26 -c:a aac -b:a 128k -movflags +faststart -pix_fmt yuv420p -vf "scale=640:360,fps=30" -profile:v baseline -level 3.0 -threads auto -y "${outputPath}"`;
            
            console.log(`🔄 Convirtiendo a H.264 (veryfast): ${convertCommand}`);
            
            try {
                await execAsync(convertCommand, { 
                    timeout: 90000,
                    cwd: process.cwd(),
                    shell: '/bin/bash'
                });
                console.log('✅ Conversión completada');
                try { fs.unlinkSync(rawPath); } catch (e) {}
            } catch (error) {
                console.error('❌ Error en conversión:', error);
                outputPath = rawPath;
                console.log('⚠️ Usando archivo original sin conversión');
            }
            
            if (!fs.existsSync(outputPath)) {
                throw new Error('No se pudo procesar el video');
            }
            
            const finalStats = fs.statSync(outputPath);
            const sizeMB = (finalStats.size / 1024 / 1024).toFixed(2);
            
            // ============ DESCARGAR MINIATURA ============
            let thumbnailBuffer = null;
            if (videoThumbnail) {
                try {
                    const thumbResponse = await axios.get(videoThumbnail, {
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando miniatura:', e.message);
                }
            }
            
            // ============ MENSAJE CON INFORMACIÓN ============
            const caption = `︵⏜⌒⁡ ᥀ ❀ ⁔⭐⁔⁣⁣⁣⁡⁡⁣   ᥀ ✿ ⌒⏜︵
🌷ׅᩙ♡ *ƚiƚ𝗎𝗅𖹭* › ${videoTitle}\n` +
                          `🌷ׅᩙ♡ *cα𝗇α𝗅* › ${videoChannel}\n` +
                          `🌷ׅᩙ♡ *d𝗎ꭇαcꪱo𝗇* › ${durationString}\n` +
                          `🌷ׅᩙ♡ *cα𝗅ꪱdαd* › ${quality}p\n` +
                          `🌷ׅᩙ♡ *ƚα𝗆αᥒ̃𖹭* › ${sizeMB} MB\n` +
                          `🌷ׅᩙ♡ *𝗅ꪱ𝗇k* › ${videoUrl}`;
            
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: caption,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: caption,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // ============ ENVIAR VIDEO ============
            const videoBufferToSend = fs.readFileSync(outputPath);
            
            await sock.sendMessage(from, {
                video: videoBufferToSend,
                mimetype: 'video/mp4',
                caption: `> ${videoTitle}`,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            // ============ LIMPIAR ARCHIVOS ============
            setTimeout(() => {
                try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
                try { if (fs.existsSync(rawPath) && rawPath !== outputPath) fs.unlinkSync(rawPath); } catch (e) {}
            }, 10000);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Video enviado por ${pushName || 'Usuario'}: ${videoTitle} (${sizeMB} MB)`);
            
        } catch (error) {
            console.error('❌ Error en mp4:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                await sock.sendMessage(msg.key.remoteJid, {
                    text: `❌ *Error:* ${error.message}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: options.config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: options.config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } catch (e) {}
        }
    }
};