import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `spotify_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatDuration(duration) {
    if (!duration) return 'N/A';
    if (typeof duration === 'string' && duration.includes(':')) return duration;
    return duration;
}

export default {
    name: 'spotify',
    alias: ['sp'],
    description: 'Descarga música desde Spotify',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, senderJid, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args.join(' ').trim();
            
            if (!url) {
                return await replyWithContext(`*ᰔᩚ* Debes proporcionar un enlace de Spotify\n> Ejemplo: ${config.prefix}spotify https://open.spotify.com/track/xxxxx`);
            }
            
            if (!url.includes('spotify.com')) {
                return await replyWithContext(`*Link inválido*\n\n> Debes proporcionar un enlace de Spotify válido.`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`*Buscando...*`);
            
            // ============ NUEVA API DE DESCARGA CON KEY ============
            const apiUrl = `https://apiakari.vercel.app/api/downloader/spotify?url=${encodeURIComponent(url)}&key=starlyndev`;
            
            const response = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.status || !response.data?.data) {
                throw new Error('No se encontró la canción');
            }
            
            const data = response.data.data;
            
            // ============ EXTRAER DATOS ============
            const title = data.title || data.raw?.name || 'Canción';
            const artist = data.author || data.raw?.artist || 'Artista';
            const album = data.album || data.raw?.album || '';
            const year = data.year || data.raw?.year || '';
            const duration = data.duration || data.raw?.duration || 'N/A';
            const imageUrl = data.cover || data.raw?.cover || '';
            const downloadUrl = data.download || data.raw?.mp3;
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // ============ DESCARGAR THUMBNAIL ============
            let thumbnailBuffer = null;
            if (imageUrl) {
                try {
                    const thumbResponse = await axios.get(imageUrl, { 
                        responseType: 'arraybuffer',
                        timeout: 15000
                    });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando thumbnail:', e.message);
                }
            }
            
            // ============ DESCARGAR AUDIO ============
            await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            
            const audioResponse = await axios.get(downloadUrl, {
                responseType: 'arraybuffer',
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://spotify.com/',
                    'Accept': '*/*',
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive'
                }
            });
            
            const audioBuffer = Buffer.from(audioResponse.data);
            const sizeMB = (audioBuffer.length / 1024 / 1024).toFixed(2);
            const nombreArchivo = title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
            
            // ============ CONSTRUIR CAPTION ============
            let caption = `꯭ꕤ゙ *Nombre › ${title}*\n`;
            caption += `ꕤ゙ *Artista › ${artist}*\n`;
            if (album) caption += `ꕤ゙ *Álbum › ${album}*\n`;
            if (year) caption += `ꕤ゙ *Año › ${year}*\n`;
            caption += `ꕤ゙ *Duración › ${formatDuration(duration)}*\n`;
            caption += `ꕤ゙ *Tamaño › ${sizeMB} MB*\n\n`;
            caption += `> Solicitado por: ${pushName || 'Usuario'}`;
            
            // ============ ENVIAR THUMBNAIL CON INFORMACIÓN ============
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: caption,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(caption);
            }
            
            // ============ ENVIAR AUDIO ============
            await sock.sendMessage(from, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${nombreArchivo}.mp3`,
                ptt: false,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Canción descargada: ${title} - ${artist} (${sizeMB} MB) por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en spotify:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}\n\n> Verifica que el enlace sea válido y vuelve a intentarlo.`);
            } catch (e) {}
        }
    }
};