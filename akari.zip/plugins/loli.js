import axios from 'axios';

export default {
    name: 'loli',
    alias: [],
    description: 'Envía una imagen aleatoria de Loli',
    category: 'image',
    
    async execute(sock, msg, options) {
        try {
            const { config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            const apiUrl = 'https://api.ikyyxd.my.id/random/loli?apikey=kyzz';
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const imageBuffer = Buffer.from(response.data);
            
            const caption = `> Aquí tienes tu Loli ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`;
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: caption,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Loli enviado a ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en loli:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: No se pudo obtener la imagen`);
            } catch (e) {}
        }
    }
};