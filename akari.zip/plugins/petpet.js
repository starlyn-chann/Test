import fs from 'fs';
import path from 'path';
import axios from 'axios';
import { randomBytes } from 'crypto';
import ffmpeg from 'fluent-ffmpeg';
import pkg from 'node-webpmux';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import FormData from 'form-data';

const { Image } = pkg;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const tempFolder = path.join(__dirname, '../databases/');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

// --- FUNCIONES DE SOPORTE (Tus funciones originales) ---

function randomFileName(ext) {
    return `${randomBytes(6).readUIntLE(0, 6).toString(36)}.${ext}`;
}

async function addExif(webpBuffer, metadata) {
    const tmpIn = path.join(tempFolder, randomFileName('webp'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, webpBuffer);

    const json = {
        "sticker-pack-id": "starry_moonlight",
        "sticker-pack-name": metadata.packname || "Moonlight",
        "sticker-pack-publisher": metadata.author || "Bot",
        "emojis": ["✨"]
    };

    const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);

    const img = new Image();
    await img.load(tmpIn);
    img.exif = exif;
    await img.save(tmpOut);
    fs.unlinkSync(tmpIn);
    return tmpOut;
}

async function gifToWebpSticker(gifBuffer) {
    const tmpIn = path.join(tempFolder, randomFileName('gif'));
    const tmpOut = path.join(tempFolder, randomFileName('webp'));
    fs.writeFileSync(tmpIn, gifBuffer);

    return new Promise((resolve, reject) => {
        ffmpeg(tmpIn)
            .on('error', (err) => {
                if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
                reject(err);
            })
            .on('end', () => {
                const buff = fs.readFileSync(tmpOut);
                if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
                if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
                resolve(buff);
            })
            .addOutputOptions([
                "-vcodec", "libwebp",
                "-vf", "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15,pad=320:320:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse",
                "-loop", "0", "-preset", "default", "-an", "-vsync", "0"
            ])
            .toFormat('webp')
            .save(tmpOut);
    });
}

async function uploadUguu(buffer) {
    const form = new FormData();
    form.append('files[]', buffer, 'image.jpg');
    const res = await axios.post('https://uguu.se/upload.php', form, { headers: form.getHeaders() });
    return res.data?.files?.[0]?.url;
}

// --- COMANDO PRINCIPAL ---

export default {
    name: 'petpet',
    alias: ['petgif'],
    description: 'Crea un sticker respondiendo a una imagen (palmadita)',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, pushName, senderNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;

            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            if (!quotedMessage?.imageMessage && !quotedMessage?.stickerMessage && !msg.message?.imageMessage) {
                return await replyWithContext(`「✰」Responde a una imagen o sticker.`);
            }

            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            // 1. Descargar el medio
            const mediaObj = quotedMessage ? {
                key: { remoteJid: from, id: quotedMsg.stanzaId, participant: quotedMsg.participant || from, fromMe: false },
                message: quotedMessage
            } : msg;

            const buffer = await downloadMediaMessage(mediaObj, 'buffer', {}, { logger: console });

            // 2. Subir para la API
            const imageUrl = await uploadUguu(buffer);

            // 3. Obtener GIF de la API
            const petApi = `https://api.delirius.store/canvas/petgif?url=${encodeURIComponent(imageUrl)}&resolution=512&delay=20`;
            const response = await axios.get(petApi, { responseType: 'arraybuffer' });

            // 4. CONVERTIR A WEBP (Visible y Animado)
            const webpSticker = await gifToWebpSticker(Buffer.from(response.data));

            // 5. AGREGAR EXIF (Metadata)
            const metadata = { 
                packname: `「✰」${pushName || 'Moonlight'}`, 
                author: `「✰」Bot » ${config.nombre || 'StarRy'}` 
            };
            const stickerPath = await addExif(webpSticker, metadata);

            // 6. Enviar
            await sock.sendMessage(from, {
                sticker: fs.readFileSync(stickerPath)
            }, { quoted: msg });

            fs.unlinkSync(stickerPath);
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('❌ Error en petpet:', error);
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
        }
    }
};