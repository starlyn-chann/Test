import { obtenerPersonajePorNombre, obtenerPersonajePorTag } from '../lib/gacha.js';
import { 
    guardarPersonajeEnGrupo, 
    getPersonajeEnGrupo,
    eliminarPersonajeDelCache
} from '../lib/gachaCache.js';

export default {
    name: 'vote',
    alias: ['votar'],
    description: 'Vota por un personaje para aumentar su valor',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando vote...');
            
            const { config, replyWithContext, userNumber, args } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const nombreBuscado = args.join(' ').trim();
            
            if (!nombreBuscado) {
                return await replyWithContext(
                    `❀ Debes proporcionar el nombre de un personaje\n> Ejemplo › ${config.prefix}vote Luffy`
                );
            }
            
            // ============ VERIFICAR COOLDOWN (1 HORA = 3600000ms) ============
            const cooldownKey = `vote_${userNumber}`;
            const cooldownData = getPersonajeEnGrupo(cooldownKey);
            
            if (cooldownData) {
                const tiempoTranscurrido = Date.now() - cooldownData.timestamp;
                const tiempoRestante = Math.max(0, 3600000 - tiempoTranscurrido);
                
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.ceil((tiempoRestante % 60000) / 1000);
                    const tiempoStr = minutos > 0 ? `${minutos}m ${segundos}s` : `${segundos}s`;
                    return await replyWithContext(`ꕤ Debes esperar \`${tiempoStr}\` para volver a votar`);
                } else {
                    eliminarPersonajeDelCache(cooldownKey);
                }
            }
            // ================================================================
            
            // ============ BUSCAR PERSONAJE ============
            // Buscar por nombre exacto
            let personaje = await obtenerPersonajePorNombre(nombreBuscado);
            
            // Si no se encuentra, buscar por tag
            if (!personaje) {
                const tagLower = nombreBuscado.toLowerCase().replace(/\s+/g, '_');
                personaje = await obtenerPersonajePorTag(tagLower);
            }
            
            // Si no se encuentra, buscar por nombre invertido
            if (!personaje) {
                const palabras = nombreBuscado.trim().split(/\s+/);
                if (palabras.length > 1) {
                    const nombreInvertido = palabras.reverse().join(' ');
                    personaje = await obtenerPersonajePorNombre(nombreInvertido);
                }
            }
            
            // Si no se encuentra, buscar por coincidencia parcial
            if (!personaje) {
                const { obtenerTodosPersonajes } = await import('../lib/gacha.js');
                const todos = await obtenerTodosPersonajes();
                const nombreLower = nombreBuscado.toLowerCase();
                
                for (const pj of todos) {
                    const pjNombreLower = pj.nombre.toLowerCase();
                    if (pjNombreLower.includes(nombreLower) || nombreLower.includes(pjNombreLower)) {
                        personaje = pj;
                        break;
                    }
                }
            }
            
            if (!personaje) {
                return await replyWithContext(`ꕤ No se encontró el personaje *"${nombreBuscado}"*\n> Verifica que el nombre esté bien escrito`);
            }
            // ================================================================
            
            // ============ CALCULAR NUEVO VALOR ============
            const aumento = Math.floor(Math.random() * (60 - 20 + 1)) + 20;
            const nuevoValor = personaje.valor + aumento;
            
            const { actualizarValorPersonaje } = await import('../lib/gacha.js');
            const actualizado = await actualizarValorPersonaje(personaje.id, nuevoValor);
            
            if (!actualizado) {
                return await replyWithContext(`❌ Error al actualizar el valor del personaje`);
            }
            // ================================================================
            
            // ============ GUARDAR COOLDOWN ============
            guardarPersonajeEnGrupo(cooldownKey, 'vote', userNumber, null);
            
            setTimeout(() => {
                const data = getPersonajeEnGrupo(cooldownKey);
                if (data) {
                    eliminarPersonajeDelCache(cooldownKey);
                    console.log(`⏰ Cooldown de vote eliminado para ${userNumber}`);
                }
            }, 3600000);
            // ================================================================
            
            // ============ MENSAJE DE RESPUESTA ============
            const mensaje = 
`ꕤ Votaste por *${personaje.nombre}*
> Valor › ${nuevoValor} (+${aumento})`;

            await replyWithContext(mensaje);
            
            console.log(`✅ Vote ejecutado: ${userNumber} votó por ${personaje.nombre} (+${aumento})`);
            // ================================================================
            
        } catch (error) {
            console.error('❌ Error en vote:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};