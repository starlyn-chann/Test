import db from '#db';

export default {
    name: 'setgenre',
    alias: ['setgenero'],
    description: 'Establece o elimina tu género',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        const input = args.join(' ').toLowerCase();

        // Eliminar género
        if (input === 'delete' || input === 'eliminar' || input === 'remove') {
            if (!user?.genre) {
                return await replyWithContext(`ꕥ *No tienes un género establecido para eliminar.*`);
            }
            
            await db.updateUser(userNumber, 'genre', null);
            return await replyWithContext(`✎ *Tu género ha sido eliminado correctamente.*`);
        }

        if (user?.genre) {
            return await replyWithContext(`ꕥ Ya tienes un género. Usa › *${config.prefix}setgenre delete* para eliminarlo.`);
        }

        if (!input) {
            return await replyWithContext('《✧》 Debes ingresar un género válido.\n\n*Ejemplos:*\n' +
                `${config.prefix}setgenre hombre\n${config.prefix}setgenre mujer\n${config.prefix}setgenre delete`);
        }

        const genre = input === 'hombre' ? 'Hombre' : input === 'mujer' ? 'Mujer' : null;
        if (!genre) {
            return await replyWithContext(`《✧》 Elige un género válido.\n*Opciones:* hombre, mujer`);
        }

        await db.updateUser(userNumber, 'genre', genre);

        return await replyWithContext(`✎ Se ha establecido tu género como: *${genre}*`);
    }
};