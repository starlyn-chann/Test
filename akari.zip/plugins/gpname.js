export default {
    name: 'gpname',
    alias: ['setgroupname'],
    description: 'Cambia el nombre del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, senderJid, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Función para limpiar número
            function cleanNumber(jid) {
                if (!jid) return '';
                return jid.split(':')[0].split('@')[0].replace(/\D/g, '');
            }
            
            function getCleanJid(jid) {
                if (!jid) return '';
                const number = cleanNumber(jid);
                return `${number}@s.whatsapp.net`;
            }
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Verificar que se proporcionó un nombre
            const nuevoNombre = args.join(' ').trim();
            
            if (!nuevoNombre) {
                return await replyWithContext(`*ᰔᩚ* Debes proporcionar un nombre para el grupo\n> Ejemplo: ${config.prefix}gpname +Mi Nuevo Grupo`);
            }
            
            // Eliminar el '+' si está presente al inicio
            let nombreFinal = nuevoNombre;
            if (nombreFinal.startsWith('+')) {
                nombreFinal = nombreFinal.substring(1).trim();
            }
            
            if (!nombreFinal) {
                return await replyWithContext(`*ᰔᩚ* El nombre no puede estar vacío`);
            }
            
            // Limitar longitud (máx 100 caracteres)
            if (nombreFinal.length > 100) {
                return await replyWithContext(`「✰」 El nombre del grupo no puede tener más de 100 caracteres\n> Tu nombre tiene: ${nombreFinal.length} caracteres`);
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Verificar si el usuario que ejecuta el comando es administrador
            const senderCleanJid = getCleanJid(senderJid);
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid || p.id === senderCleanJid);
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            if (!isSenderAdmin) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para poder usar este comando`);
            }
            
            // Verificar si el bot es administrador
            const botJid = sock.user?.id;
            const botCleanJid = getCleanJid(botJid);
            const botParticipant = groupMetadata.participants.find(p => p.id === botJid || p.id === botCleanJid);
            const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
            
            if (!isBotAdmin) {
                return await replyWithContext(`「✰」 ${config.nombre || config.name} debe ser administrador del grupo`);
            }
            
            // Cambiar el nombre del grupo
            try {
                await sock.groupUpdateSubject(from, nombreFinal);
                
                await replyWithContext(`《✧》 Nombre del grupo actualizado a: *${nombreFinal}*`);
                
                console.log(`📝 Nombre del grupo cambiado a "${nombreFinal}" por ${pushName || userNumber} en grupo ${from}`);
                
            } catch (error) {
                console.error('Error al cambiar nombre:', error);
                return await replyWithContext(`❌ Error al cambiar el nombre: ${error.message}`);
            }
            
        } catch (error) {
            console.error('❌ Error en gpname:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};