import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para la verificación de NSFW
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Función para cargar la configuración de los grupos
function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

// Variable para mantener la sesión activa fuera del execute
let sessionCookie = null;

async function getDanbooruSession() {
    if (sessionCookie) return sessionCookie;
    try {
        const res = await axios.post('https://danbooru.donmai.us/session', 
            'user[name]=uwudanonino5599&user[password]=danoninoleonel5599', 
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        sessionCookie = res.headers['set-cookie'];
        return sessionCookie;
    } catch (e) {
        return null;
    }
}

export default {
    name: 'danbooru',
    alias: ['dbooru'],
    description: 'Busca imágenes en Danbooru',
    category: 'nsfw',

    async execute(sock, msg, options) {
        const { args, config, senderJid, replyWithContext, isGroup } = options;
        const from = msg.key.remoteJid;

        try {
            // --- VALIDACIÓN NSFW ---
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------

            if (!args || !args.length) {
                return await replyWithContext(`《✧》 Debes especificar tags para buscar\n> Ejemplo » *${config.prefix}danbooru neko*`);
            }

            try {
                await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } });
            } catch (e) {}

            const cookie = await getDanbooruSession();
            const tag = args.join('_');
            const url = `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(tag)}&limit=20`;

            const response = await axios.get(url, {
                headers: { 'Cookie': cookie || '' },
                timeout: 15000
            });

            const json = response.data;

            if (!Array.isArray(json) || json.length === 0) {
                return await replyWithContext(`《✧》 No se encontraron resultados para: ${tag}`);
            }

            const mediaList = json
                .filter(p => p?.file_url && /\.(jpe?g|png|gif)$/i.test(p.file_url))
                .map(p => p.file_url);

            if (!mediaList.length) {
                return await replyWithContext(`《✧》 Se encontraron posts pero no tienen archivos visuales directos.`);
            }

            const chosenMedia = mediaList[Math.floor(Math.random() * mediaList.length)];
            const caption = `ꕥ *Danbooru Search*\n*ᰔᩚ* Tags » ${tag}\n*ᰔᩚ* Pedido por » ${options.pushName || 'Usuario'}`;

            await sock.sendMessage(from, {
                image: { url: chosenMedia },
                caption: caption,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            try {
                await sock.sendMessage(from, { react: { text: '✔️', key: msg.key } });
            } catch (e) {}

        } catch (error) {
            console.error('❌ Error en Danbooru:', error);
            try {
                await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};