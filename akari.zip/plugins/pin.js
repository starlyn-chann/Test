import axios from 'axios';

export default {
    name: 'pin',
    alias: ['pinterest', 'pint'],
    description: 'Busca imágenes/videos en Pinterest o descarga desde enlace',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const text = args.join(' ');
            
            if (!text) {
                return await replyWithContext(`ꕤ Por favor, ingresa lo que deseas buscar en Pinterest.\n\n> Ejemplo: ${config.prefix}pin gatos bonitos`);
            }
            
            // Verificar si es un link de Pinterest
            const isPinterestLink = text.includes('pin.it') || text.includes('pinterest.com') || text.includes('pin/');
            
            if (isPinterestLink) {
                // ============ MÉTODO LINK: API NexRay ============
                console.log(`🔗 Procesando link de Pinterest: ${text}`);
                
                const apiUrl = `https://api.nexray.web.id/downloader/pinterest?url=${encodeURIComponent(text)}`;
                
                const response = await axios.get(apiUrl, {
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });
                
                if (!response.data || !response.data.status || !response.data.result) {
                    throw new Error('No se pudo obtener el contenido del link');
                }
                
                const result = response.data.result;
                const title = result.title || 'Pinterest';
                const author = result.author || 'Desconocido';
                
                let caption = `❀ Pinterest - Download ✿\n\n「★」Título » ${title}\n「★」Autor » ${author}`;
                
                // Determinar tipo y URL del media
                if (result.video) {
                    // Es un video
                    const videoBuffer = await axios.get(result.video, {
                        responseType: 'arraybuffer',
                        timeout: 60000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    }).then(res => Buffer.from(res.data));
                    
                    await sock.sendMessage(from, {
                        video: videoBuffer,
                        caption: caption,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                } else if (result.image) {
                    // Verificar si es GIF por la extensión o URL
                    const isGif = result.image.includes('.gif') || result.thumbnail?.includes('.gif');
                    
                    const mediaBuffer = await axios.get(result.image, {
                        responseType: 'arraybuffer',
                        timeout: 60000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    }).then(res => Buffer.from(res.data));
                    
                    if (isGif) {
                        await sock.sendMessage(from, {
                            video: mediaBuffer,
                            gifPlayback: true,
                            caption: caption,
                            contextInfo: {
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    } else {
                        await sock.sendMessage(from, {
                            image: mediaBuffer,
                            caption: caption,
                            contextInfo: {
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                }
                
                console.log(`✅ Pinterest link descargado por ${pushName || userNumber}: ${title}`);
                
            } else {
                // ============ MÉTODO BÚSQUEDA: API Siputzx ============
                console.log(`🔍 Buscando en Pinterest: ${text}`);
                
                const apiUrl = `https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(text)}`;
                
                const response = await axios.get(apiUrl, {
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });
                
                if (!response.data || !response.data.status || !response.data.data || response.data.data.length === 0) {
                    return await replyWithContext(`ꕤ No se encontraron resultados para "${text}".`);
                }
                
                const resultados = response.data.data;
                const aleatorio = Math.floor(Math.random() * resultados.length);
                const item = resultados[aleatorio];
                
                let descripcion = '';
                if (item.description && item.description.trim() !== '' && item.description.trim() !== ' ') {
                    descripcion = item.description.trim();
                } else if (item.grid_title && item.grid_title.trim() !== '' && item.grid_title.trim() !== ' ') {
                    descripcion = item.grid_title.trim();
                }
                
                let caption = `❀ Pinterest - Search ✿\n\n「★」Búsqueda » ${text}\n「★」Tipo » ${item.type || 'image'}`;
                
                if (descripcion) {
                    caption += `\n「★」Descripción » ${descripcion.substring(0, 100)}${descripcion.length > 100 ? '...' : ''}`;
                }
                
                caption += `\n「★」Usuario » ${item.pinner?.full_name || 'Desconocido'}\n「★」Reacciones » ${item.reaction_counts?.['1'] || 0} ❤️`;
                
                const mediaUrl = item.video_url || item.gif_url || item.image_url;
                
                const mediaBuffer = await axios.get(mediaUrl, {
                    responseType: 'arraybuffer',
                    timeout: 60000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                }).then(res => Buffer.from(res.data));
                
                if (item.type === 'video') {
                    await sock.sendMessage(from, {
                        video: mediaBuffer,
                        caption: caption,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } else if (item.type === 'gif') {
                    await sock.sendMessage(from, {
                        video: mediaBuffer,
                        gifPlayback: true,
                        caption: caption,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, {
                        image: mediaBuffer,
                        caption: caption,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                
                console.log(`✅ Pinterest "${text}" por ${pushName || userNumber}`);
            }

        } catch (error) {
            console.error('❌ Error en comando pin:', error);
            
            try {
                const { config, replyWithContext } = options;
                await replyWithContext(`ꕤ Se ha producido un problema.\n> » Usa *${config.prefix}report* para informarlo.\n\n${error.message}`);
            } catch (e) {}
        }
    }
};