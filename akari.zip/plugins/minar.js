import economy from '#economy';

export default {
    name: 'minar',
    alias: ['mine'],
    description: 'Mina y gana entre 10,000 y 50,000 monedas',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const cooldownTime = 3 * 60 * 1000;
            
            const lastUsed = await economy.getCooldown(from, userNumber, 'minar');
            const now = Date.now();
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const remaining = cooldownTime - (now - lastUsed);
                const minutos = Math.floor(remaining / 60000);
                const segundos = Math.floor((remaining % 60000) / 1000);
                return await replyWithContext(`❀ *Espera un poco*\n> Puedes minar de nuevo en ${minutos}m ${segundos}s`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const ganancia = Math.floor(Math.random() * (50000 - 10000 + 1)) + 10000;
            
            const minas = [
                'Encontraste un yacimiento de oro ⛏️',
                'Descubriste una veta de diamantes 💎',
                'Excavaste una mina de esmeraldas 🟢',
                'Hallaste un tesoro enterrado 🏴‍☠️'
            ];
            
            const mina = minas[Math.floor(Math.random() * minas.length)];
            
            await economy.updateUserEconomy(from, userNumber, {
                dinero: ganancia,
                nombre: pushName || 'Usuario'
            });
            
            await economy.setCooldown(from, userNumber, 'minar');
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`❀ *Minando* ⛏️\n> ${mina}\n> *Ganaste* ${economy.formatNumber(ganancia)} ${moneda}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en minar:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};