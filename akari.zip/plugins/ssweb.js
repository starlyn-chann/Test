import axios from 'axios';

export default {
    name: 'ssweb',
    alias: ['screenshot', 'captura'],
    description: 'Toma una captura de pantalla de una página web',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args[0];
            
            if (!url) {
                return await replyWithContext(`「✰」 Debes proporcionar una URL para capturar\n> Ejemplo: ${config.prefix}ssweb https://ejemplo.com`);
            }
            
            // Validar URL
            if (!url.startsWith('http://') && !url.startsWith('https://')) {
                return await replyWithContext(`「✰」 Debes proporcionar una URL válida (con http:// o https://)`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📸', key: msg.key } });
            } catch (e) {}
            
            // Llamar a la API para capturar la web
            const apiUrl = `https://api.ikyyxd.my.id/tools/ssweb?url=${encodeURIComponent(url)}`;
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const imageBuffer = Buffer.from(response.data);
            
            // Enviar la imagen sin caption
            await sock.sendMessage(from, {
                image: imageBuffer,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Captura de pantalla tomada por ${pushName || userNumber}: ${url}`);
            
        } catch (error) {
            console.error('❌ Error en ssweb:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* No se pudo capturar la página\n> ${error.message}`);
            } catch (e) {}
        }
    }
};