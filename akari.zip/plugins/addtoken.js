import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import chalk from 'chalk';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PREMS_FILE = path.join(__dirname, '..', 'databases', 'prems.json');

if (!fs.existsSync(path.join(__dirname, '..', 'databases'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'databases'), { recursive: true });
}

function loadPrems() {
    try {
        if (fs.existsSync(PREMS_FILE)) {
            return JSON.parse(fs.readFileSync(PREMS_FILE, 'utf8'));
        }
    } catch (e) {}
    return {};
}

function savePrems(data) {
    try {
        fs.writeFileSync(PREMS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {}
}

function generateToken() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    for (let i = 0; i < 8; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
    return token;
}

function generateUniqueToken() {
    const prems = loadPrems();
    let token;
    let attempts = 0;
    do {
        token = generateToken();
        attempts++;
    } while (prems[token] && attempts < 100);
    return token;
}

function getTokenExpiration() {
    const now = Date.now();
    const days = 30;
    return now + (days * 24 * 60 * 60 * 1000);
}

export default {
    name: 'addtoken',
    alias: ['creartoken', 'gentoken'],
    description: 'Genera un token premium (solo owner)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { isOwner, replyWithContext, config, pushName } = options;
            
            if (!isOwner) {
                return await replyWithContext(`❀ *Solo el dueño del bot puede usar este comando*`);
            }
            
            const prems = loadPrems();
            const token = generateUniqueToken();
            const expires = getTokenExpiration();
            
            prems[token] = {
                token: token,
                numero: null,
                creado: Date.now(),
                expires: expires,
                activo: false
            };
            
            savePrems(prems);
            
            const fechaExpiracion = new Date(expires).toLocaleDateString('es-ES', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            await replyWithContext(`🪙 *Token Premium Generado*\n\n` +
                `🔑 *Token:* \`${token}\`\n` +
                `⏰ *Expira:* ${fechaExpiracion}\n` +
                `📌 *Estado:* Sin usar\n\n` +
                `> Usa \`${config.prefix}codepremium ${token}\` para vincular un bot premium`);
            
            console.log(chalk.green(`[ PREMIUM ] Token generado: ${token} por ${pushName}`));
            
        } catch (error) {
            console.error('❌ Error en addtoken:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};