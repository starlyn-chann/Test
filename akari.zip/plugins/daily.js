import economy from '#economy';
import db from '#db';

export default {
    name: 'daily',
    alias: ['recompensa', 'diario'],
    description: 'Reclama tu recompensa diaria',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || 'Golosinas';
            const now = Date.now();
            const TIEMPO_ESPERA = 24 * 60 * 60 * 1000;
            const fechaActual = economy.getFechaDia();
            
            // Obtener racha del usuario
            const rachaData = await economy.getDailyRacha(userNumber);
            const ultimoReclamoGrupo = await economy.getCooldown(from, userNumber, 'daily');
            let racha = rachaData.racha || 0;
            const ultimaFecha = rachaData.ultimaFecha || null;
            
            // Verificar cooldown por grupo (24 horas)
            if (ultimoReclamoGrupo > 0) {
                const tiempoRestante = (ultimoReclamoGrupo + TIEMPO_ESPERA) - now;
                if (tiempoRestante > 0) {
                    const horas = Math.floor(tiempoRestante / (60 * 60 * 1000));
                    const minutos = Math.floor((tiempoRestante % (60 * 60 * 1000)) / (60 * 1000));
                    return await replyWithContext(`❀ *Ya reclamaste tu daily en este grupo*\n> Vuelve en ${horas}h ${minutos}m`);
                }
            }
            
            // Verificar racha global
            if (ultimaFecha !== fechaActual) {
                if (ultimaFecha) {
                    const fechaAnterior = new Date(ultimaFecha);
                    const fechaActualObj = new Date(fechaActual);
                    const diffDias = Math.floor((fechaActualObj - fechaAnterior) / (24 * 60 * 60 * 1000));
                    
                    if (diffDias > 3) {
                        racha = 0;
                    } else if (diffDias === 1) {
                        racha++;
                    } else if (diffDias > 1) {
                        racha = 0;
                    }
                } else {
                    racha = 1;
                }
            }
            
            // Guardar racha
            await economy.updateDailyRacha(userNumber, {
                racha: racha,
                ultimaFecha: fechaActual,
                ultimoReclamoGlobal: now
            });
            
            // Guardar cooldown por grupo
            await economy.setCooldown(from, userNumber, 'daily');
            
            // Dar recompensa
            const recompensa = economy.calcularRecompensaDaily(racha);
            const siguienteRecompensa = economy.calcularRecompensaDaily(racha + 1);
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            await economy.updateUserEconomy(from, userNumber, {
                dinero: recompensa,
                nombre: pushName || 'Usuario'
            });
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            let mensaje = `「✿」Has reclamado tu recompensa diaria de *${economy.formatNumber(recompensa)} ${moneda}*! (Día *${racha}*)\n`;
            mensaje += `> Día *${racha + 1}* » *+${economy.formatNumber(siguienteRecompensa)}*\n`;
            mensaje += `> _¡Sigue reclamando seguido para aumentar tu daily!_\n\n`;
            mensaje += `*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${moneda}`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en daily:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};