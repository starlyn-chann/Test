// plugins/testv2.js

import { terabox } from '@danonino/moon';

export default {
    name: 'testv2',
    alias: ['terabox'],
    description: 'Descarga videos de Terabox',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(
                    `📦 *Terabox Downloader*\n\n` +
                    `Descarga videos de Terabox\n` +
                    `Ejemplo: ${config.prefix}testv2 https://1024terabox.com/s/xxxxx`
                );
            }
            
            const isTeraboxUrl = query.includes('terabox.com') || query.includes('1024terabox.com');
            if (!isTeraboxUrl) {
                return await replyWithContext(
                    `❌ *URL no válida*\n\n` +
                    `Por favor, proporciona un enlace de Terabox válido.\n` +
                    `Ejemplo: ${config.prefix}testv2 https://1024terabox.com/s/xxxxx`
                );
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext('⏳ *Obteniendo información del video...*');
            
            const result = await terabox(query);
            
            if (!result.success) {
                await replyWithContext(`❌ *Error:* ${result.message}`);
                try {
                    await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            const jsonText = `📦 *Resultado del scraper:*\n\n` +
                           `\`\`\`json\n${JSON.stringify(result, null, 2)}\n\`\`\``;
            
            await replyWithContext(jsonText);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`📦 Video Terabox obtenido: ${result.fileName} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en testv2:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}`);
            } catch (e) {}
        }
    }
};