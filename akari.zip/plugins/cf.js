import economy from '#economy';

export default {
    name: 'cf',
    alias: ['coinflip', 'caraocruz'],
    description: 'Apuesta a cara o cruz',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName, args }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length < 2) {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Ejemplo: ${config.prefix}cf 1000 cara\n> ${config.prefix}cf cruz 500`);
            }
            
            let cantidad = 0;
            let lado = '';
            
            const firstArg = args[0].toLowerCase();
            const secondArg = args[1].toLowerCase();
            
            if (!isNaN(firstArg) && parseInt(firstArg) > 0) {
                cantidad = parseInt(firstArg);
                lado = secondArg;
            } else if (!isNaN(secondArg) && parseInt(secondArg) > 0) {
                cantidad = parseInt(secondArg);
                lado = firstArg;
            } else {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Ejemplo: ${config.prefix}cf 1000 cara\n> ${config.prefix}cf cruz 500`);
            }
            
            if (cantidad <= 0) {
                return await replyWithContext(`「✰」 La cantidad debe ser mayor a 0`);
            }
            
            if (lado !== 'cara' && lado !== 'cruz') {
                return await replyWithContext(`「✰」 Solo puedes apostar a *cara* o *cruz*`);
            }
            
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const dineroActual = userEconomy.dinero || 0;
            
            if (cantidad > dineroActual) {
                return await replyWithContext(`❀ *No tienes suficiente dinero*\n> Billetera: ${economy.formatNumber(dineroActual)} ${config.moneda}`);
            }
            
            const resultado = Math.random() < 0.5 ? 'cara' : 'cruz';
            const esGanador = lado === resultado;
            
            let mensaje = '';
            
            if (esGanador) {
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: cantidad,
                    nombre: pushName || 'Usuario'
                });
                mensaje = `✧ Apuestas a *${lado}* y ganaste ${economy.formatNumber(cantidad)} ${config.moneda}`;
            } else {
                await economy.updateUserEconomy(from, userNumber, {
                    dinero: -cantidad,
                    nombre: pushName || 'Usuario'
                });
                mensaje = `✧ Apuestas a *${lado}* y perdiste ${economy.formatNumber(cantidad)} ${config.moneda}`;
            }
            
            const updatedEconomy = await economy.getUserEconomy(from, userNumber);
            
            await replyWithContext(`${mensaje}\n\n*Billetera:* ${economy.formatNumber(updatedEconomy.dinero)} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en cf:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};