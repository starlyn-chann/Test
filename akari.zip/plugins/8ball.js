export default {
    name: '8ball',
    alias: ['bola8'],
    description: 'Haz una pregunta y obtén una respuesta aleatoria',
    category: 'fun',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, senderJid, args } = options;
            const from = msg.key.remoteJid;
            
            const pregunta = args.join(' ').trim();
            
            if (!pregunta) {
                return await replyWithContext(`「✰」Debes hacer una pregunta\n> Ejemplo: ${config.prefix}8ball ¿Soy gay?`);
            }
            
            const respuestas = ['Sí', 'No', 'Tal vez', 'Definitivamente sí', 'Definitivamente no', 'No sé', 'Pregunta de nuevo', 'Sin duda', 'No cuentes con ello', 'Sí, claro', 'Ni loco'];
            const respuesta = respuestas[Math.floor(Math.random() * respuestas.length)];
            
            await replyWithContext(`🎱 *Pregunta:* ${pregunta}\n🔮 *Respuesta:* ${respuesta}`);
            
        } catch (error) {
            console.error('❌ Error en 8ball:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};