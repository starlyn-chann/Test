import { 
    obtenerPersonajePorNombre, 
    obtenerPersonajePorId,
    verificarReclamo,
    obtenerPersonajesReclamados,
    reclamarPersonaje,
    eliminarReclamo
} from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function getDisplayName(number) {
    const users = loadUsersDb();
    const user = users.find(u => u.number === number);
    return user ? user.pushName : number;
}

// Cache para intercambios pendientes
const pendingTrade = {};

export default {
    name: 'trade',
    alias: ['intercambiar', 'intercambio'],
    description: 'Intercambia un personaje con otro usuario',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando trade...');
            
            const { config, replyWithContext, args, userNumber, senderJid, pushName, quotedMsg, quotedMessage, quotedText } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`⭐ *Este comando solo funciona en grupos*`);
            }
            
            // ============ VERIFICAR SI ES UNA ACEPTACIÓN ============
            const esAceptar = args.length >= 1 && args[0].toLowerCase() === 'aceptar';
            
            if (esAceptar) {
                // Verificar que se está respondiendo a un mensaje
                if (!quotedMsg || !quotedMessage) {
                    return await replyWithContext(`❀ Debes responder al mensaje de solicitud de intercambio.`);
                }
                
                // Verificar que el mensaje citado contiene "SOLICITUD DE INTERCAMBIO"
                const textoCitado = quotedText || '';
                const esSolicitud = textoCitado.includes('SOLICITUD DE INTERCAMBIO') || 
                                   textoCitado.includes('solicitud de intercambio');
                
                if (!esSolicitud) {
                    return await replyWithContext(`❀ Debes responder al mensaje de solicitud de intercambio.`);
                }
                
                const tradeKey = `trade_${from}`;
                const tradeData = pendingTrade[tradeKey];
                
                if (!tradeData) {
                    return await replyWithContext(`❀ No hay solicitud de intercambio pendiente.`);
                }
                
                // Verificar que el usuario que acepta sea el receptor
                if (tradeData.to !== userNumber) {
                    return await replyWithContext(`ꕥ Solo el usuario al que va dirigida la solicitud puede aceptar.`);
                }
                
                // Verificar que los personajes sigan existiendo y reclamados
                const reclamados = await obtenerPersonajesReclamados(from);
                const reclamoA = reclamados.find(r => r.personajeId === tradeData.give);
                const reclamoB = reclamados.find(r => r.personajeId === tradeData.get);
                
                if (!reclamoA || !reclamoB) {
                    delete pendingTrade[tradeKey];
                    return await replyWithContext(`⚠︎ Uno de los personajes ya no está disponible para el intercambio.`);
                }
                
                // Verificar que sigan siendo de los mismos dueños
                if (reclamoA.usuarioId !== tradeData.from || reclamoB.usuarioId !== tradeData.to) {
                    delete pendingTrade[tradeKey];
                    return await replyWithContext(`⚠︎ Uno de los personajes ya no está disponible para el intercambio.`);
                }
                
                // ============ REALIZAR INTERCAMBIO ============
                await eliminarReclamo(from, tradeData.give);
                await eliminarReclamo(from, tradeData.get);
                await reclamarPersonaje(from, tradeData.give, tradeData.to);
                await reclamarPersonaje(from, tradeData.get, tradeData.from);
                
                clearTimeout(tradeData.timeout);
                delete pendingTrade[tradeKey];
                
                const nameFrom = getDisplayName(tradeData.from);
                const nameTo = getDisplayName(tradeData.to);
                
                const mensajeExito = 
`「✿」 *INTERCAMBIO ACEPTADO!*

✦ *${nameTo}* » ${tradeData.giveName}
✦ *${nameFrom}* » ${tradeData.getName}

✅ ¡El intercambio se ha completado exitosamente!`;

                await replyWithContext(mensajeExito);
                console.log(`✅ Intercambio completado: ${tradeData.from} ↔ ${tradeData.to}`);
                return;
            }
            // ================================================================
            
            // ============ CREAR NUEVA SOLICITUD DE INTERCAMBIO ============
            // Verificar si hay un intercambio en curso en este grupo
            const tradeKey = `trade_${from}`;
            const tradeData = pendingTrade[tradeKey];
            if (tradeData && tradeData.timeout) {
                const tiempoRestante = Math.ceil((tradeData.timeout - Date.now()) / 1000);
                if (tiempoRestante > 0) {
                    return await replyWithContext(`《✧》 Ya hay un intercambio en curso. Espera ${tiempoRestante}s a que se complete o expire.`);
                } else {
                    delete pendingTrade[tradeKey];
                }
            }
            
            if (args.length < 2) {
                return await replyWithContext(
                    `❀ Debes especificar dos personajes para intercambiarlos.\n> ✐ Ejemplo: *${config.prefix}trade Personaje1 / Personaje2*`
                );
            }
            
            const texto = args.join(' ');
            const partes = texto.split('/').map(p => p.trim());
            
            if (partes.length !== 2) {
                return await replyWithContext(
                    `❀ Debes especificar dos personajes para intercambiarlos.\n> ✐ Ejemplo: *${config.prefix}trade Personaje1 / Personaje2*`
                );
            }
            
            const [nombreA, nombreB] = partes;
            
            if (!nombreA || !nombreB) {
                return await replyWithContext(
                    `❀ Debes especificar dos personajes para intercambiarlos.\n> ✐ Ejemplo: *${config.prefix}trade Personaje1 / Personaje2*`
                );
            }
            
            // ============ BUSCAR PERSONAJES ============
            let personajeA = await obtenerPersonajePorNombre(nombreA);
            let personajeB = await obtenerPersonajePorNombre(nombreB);
            
            // Buscar por nombre invertido
            if (!personajeA) {
                const palabrasA = nombreA.trim().split(/\s+/);
                if (palabrasA.length > 1) {
                    const nombreInvertidoA = palabrasA.reverse().join(' ');
                    personajeA = await obtenerPersonajePorNombre(nombreInvertidoA);
                }
            }
            
            if (!personajeB) {
                const palabrasB = nombreB.trim().split(/\s+/);
                if (palabrasB.length > 1) {
                    const nombreInvertidoB = palabrasB.reverse().join(' ');
                    personajeB = await obtenerPersonajePorNombre(nombreInvertidoB);
                }
            }
            
            // Buscar por coincidencia parcial
            if (!personajeA) {
                const { obtenerTodosPersonajes } = await import('../lib/gacha.js');
                const todos = await obtenerTodosPersonajes();
                const nombreLowerA = nombreA.toLowerCase();
                for (const pj of todos) {
                    if (pj.nombre.toLowerCase().includes(nombreLowerA) || nombreLowerA.includes(pj.nombre.toLowerCase())) {
                        personajeA = pj;
                        break;
                    }
                }
            }
            
            if (!personajeB) {
                const { obtenerTodosPersonajes } = await import('../lib/gacha.js');
                const todos = await obtenerTodosPersonajes();
                const nombreLowerB = nombreB.toLowerCase();
                for (const pj of todos) {
                    if (pj.nombre.toLowerCase().includes(nombreLowerB) || nombreLowerB.includes(pj.nombre.toLowerCase())) {
                        personajeB = pj;
                        break;
                    }
                }
            }
            
            if (!personajeA || !personajeB) {
                const noEncontrado = !personajeA ? nombreA : nombreB;
                return await replyWithContext(`❀ No se encontró el personaje *"${noEncontrado}"*`);
            }
            
            if (personajeA.id === personajeB.id) {
                return await replyWithContext(`❀ No puedes intercambiar el mismo personaje.`);
            }
            // ================================================================
            
            // ============ VERIFICAR RECLAMOS ============
            const reclamados = await obtenerPersonajesReclamados(from);
            
            const reclamoA = reclamados.find(r => r.personajeId === personajeA.id);
            const reclamoB = reclamados.find(r => r.personajeId === personajeB.id);
            
            // Verificar que el personaje A esté reclamado por el usuario
            if (!reclamoA) {
                return await replyWithContext(`❀ *${personajeA.nombre}* no está reclamado por nadie en este grupo.`);
            }
            
            if (reclamoA.usuarioId !== userNumber) {
                const nombreDueno = getDisplayName(reclamoA.usuarioId);
                return await replyWithContext(`❀ *${personajeA.nombre}* está reclamado por *${nombreDueno}*, no por ti.`);
            }
            
            // Verificar que el personaje B esté reclamado por alguien
            if (!reclamoB) {
                return await replyWithContext(`❀ *${personajeB.nombre}* no está reclamado por nadie en este grupo.`);
            }
            
            const receiverId = reclamoB.usuarioId;
            
            if (receiverId === userNumber) {
                return await replyWithContext(`❀ *${personajeB.nombre}* ya está reclamado por ti.`);
            }
            // ================================================================
            
            // ============ CREAR SOLICITUD DE INTERCAMBIO ============
            const receiverName = getDisplayName(receiverId);
            const senderName = pushName || userNumber;
            const receiverJid = `${receiverId}@s.whatsapp.net`;
            
            // Guardar solicitud pendiente con timeout
            const timeoutDuration = 60000; // 60 segundos
            const timeoutId = setTimeout(async () => {
                if (pendingTrade[tradeKey]) {
                    delete pendingTrade[tradeKey];
                    try {
                        await sock.sendMessage(from, { 
                            text: `⚠︎ *La solicitud de intercambio ha expirado*`
                        });
                    } catch (e) {}
                    console.log(`⚠︎ Solicitud de intercambio expirada en ${from}`);
                }
            }, timeoutDuration);
            
            pendingTrade[tradeKey] = {
                from: userNumber,
                to: receiverId,
                chat: from,
                give: personajeA.id,
                get: personajeB.id,
                giveName: personajeA.nombre,
                getName: personajeB.nombre,
                giveValue: personajeA.valor || 0,
                getValue: personajeB.valor || 0,
                timeout: timeoutId,
                timestamp: Date.now()
            };
            // ================================================================
            
            // ============ ENVIAR MENSAJE DE SOLICITUD ============
            const mensaje = 
`「✿」 *SOLICITUD DE INTERCAMBIO*

*${senderName}* te ha enviado una solicitud de intercambio.

✦ [${senderName}] *${personajeA.nombre}* (${personajeA.valor || 0})
✦ [${receiverName}] *${personajeB.nombre}* (${personajeB.valor || 0})

✐ Para aceptar responde a este mensaje con *${config.prefix}trade aceptar*
⚠︎ La solicitud expira en 60 segundos.`;

            await sock.sendMessage(from, {
                text: mensaje,
                mentions: [senderJid, receiverJid]
            }, { quoted: msg });
            // ================================================================
            
            console.log(`✅ trade ejecutado: ${senderName} → ${receiverName} (${personajeA.nombre} ↔ ${personajeB.nombre})`);
            
        } catch (error) {
            console.error('❌ Error en trade:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};