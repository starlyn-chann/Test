import axios from 'axios';

// API de búsqueda de Apple Music
const API_APPLE_SEARCH = 'https://api.nexray.eu.cc/search/applemusic';

export default {
    name: 'applesearch',
    alias: ['musicsearch'],
    description: 'Busca canciones en Apple Music',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const query = args.join(' ').trim();

            if (!query) {
                return await replyWithContext(`「✰」Debes proporcionar una búsqueda\n> Ejemplo: ${config.prefix}applesearch Boss Bitch`);
            }

            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}

            // --- LLAMAR A LA API DE BÚSQUEDA ---
            let searchResults = [];

            try {
                const response = await axios.get(`${API_APPLE_SEARCH}?q=${encodeURIComponent(query)}`, {
                    timeout: 30000,
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                });

                if (!response.data?.status || !response.data?.result) {
                    throw new Error('Respuesta inválida de la API');
                }

                searchResults = response.data.result;

                if (!searchResults || searchResults.length === 0) {
                    throw new Error('No se encontraron resultados');
                }

                console.log(`✅ Apple Search: ${searchResults.length} resultados para "${query}"`);

            } catch (apiError) {
                console.error('❌ Error con API:', apiError.message);
                throw new Error(`No se pudo realizar la búsqueda: ${apiError.message}`);
            }

            // --- MEZCLAR Y SELECCIONAR 10 RESULTADOS ALEATORIOS ---
            const shuffledResults = [...searchResults];
            for (let i = shuffledResults.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [shuffledResults[i], shuffledResults[j]] = [shuffledResults[j], shuffledResults[i]];
            }
            
            const selectedResults = shuffledResults.slice(0, 10);

            // --- CONSTRUIR MENSAJE CON FORMATO SOLICITADO ---
            let responseText = `❀ \`\`\`A P P L E - M U S I C\`\`\` ❀\n\n`;
            
            for (let i = 0; i < selectedResults.length; i++) {
                const result = selectedResults[i];
                responseText += `⭐᳹᷼ํ Ⳋ *Title ::* ${result.title || 'Sin título'}\n`;
                responseText += `⭐᳹᷼ํ Ⳋ *Subtitle ::* ${result.subtitle || 'Sin información'}\n`;
                responseText += `⭐᳹᷼ํ Ⳋ *Link ::* ${result.link || 'No disponible'}\n`;
                if (i < selectedResults.length - 1) responseText += `\n`;
            }

            // Enviar resultados como texto
            await sock.sendMessage(from, { text: responseText }, { quoted: msg });

            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

            console.log(`✅ Apple Search completado: ${selectedResults.length} resultados mostrados para "${query}" por ${pushName || userNumber}`);

        } catch (error) {
            console.error('❌ Error en applesearch:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `❌ *Error:* ${error.message}`;
            if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                errorMsg += `\n\n⏰ La búsqueda tardó demasiado. Por favor, intenta de nuevo.`;
            } else if (error.message.includes('No se encontraron resultados')) {
                errorMsg = `🔍 No se encontraron resultados para "${args.join(' ')}"`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};