import db from '#db';

export default {
    name: 'top',
    alias: ['rank', 'topexp'],
    description: 'Muestra el top de usuarios con más experiencia',
    category: 'main',
    
    async execute(sock, msg, { args, config, replyWithContext, isGroup }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Obtener todos los usuarios de la base de datos
            const allUsers = await db.getAllUsers();
            
            if (!allUsers || allUsers.length === 0) {
                return await replyWithContext(`❀ *No hay usuarios registrados*`);
            }
            
            let pagina = 1;
            if (args && args.length > 0) {
                const num = parseInt(args[0]);
                if (!isNaN(num) && num > 0) {
                    pagina = num;
                }
            }
            
            const USUARIOS_POR_PAGINA = 10;
            
            // Ordenar por experiencia (mayor a menor)
            const usuariosOrdenados = [...allUsers].sort((a, b) => (b.exp || 0) - (a.exp || 0));
            
            const totalUsuarios = usuariosOrdenados.length;
            const totalPaginas = Math.ceil(totalUsuarios / USUARIOS_POR_PAGINA);
            
            if (pagina > totalPaginas) {
                return await replyWithContext(`❀ *Página no válida*\n> Hay ${totalPaginas} páginas disponibles`);
            }
            
            const inicio = (pagina - 1) * USUARIOS_POR_PAGINA;
            const fin = Math.min(inicio + USUARIOS_POR_PAGINA, totalUsuarios);
            const usuariosPagina = usuariosOrdenados.slice(inicio, fin);
            
            function formatNumber(num) {
                if (!num) return '0';
                return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
            
            let mensaje = `❀ *Top Experiencia Global*\n\n`;
            
            const mentions = [];
            for (let i = 0; i < usuariosPagina.length; i++) {
                const user = usuariosPagina[i];
                const posicion = inicio + i + 1;
                const exp = user.exp || 0;
                const nivel = user.nivel || 1;
                const nombre = user.pushName || 'Usuario';
                const userId = user.number || user._id;
                const jid = userId + '@s.whatsapp.net';
                mentions.push(jid);
                
                mensaje += `${posicion} ✰᪲͜ᮬ ${nombre}\n`;
                mensaje += `> ${formatNumber(exp)} EXP » Nivel ${nivel}\n\n`;
            }
            
            mensaje += `> *Lista (${pagina}) de (${totalPaginas})*`;
            
            await replyWithContext(mensaje, mentions);
            
        } catch (error) {
            console.error('❌ Error en top:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};