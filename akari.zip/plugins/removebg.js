import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import FormData from 'form-data';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const REMOVEBG_API = 'https://api-varhad.my.id/tools/removebg';

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    if (typeof res.data !== 'string' || !res.data.startsWith('https://')) {
        throw new Error('Respuesta inválida de Catbox');
    }
    return res.data;
}

async function uploadUguu(buffer) {
    const form = new FormData();
    form.append('files[]', buffer, generateUniqueFilename('image/jpeg'));

    const res = await axios.post('https://uguu.se/upload.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    const url = res.data?.files?.[0]?.url;
    if (!url) throw new Error('Respuesta inválida de Uguu');
    return url;
}

async function uploadQuax(buffer, mime) {
    const form = new FormData();
    form.append('file', buffer, { filename: generateUniqueFilename(mime), contentType: mime });

    const res = await axios.post('https://qu.ax/upload.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    const url = res.data?.files?.[0]?.url;
    if (!url) throw new Error('Respuesta inválida de Quax');
    return url;
}

async function uploadAuto(buffer, mime) {
    try {
        return { link: await uploadCatbox(buffer, mime), server: 'catbox' };
    } catch {
        try {
            return { link: await uploadUguu(buffer), server: 'uguu' };
        } catch {
            return { link: await uploadQuax(buffer, mime), server: 'quax' };
        }
    }
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'removebg',
    alias: ['quitarfondo', 'nobg'],
    description: 'Elimina el fondo de una imagen',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { config, senderJid, pushName, userNumber, replyWithContext, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage) {
                return await replyWithContext(`🌵 Debes responder a una imagen\n\n> Ejemplo: Responde a una imagen con ${config.prefix}removebg`);
            }
            
            let imageBuffer = null;
            let mime = 'image/jpeg';
            
            if (quotedMessage.imageMessage) {
                const imageMsg = quotedMessage.imageMessage;
                mime = imageMsg.mimetype || 'image/jpeg';
                
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        imageMessage: imageMsg
                    }
                };
                
                imageBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            } else {
                return await replyWithContext(`🌵 Debes responder a una imagen`);
            }
            
            if (!imageBuffer || imageBuffer.length === 0) {
                throw new Error('No se pudo descargar la imagen');
            }
            
            if (imageBuffer.length > 5 * 1024 * 1024) {
                return await replyWithContext(`🌵 La imagen es demasiado grande (máx 5MB)`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🖼️', key: msg.key } });
            } catch (e) {}
            
            const upload = await uploadAuto(imageBuffer, mime);
            console.log(`✅ Imagen subida a ${upload.server}: ${upload.link}`);
            
            const response = await axios.get(`${REMOVEBG_API}?imageUrl=${encodeURIComponent(upload.link)}`, {
                responseType: 'arraybuffer',
                timeout: 60000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('No se pudo eliminar el fondo');
            }
            
            const resultBuffer = Buffer.from(response.data);
            
            await sock.sendMessage(from, {
                image: resultBuffer,
                caption: `> solicitado por : ${pushName || userNumber}`,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Fondo eliminado por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en removebg:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                await replyWithContext(`❌ *Error:* ${error.message}`);
            } catch (e) {}
        }
    }
};