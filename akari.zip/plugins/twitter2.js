import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import { promisify } from 'util';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execAsync = promisify(exec);

const APIS = [
    {
        name: 'OotaIzumi',
        url: 'https://api.ootaizumi.web.id/downloader/twitter',
        getMedia: (data) => {
            if (!data.status || !data.result || data.result.length === 0) return null;
            return data.result.map(item => ({
                type: item.type === 'image' ? 'photo' : item.type,
                link: item.link
            }));
        }
    },
    {
        name: 'NexRay',
        url: 'https://api.nexray.web.id/downloader/twitter',
        getMedia: (data) => {
            if (!data.status || !data.result) return null;
            const downloadUrls = data.result.download_url || [];
            if (downloadUrls.length === 0) return null;
            return downloadUrls.map(item => ({
                type: item.type === 'image' ? 'photo' : 'video',
                link: item.url,
                thumbnail: item.thumbnail
            }));
        }
    }
];

export default {
    name: 'twitter2',
    alias: ['tw2', 'x2'],
    description: 'Descarga videos e imágenes de Twitter/X',
    category: 'download',
    
    async execute(sock, msg, options) {
        let tempFile = null;
        let convertedFile = null;
        
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const url = args[0];
            
            if (!url) {
                return await replyWithContext(`「✰」 Te faltó el link de una imagen/video de Twitter/X.\n> Uso: ${config.prefix}twitter [enlace]`);
            }
            
            if (!url.includes('twitter.com') && !url.includes('x.com')) {
                return await replyWithContext(`♡ Eso no parece ser un enlace de Twitter/X válido`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            let mediaItems = null;
            
            for (const api of APIS) {
                try {
                    const response = await axios.get(api.url, {
                        params: { url: url },
                        timeout: 30000,
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    mediaItems = api.getMedia(response.data);
                    
                    if (mediaItems && mediaItems.length > 0) {
                        console.log(`✅ ${mediaItems.length} archivos encontrados`);
                        break;
                    }
                    
                } catch (error) {
                    console.log(`⚠️ API falló: ${error.message}`);
                    continue;
                }
            }
            
            if (!mediaItems || mediaItems.length === 0) {
                throw new Error('No se pudo obtener el contenido');
            }
            
            const videos = mediaItems.filter(item => item.type === 'video' && item.link);
            const photos = mediaItems.filter(item => (item.type === 'photo' || item.type === 'image') && item.link);
            
            const tempDir = path.join(__dirname, '..', 'temp');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            
            if (videos.length > 0) {
                const videoUrl = videos[0].link;
                
                console.log(`📥 Descargando video...`);
                
                tempFile = path.join(tempDir, `twitter_${Date.now()}.mp4`);
                convertedFile = path.join(tempDir, `twitter_conv_${Date.now()}.mp4`);
                
                const videoResponse = await axios({
                    method: 'get',
                    url: videoUrl,
                    responseType: 'stream',
                    timeout: 120000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Referer': 'https://twitter.com/'
                    }
                });
                
                const writer = fs.createWriteStream(tempFile);
                videoResponse.data.pipe(writer);
                
                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve);
                    writer.on('error', reject);
                });
                
                const stats = fs.statSync(tempFile);
                const sizeMB = stats.size / (1024 * 1024);
                console.log(`✅ Video descargado: ${sizeMB.toFixed(2)} MB`);
                
                if (sizeMB > 100) {
                    throw new Error('El video es demasiado pesado (máx 100MB)');
                }
                
                let videoBuffer = fs.readFileSync(tempFile);
                
                try {
                    await sock.sendMessage(from, {
                        video: videoBuffer,
                        mimetype: 'video/mp4',
                        caption: `✿ *Twitter Download* ✿`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    console.log(`✅ Video enviado`);
                    
                } catch (sendError) {
                    console.log(`⚠️ Necesita conversión`);
                    
                    await execAsync(`ffmpeg -i "${tempFile}" -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 64k -movflags +faststart -vf "scale=ceil(iw/2)*2:ceil(ih/2)*2" -pix_fmt yuv420p -r 24 -max_muxing_queue_size 1024 "${convertedFile}" -y -loglevel error`);
                    
                    videoBuffer = fs.readFileSync(convertedFile);
                    console.log(`✅ Video convertido: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);
                    
                    await sock.sendMessage(from, {
                        video: videoBuffer,
                        mimetype: 'video/mp4',
                        caption: `✿ *Twitter Download* ✿`,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
                
            } else if (photos.length > 0) {
                for (let i = 0; i < photos.length; i++) {
                    const photoUrl = photos[i].link;
                    
                    console.log(`📥 Descargando imagen ${i + 1}/${photos.length}...`);
                    
                    try {
                        const imageResponse = await axios({
                            method: 'get',
                            url: photoUrl,
                            responseType: 'arraybuffer',
                            timeout: 30000,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                            }
                        });
                        
                        const imageBuffer = Buffer.from(imageResponse.data);
                        
                        const caption = photos.length > 1 
                            ? `✿ *Twitter Download* ✿\n> Imagen ${i + 1}/${photos.length}`
                            : `✿ *Twitter Download* ✿`;
                        
                        await sock.sendMessage(from, {
                            image: imageBuffer,
                            caption: caption,
                            contextInfo: {
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                        
                        console.log(`✅ Imagen ${i + 1} enviada: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
                        
                    } catch (imgError) {
                        console.log(`⚠️ Error descargando imagen ${i + 1}: ${imgError.message}`);
                    }
                }
                
            } else {
                throw new Error('No se encontró contenido descargable');
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Twitter descargado por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en twitter:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`ꕤ Error: ${error.message}`);
            } catch (e) {}
            
        } finally {
            setTimeout(() => {
                try { if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (e) {}
                try { if (convertedFile && fs.existsSync(convertedFile)) fs.unlinkSync(convertedFile); } catch (e) {}
            }, 5000);
        }
    }
};