import axios from 'axios';
import { connectMongoDB } from '../lib/mongoose.js';

// ============ ESQUEMA Y MODELO PARA HISTORIAL ============
let HistorialModel = null;
let mongoose = null;

async function getHistorialModel() {
    if (HistorialModel) return HistorialModel;
    
    const { default: mongooseMod } = await import('mongoose');
    mongoose = mongooseMod;
    
    await connectMongoDB();
    
    const historialSchema = new mongoose.Schema({
        _id: { type: String, required: true },
        conversacion: { type: Array, default: [] },
        ultimaActualizacion: { type: Date, default: Date.now }
    });
    
    HistorialModel = mongoose.model('HistorialChatGPT', historialSchema);
    return HistorialModel;
}

// ============ FUNCIONES PARA HISTORIAL ============
async function getHistorialUsuario(userNumber) {
    try {
        const model = await getHistorialModel();
        const usuario = await model.findOne({ _id: userNumber });
        if (!usuario) return [];
        return usuario.conversacion || [];
    } catch (error) {
        console.error('Error cargando historial:', error);
        return [];
    }
}

async function addToHistorial(userNumber, role, content) {
    try {
        const model = await getHistorialModel();
        const usuario = await model.findOne({ _id: userNumber });
        
        const nuevoMensaje = {
            role: role,
            content: content,
            timestamp: new Date().toISOString()
        };
        
        if (usuario) {
            usuario.conversacion.push(nuevoMensaje);
            if (usuario.conversacion.length > 20) {
                usuario.conversacion = usuario.conversacion.slice(-20);
            }
            usuario.ultimaActualizacion = new Date();
            await usuario.save();
        } else {
            const nuevoUsuario = new model({
                _id: userNumber,
                conversacion: [nuevoMensaje]
            });
            await nuevoUsuario.save();
        }
        return true;
    } catch (error) {
        console.error('Error guardando historial:', error);
        return false;
    }
}

function construirContexto(historial, nuevaPregunta) {
    let contexto = '';
    
    for (const msg of historial) {
        if (msg.role === 'user') {
            contexto += `Usuario: ${msg.content}\n`;
        } else {
            contexto += `ChatGPT: ${msg.content}\n`;
        }
    }
    
    contexto += `Usuario: ${nuevaPregunta}\nChatGPT:`;
    
    return contexto;
}

export default {
    name: 'chatgpt',
    alias: ['gpt', 'openai'],
    description: 'Pregunta algo a ChatGPT AI',
    category: 'ai',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const prompt = args.join(' ').trim();
            
            if (!prompt) {
                return await replyWithContext(`「✰」Debes proporcionar una pregunta para ChatGPT`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⭐', key: msg.key } });
            } catch (e) {}
            
            // Guardar pregunta del usuario en MongoDB
            await addToHistorial(userNumber, 'user', prompt);
            
            // Obtener historial y construir contexto
            const historial = await getHistorialUsuario(userNumber);
            const contexto = construirContexto(historial, prompt);
            
            console.log(`📝 Contexto para ${pushName || userNumber}: ${historial.length} mensajes previos`);
            
            const apiUrl = `https://api.alwayscodex.my.id/api/ai/grokv2?teks=${encodeURIComponent(contexto)}&model=gpt-oss-120b`;
            
            const response = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/json'
                }
            });
            
            let answer = null;
            
            if (response.data?.status && response.data?.data?.answer) {
                answer = response.data.data.answer;
            }
            
            if (!answer) {
                throw new Error('No se pudo obtener respuesta');
            }
            
            // Guardar respuesta del bot en MongoDB
            await addToHistorial(userNumber, 'assistant', answer);
            
            // ✅ ELIMINADO EL TRUNCAMIENTO - Envía la respuesta completa
            await replyWithContext(`\`\`\`${answer}\`\`\``);
            
            try {
                await sock.sendMessage(from, { react: { text: '🌟', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ ChatGPT respondió para ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en chatgpt:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* No se pudo obtener respuesta. Intenta más tarde.`);
            } catch (e) {}
        }
    }
};