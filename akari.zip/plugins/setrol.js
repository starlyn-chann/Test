import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROLES_FILE = path.join(__dirname, '..', 'data', 'roles.json');

// Asegurar que la carpeta data existe
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

// Cargar roles desde archivo
function loadRoles() {
    try {
        if (fs.existsSync(ROLES_FILE)) {
            const data = fs.readFileSync(ROLES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando roles:', error);
    }
    return {};
}

// Guardar roles en archivo
function saveRoles(roles) {
    try {
        fs.writeFileSync(ROLES_FILE, JSON.stringify(roles, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando roles:', error);
        return false;
    }
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

export default {
    name: 'setrole',
    alias: ['setrol', 'role'],
    description: 'Asigna un rol a un usuario (Solo owner)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando setrole...');
            
            const { args, config, replyWithContext, userNumber, isOwner, senderJid } = options;
            const from = msg.key.remoteJid;
            
            // Solo owner puede usar este comando
            if (!isOwner) {
                return; // No responder nada, silencioso
            }
            
            // Verificar si hay un rol y un usuario
            if (args.length < 2) {
                return await replyWithContext(
                    `❀ *USO DEL COMANDO*\n\n` +
                    `📌 *Formato:*\n` +
                    `${config.prefix}setrole <rol> @usuario\n\n` +
                    `📌 *Roles disponibles:*\n` +
                    `• sub-owner\n` +
                    `• mod\n` +
                    `• aspirante\n\n` +
                    `📌 *Ejemplos:*\n` +
                    `${config.prefix}setrole mod @usuario\n` +
                    `${config.prefix}setrole sub-owner @usuario`
                );
            }
            
            // Obtener el rol (primer argumento)
            const rol = args[0].toLowerCase();
            const rolesValidos = ['sub-owner', 'mod', 'aspirante'];
            
            if (!rolesValidos.includes(rol)) {
                return await replyWithContext(
                    `❀ *Rol inválido*\n\n` +
                    `📌 *Roles disponibles:*\n` +
                    `• sub-owner\n` +
                    `• mod\n` +
                    `• aspirante\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}setrole mod @usuario`
                );
            }
            
            // Obtener el usuario target (mencionado o respondido)
            let targetNumber = null;
            let targetJid = null;
            
            // Verificar si hay mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (mentionedJid) {
                targetJid = mentionedJid;
                targetNumber = cleanNumber(mentionedJid);
            } else {
                // Verificar si se está respondiendo a un mensaje
                const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
                const quotedMessage = quotedMsg?.quotedMessage;
                
                if (quotedMsg && quotedMessage) {
                    const quotedParticipant = quotedMsg?.participant || quotedMsg?.remoteJid;
                    if (quotedParticipant) {
                        targetJid = quotedParticipant;
                        targetNumber = cleanNumber(quotedParticipant);
                    }
                }
            }
            
            if (!targetNumber) {
                return await replyWithContext(
                    `❀ *Debes mencionar o responder a un usuario*\n\n` +
                    `📌 *Ejemplos:*\n` +
                    `${config.prefix}setrole mod @usuario\n` +
                    `${config.prefix}setrole sub-owner (respondiendo a un mensaje)`
                );
            }
            
            // No permitir asignar roles al propio owner
            const ownerNumbers = config.owner || [];
            const isTargetOwner = ownerNumbers.some(owner => {
                const cleanOwner = cleanNumber(owner);
                return cleanOwner === targetNumber;
            });
            
            if (isTargetOwner) {
                return await replyWithContext(`❀ No puedes cambiar el rol del propietario del bot`);
            }
            
            // ============ GUARDAR ROL ============
            const roles = loadRoles();
            roles[targetNumber] = {
                rol: rol,
                asignadoPor: userNumber,
                fecha: new Date().toLocaleString()
            };
            
            saveRoles(roles);
            // ================================================================
            
            // ============ OBTENER NOMBRE DEL USUARIO ============
            let nombreUsuario = targetNumber;
            
            try {
                // Intentar obtener el nombre de contacto
                const contact = await sock.onWhatsApp(targetJid);
                if (contact && contact.length > 0 && contact[0].verifiedName) {
                    nombreUsuario = contact[0].verifiedName;
                } else {
                    // Buscar en la base de datos de usuarios
                    const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
                    if (fs.existsSync(USERS_FILE)) {
                        const usersData = fs.readFileSync(USERS_FILE, 'utf8');
                        const users = JSON.parse(usersData);
                        const user = users.find(u => u.number === targetNumber);
                        if (user && user.pushName) {
                            nombreUsuario = user.pushName;
                        }
                    }
                }
            } catch (e) {
                console.log('⚠️ No se pudo obtener nombre del usuario:', e.message);
            }
            // ================================================================
            
            // ============ MENSAJE DE RESPUESTA ============
            const mensaje = 
`❀ *ROL ASIGNADO* ❀

👤 *Usuario ›* ${nombreUsuario}
📌 *Rol ›* ${rol}
👑 *Asignado por ›* Owner

✅ El usuario ahora tiene el rol de *${rol}*`;

            await replyWithContext(mensaje);
            
            console.log(`✅ setrole ejecutado: ${targetNumber} → ${rol}`);
            // ================================================================
            
        } catch (error) {
            console.error('❌ Error en setrole:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};