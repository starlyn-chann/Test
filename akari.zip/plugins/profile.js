import db from '#db';
import moment from 'moment-timezone';

export default {
    name: 'profile',
    alias: ['perfil', 'pf'],
    description: 'Ver perfil de usuario',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        
        // Obtener usuario objetivo (mención o respuesta)
        let targetUser = userNumber;
        let targetPushName = pushName;
        let mentionedUser = null;
        
        // Verificar menciones
        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            const mentions = msg.message.extendedTextMessage.contextInfo.mentionedJid;
            if (mentions && mentions.length > 0) {
                mentionedUser = mentions[0];
                const cleanMentioned = mentionedUser.split(':')[0].split('@')[0].replace(/\D/g, '');
                const userFound = await db.getUser(cleanMentioned);
                if (userFound) {
                    targetUser = userFound.number;
                    targetPushName = userFound.pushName || 'Usuario';
                }
            }
        }
        
        // Verificar respuesta a mensaje
        if (!mentionedUser) {
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg) {
                const quotedParticipant = msg.message.extendedTextMessage.contextInfo.participant;
                if (quotedParticipant) {
                    const cleanQuoted = quotedParticipant.split(':')[0].split('@')[0].replace(/\D/g, '');
                    const userFound = await db.getUser(cleanQuoted);
                    if (userFound) {
                        targetUser = userFound.number;
                        targetPushName = userFound.pushName || 'Usuario';
                    }
                }
            }
        }
        
        // Obtener datos del usuario
        const userData = await db.getUser(targetUser);
        
        if (!userData) {
            return await replyWithContext(`🌼 *El usuario no está registrado aún*\n\nUsa un comando para registrarte automáticamente.`);
        }
        
        // Obtener todos los usuarios para el ranking
        const allUsers = await db.getAllUsers();
        const sortedUsers = allUsers.sort((a, b) => (b.nivel || 0) - (a.nivel || 0) || (b.exp || 0) - (a.exp || 0));
        const rank = sortedUsers.findIndex(u => u.number === targetUser) + 1;
        
        // Datos del usuario
        const nombre = userData.pushName || 'Usuario';
        const nivel = userData.nivel || 1;
        const exp = userData.exp || 0;
        const cmds = userData.cmds || 0;
        const genre = userData.genre || 'No especificado';
        const birth = userData.birth || 'No especificado';
        const pasatiempo = userData.pasatiempo || 'No definido';
        const description = userData.description || '';
        
        // Calcular EXP para siguiente nivel
        let expNeeded = 100;
        let currentLevel = 1;
        let currentExp = exp;
        while (currentLevel < nivel) {
            expNeeded = Math.floor(100 * Math.pow(1.5, currentLevel - 1));
            currentExp -= expNeeded;
            currentLevel++;
        }
        const nextLevelExp = Math.floor(100 * Math.pow(1.5, nivel - 1));
        const expProgress = currentExp;
        const expPercentage = Math.min(Math.floor((expProgress / nextLevelExp) * 100), 100);
        
        // Barra de progreso
        const barLength = 15;
        const filledBars = Math.floor((expPercentage / 100) * barLength);
        const emptyBars = barLength - filledBars;
        const progressBar = '▓'.repeat(filledBars) + '░'.repeat(emptyBars);
        
        // Obtener foto de perfil
        let profilePic = 'https://cdn.sockywa.xyz/files/1751246122292.jpg';
        try {
            const pic = await sock.profilePictureUrl(targetUser + '@s.whatsapp.net', 'image');
            if (pic) profilePic = pic;
        } catch {}
        
        // Diseño del perfil
        const profileText = `
⏜⏜︵︵︵ 𐔌 🥭ᩚܿ݀⋮ !! ︵︵︵⏜⏜

♡ — 🗡⃟⃟ᩚܹ   ⁝ 𝐇𝗈𝗅𝖺, *${nombre}*  𝖻𝗂𝖾𝗇𝗏𝖾𝗇𝗂𝖽𝗈/𝖺 𝖺 𝗍𝗎 𝗉𝖾𝗋𝖿𝗂𝗅 ʕ≧㉨≦ʔ!!      𠀾

> ✦ ${description}
  
    𝗗𝗮𝘁𝗼𝘀:

🥭݆݊ܶ⃝  : 𝗡𝗶𝘃𝗲𝗹 » *${nivel}*

🥭݆݊ܶ⃝  : 𝗘𝘅𝗽 » *${exp.toLocaleString()}*

🥭݆݊ܶ⃝  : 𝗖𝗼𝗺𝗮𝗻𝗱𝗼𝘀 » *${cmds.toLocaleString()}*

🥭݆݊ܶ⃝  : 𝗚𝗲́𝗻𝗲𝗿𝗼 » *${genre}*

🥭݆݊ܶ⃝  : 𝗙𝗲𝗰𝗵𝗮 𝗡𝗮𝗰. » *${birth}*

🥭݆݊ܶ⃝  : 𝗣𝗮𝘀𝗮𝘁𝗶𝗲𝗺𝗽𝗼 » *${pasatiempo}*

🥭݆݊ܶ⃝  : 𝗥𝗮𝗻𝗸𝗶𝗻𝗴 » *#${rank}* de ${allUsers.length}

︵︵ ꉂꉂ(ᵔᗜᵔ◍) . 🛞 ˙

≧ 🩹 ≦ 𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝗼:
${progressBar} ${expPercentage}%
${expProgress}/${nextLevelExp} EXP para nivel ${nivel + 1}`;
        
        // Enviar perfil con imagen
        await sock.sendMessage(
            msg.key.remoteJid,
            {
                image: { url: profilePic },
                caption: profileText,
                contextInfo: {
                    mentionedJid: [targetUser + '@s.whatsapp.net'],
                    forwardingScore: 999,
                    isForwarded: true
                }
            },
            { quoted: msg }
        );
    }
};