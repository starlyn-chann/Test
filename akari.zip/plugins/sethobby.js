import db from '#db';

export default {
    name: 'setpasatiempo',
    alias: ['sethobby', 'sethobbie'],
    description: 'Establece o elimina tu pasatiempo',
    category: 'profile',
    
    async execute(sock, msg, { args, config, startTime, isOwner, pushName, userNumber, senderJid, isGroup, replyWithContext }) {
        const user = await db.getUser(userNumber);
        const input = args.join(' ').trim();

        // Eliminar pasatiempo
        if (input === 'delete' || input === 'eliminar' || input === 'remove') {
            if (!user?.pasatiempo) {
                return await replyWithContext(`✐ *No tienes un pasatiempo establecido para eliminar.*`);
            }
            
            await db.updateUser(userNumber, 'pasatiempo', null);
            return await replyWithContext(`✐ *Tu pasatiempo ha sido eliminado correctamente.*`);
        }

        const pasatiemposDisponibles = [
            '📚 Leer', '✍️ Escribir', '🎤 Cantar', '💃 Bailar', '🎮 Jugar',
            '🎨 Dibujar', '🍳 Cocinar', '✈️ Viajar', '🏊 Nadar', '📸 Fotografía',
            '🎧 Escuchar música', '🏀 Deportes', '🎬 Ver películas', '🌿 Jardinería',
            '🧵 Manualidades', '🎲 Juegos de mesa', '🏋️‍♂️ Gimnasio', '🚴 Ciclismo',
            '🎯 Tiro con arco', '🍵 Ceremonia del té', '🧘‍♂️ Meditación', '🎪 Malabares',
            '🛠️ Bricolaje', '🎹 Tocar instrumentos', '🐶 Cuidar mascotas', '🌌 Astronomía',
            '♟️ Ajedrez', '🍷 Catación de vinos', '🛍️ Compras', '🏕️ Acampar',
            '🎣 Pescar', '📱 Tecnología', '🎭 Teatro', '🍽️ Gastronomía', '🏺 Coleccionar',
            '✂️ Costura', '🧁 Repostería', '📝 Blogging', '🚗 Automóviles', '🧩 Rompecabezas',
            '🎳 Bolos', '🏄 Surf', '⛷️ Esquí', '🎿 Snowboard', '🤿 Buceo', '🏹 Tiro al blanco',
            '🧭 Orientación', '🏇 Equitación', '🎨 Pintura', '📊 Invertir', '🌡️ Meteorología',
            '🔍 Investigar', '💄 Maquillaje', '💇‍♂️ Peluquería', '🛌 Dormir', '🍺 Cervecería',
            '🪓 Carpintería', '🧪 Experimentos', '📻 Radioafición', '🗺️ Geografía', '💎 Joyería',
            'Otro 🌟'
        ];

        if (!input) {
            let lista = '🎯 *Elige un pasatiempo:*\n\n';
            pasatiemposDisponibles.forEach((pasatiempo, index) => {
                lista += `${index + 1}) ${pasatiempo}\n`;
            });
            lista += `\n*Ejemplos:*\n${config.prefix}setpasatiempo 1\n${config.prefix}setpasatiempo Leer\n${config.prefix}setpasatiempo delete`;
            return await replyWithContext(lista);
        }

        let pasatiempoSeleccionado = '';

        if (/^\d+$/.test(input)) {
            const index = parseInt(input) - 1;
            if (index >= 0 && index < pasatiemposDisponibles.length) {
                pasatiempoSeleccionado = pasatiemposDisponibles[index];
            } else {
                return await replyWithContext(`《✧》 Número inválido. Selecciona un número entre 1 y ${pasatiemposDisponibles.length}`);
            }
        } else {
            const inputLimpio = input.replace(/[^\w\s]/g, '').toLowerCase().trim();
            const encontrado = pasatiemposDisponibles.find(
                p => p.replace(/[^\w\s]/g, '').toLowerCase().includes(inputLimpio)
            );
            if (encontrado) {
                pasatiempoSeleccionado = encontrado;
            } else {
                return await replyWithContext('《✧》 Pasatiempo no encontrado. Usa el comando sin argumentos para ver la lista disponible.');
            }
        }

        if (user?.pasatiempo === pasatiempoSeleccionado) {
            return await replyWithContext(`《✧》 Ya tienes establecido este pasatiempo: *${user.pasatiempo}*`);
        }

        await db.updateUser(userNumber, 'pasatiempo', pasatiempoSeleccionado);
        return await replyWithContext(`✐ Se ha establecido tu pasatiempo:\n> *${pasatiempoSeleccionado}*`);
    }
};