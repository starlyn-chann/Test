import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERHASH = '7eac01ee208c76d5f57056c68';

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'jpg';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', USERHASH);
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    if (typeof res.data !== 'string' || !res.data.startsWith('https://')) {
        throw new Error('Respuesta inválida de Catbox');
    }
    return res.data;
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'nanobanana',
    alias: [],
    description: 'Edita una imagen con IA',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, senderJid, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const prompt = args.join(' ').trim();
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage) {
                return await replyWithContext(`「✰」 Responde a una imagen para editarla\n> Ejemplo: Responde a una imagen con ${config.prefix}nanobanana ponle un gato`);
            }
            
            if (!prompt) {
                return await replyWithContext(`「✰」 Debes escribir una descripción para editar la imagen`);
            }
            
            let imageBuffer = null;
            let imageMime = '';
            
            if (quotedMessage.imageMessage) {
                const imageMsg = quotedMessage.imageMessage;
                imageMime = imageMsg.mimetype || 'image/jpeg';
                
                const quotedMsgObj = {
                    key: {
                        remoteJid: from,
                        id: quotedMsg.stanzaId,
                        participant: quotedMsg.participant || from,
                        fromMe: false
                    },
                    message: {
                        imageMessage: imageMsg
                    }
                };
                
                imageBuffer = await downloadMediaMessage(
                    quotedMsgObj,
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            } else {
                return await replyWithContext(`「✰」 Responde a una imagen`);
            }
            
            if (!imageBuffer || imageBuffer.length < 10) {
                return await replyWithContext(`《✧》 No se pudo descargar la imagen`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
            } catch (e) {}
            
            let catboxUrl;
            try {
                catboxUrl = await uploadCatbox(imageBuffer, imageMime);
                console.log(`✅ Imagen subida: ${catboxUrl}`);
            } catch (uploadError) {
                console.error('Error subiendo a Catbox:', uploadError);
                try {
                    await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🎨', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`「✰」 Procesando imagen con IA...`);
            
            const apiUrl = `https://api.neosoft.biz.id/api/ai-image/editimage?url=${encodeURIComponent(catboxUrl)}&prompt=${encodeURIComponent(prompt)}`;
            
            let resultBuffer;
            try {
                const response = await axios.get(apiUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0'
                    },
                    responseType: 'arraybuffer',
                    timeout: 20 * 60 * 1000
                });
                
                resultBuffer = Buffer.from(response.data);
                
                if (!resultBuffer || resultBuffer.length < 1000) {
                    throw new Error('Respuesta vacía o muy pequeña');
                }
                
                console.log(`✅ Imagen editada recibida: ${resultBuffer.length} bytes`);
                
            } catch (apiError) {
                console.error('Error API:', apiError.message);
                
                if (apiError.code === 'ECONNABORTED') {
                    await replyWithContext(`「✰」 El proceso excedió el tiempo de espera (20 minutos).\n> Intenta con una imagen más pequeña o un prompt más simple.`);
                } else if (apiError.response?.status === 500) {
                    await replyWithContext(`「✰」 La API está procesando tu solicitud pero tarda más de lo normal.\n> El resultado se enviará cuando esté listo.`);
                } else {
                    await replyWithContext(`「✰」 Error al procesar la imagen.\n> Detalle: ${apiError.message}`);
                }
                
                try {
                    await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            await sock.sendMessage(from, {
                image: resultBuffer,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Nanobanana completado: "${prompt.substring(0, 50)}" por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en nanobanana:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '✖️', key: msg.key } });
            } catch (e) {}
        }
    }
};