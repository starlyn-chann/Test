import syntaxerror from 'syntax-error';
import { format } from 'util';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const require = createRequire(__dirname);

export default {
    name: 'uwuuwu',
    alias: [],
    description: 'Envía un mensaje oculto en grupo que solo la persona mencionada o citada puede ver',
    category: 'General',

    async execute(sock, msg, options) {
        const { args, config, isGroup, userNumber, senderJid } = options;
        const from = msg.key.remoteJid;

        if (!isGroup) return;

        // Obtener datos del mensaje
        const msgContext = msg.message?.extendedTextMessage?.contextInfo || {};
        const quotedMsg = msgContext.quotedMessage;
        const mentionedJid = msgContext.mentionedJid || [];
        
        let targetUser = '';
        let messageText = '';

        const fullArgs = args.join(' ');

        // DEBUG: Ver qué está llegando
        console.log('📝 mentionedJid:', mentionedJid);
        console.log('📝 quotedMsg participant:', msgContext.participant);
        console.log('📝 fullArgs:', fullArgs);

        // Método 1: Respondiendo a un mensaje
        if (msgContext.participant && !targetUser) {
            targetUser = msgContext.participant;
            messageText = fullArgs;
            console.log('✅ Detectado por respuesta:', targetUser);
        }

        // Método 2: Mención directa
        if (mentionedJid.length > 0 && !targetUser) {
            targetUser = mentionedJid[0];
            // Limpiar el texto de la mención
            let cleanText = fullArgs;
            for (const mention of mentionedJid) {
                const mentionNumber = mention.split('@')[0];
                cleanText = cleanText.replace(new RegExp(`@${mentionNumber}`, 'g'), '');
            }
            messageText = cleanText.trim();
            console.log('✅ Detectado por mención:', targetUser);
        }

        // Método 3: Formato número | texto
        if (!targetUser && fullArgs.includes('|')) {
            const parts = fullArgs.split('|');
            const targetPart = parts[0].trim();
            messageText = parts.slice(1).join('|').trim();
            
            const numberMatch = targetPart.match(/(\d+)/);
            if (numberMatch) {
                targetUser = `${numberMatch[1]}@s.whatsapp.net`;
                console.log('✅ Detectado por formato |:', targetUser);
            }
        }

        // Si no hay destinatario o no hay mensaje, salir
        if (!targetUser || !messageText) {
            console.log('❌ No se detectó destinatario o mensaje vacío');
            return;
        }

        console.log('📤 Enviando a:', targetUser);
        console.log('📤 Mensaje:', messageText);

        const contextInfo = quotedMsg ? {
            stanzaId: msgContext.stanzaId,
            participant: msgContext.participant,
            quotedMessage: quotedMsg
        } : {};

        const privateMessage = {
            extendedTextMessage: {
                text: messageText,
                contextInfo: contextInfo
            }
        };

        const messageId = msgContext.stanzaId || msg.key.id;

        return await sock.relayMessage(from, privateMessage, {
            messageId: messageId,
            additionalAttributes: {
                addressing_mode: 'direct'
            },
            senderKeyJids: [targetUser],
            forceNewSenderKey: true,
            blockRetry: true,
            retryAllowedJids: [],
            useCachedGroupMetadata: false,
            useUserDevicesCache: false
        });
    }
};