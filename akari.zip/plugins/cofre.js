import economy from '#economy';
import { getFechaUltimoDomingo } from '../lib/time.js';

export default {
    name: 'cofre',
    alias: ['treasure', 'tesoro'],
    description: 'Reclama tu recompensa semanal del cofre',
    category: 'economy',
    
    async execute(sock, msg, { config, replyWithContext, isGroup, userNumber, pushName }) {
        try {
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            const now = Date.now();
            
            // Obtener el inicio de la semana (domingo a las 00:00) usando time.js
            const ultimoDomingo = getFechaUltimoDomingo();
            
            // Verificar si ya reclamo esta semana en este grupo
            const ultimoReclamoGrupo = await economy.getCofreGrupo(from, userNumber);
            
            if (ultimoReclamoGrupo > 0 && ultimoReclamoGrupo >= ultimoDomingo) {
                const tiempoRestante = (ultimoReclamoGrupo + 7 * 24 * 60 * 60 * 1000) - now;
                const dias = Math.floor(tiempoRestante / (24 * 60 * 60 * 1000));
                const horas = Math.floor((tiempoRestante % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
                return await replyWithContext(
                    `❀ *Ya reclamaste tu cofre en este grupo esta semana*\n` +
                    `> Vuelve en ${dias} días y ${horas} horas`
                );
            }
            
            // Obtener economía del usuario
            let userEconomy = await economy.getUserEconomy(from, userNumber);
            if (!userEconomy) {
                await economy.setUserEconomy(from, userNumber, {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                });
                userEconomy = await economy.getUserEconomy(from, userNumber);
            }
            
            const RECOMPENSA = 7000000;
            
            // Depositar en el banco
            await economy.updateUserEconomy(from, userNumber, {
                banco: RECOMPENSA,
                nombre: pushName || 'Usuario'
            });
            
            // Guardar cofre en economy.js (por grupo)
            await economy.setCofreGrupo(from, userNumber, now);
            
            const mensaje = `▭ֹ ▭ׅ ▭ֹ ▭ׅ ▭ׅ  ਏਓ  ▭ׅ ▭ֹ ▭ׅ ▭ֹ ▭ׅ \n\n` +
                     `𖹭ᩧ𑁀🪙̥  ֵ *Recompensa: ${economy.formatNumber(RECOMPENSA)} ${moneda}*\n` +
                     `> *Reclama todos los domingos para recibir tu recompensa* ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en cofre:', error);
            await replyWithContext(`❌ Error: ${error.message}`);
        }
    }
};