import { 
    makeWASocket,
    useMultiFileAuthState, 
    DisconnectReason, 
    Browsers,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    jidDecode
} from '@whiskeysockets/baileys';
import pino from 'pino';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import qrcode from 'qrcode-terminal';
import chalk from "chalk";
import NodeCache from 'node-cache';
import cfonts from 'cfonts';
import readlineSync from "readline-sync";
import { spawn } from 'child_process';

// ============ FORZAR IPv4 PARA MONGODB ============
import dns from 'dns';
dns.setDefaultResultOrder('ipv4first');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const config = await import('./config.js').then(m => m.default || m);
import handler from './handler.js';
import { createSubBot, getSub, getConnectionStatus } from './lib/sub.js';
import { createPremiumBot, getPrem, getPremConnectionStatus } from './lib/prem.js';

// ============ MONGODB CON MONGOOSE ============
import { connectMongoDB } from './lib/mongoose.js';

// ============ EVENTOS DE GRUPO (WELCOME / GOODBYE) ============
import events from './events.js';

// ============ ANTILINK ============
import antilinkHandler from './antilink.js';

// ============ LOGS DECORADOS ============
const log = {
  info: (msg) => console.log(chalk.bgBlue.white.bold(` INFO `), chalk.white(msg)),
  success: (msg) => console.log(chalk.bgGreen.white.bold(` SUCCESS `), chalk.greenBright(msg)),
  warn: (msg) => console.log(chalk.bgYellowBright.blueBright.bold(` WARNING `), chalk.yellow(msg)),
  error: (msg) => console.log(chalk.bgRed.white.bold(` ERROR `), chalk.redBright(msg))
};

const msgRetryCounterCache = new NodeCache();

const sessionName = "./sessions";
const methodCodeQR = process.argv.includes("--qr");
const methodCode = process.argv.includes("code") || process.argv.includes("--code");
let phoneNumber = "";
let phoneInput = "";
let opcion;

let globalSock = null;
let starProcess = null;

const DIGITS = (s = "") => String(s).replace(/\D/g, "");
function normalizePhoneForPairing(input) {
    let s = DIGITS(input);
    if (!s) return "";
    if (s.startsWith("0")) s = s.replace(/^0+/, "");
    if (s.length === 10 && s.startsWith("3")) s = "57" + s;
    if (s.startsWith("52") && !s.startsWith("521") && s.length >= 12) s = "521" + s.slice(2);
    if (s.startsWith("54") && !s.startsWith("549") && s.length >= 11) s = "549" + s.slice(2);
    return s;
}

// Crear carpetas necesarias
const folders = ['data', 'temp', 'sessions', 'plugins', 'subs', 'Sessions', 'Sessions/Subs', 'Sessions/prems'];
folders.forEach(folder => {
    if (!fs.existsSync(folder)) {
        fs.mkdirSync(folder, { recursive: true });
        log.info(`📁 Carpeta creada: ${folder}`);
    }
});

// ============ FUNCIÓN PARA INICIAR STAR.JS ============
function iniciarStarJS() {
    const starPath = path.join(__dirname, 'star.js');
    if (!fs.existsSync(starPath)) {
        log.warn(`⚠️ star.js no encontrado, omitiendo...`);
        return;
    }

    if (starProcess) {
        log.info(`⭐ star.js ya está corriendo`);
        return;
    }

    log.info(`⭐ Iniciando star.js (API de vinculación)...`);

    try {
        starProcess = spawn('node', [starPath], {
            stdio: 'inherit',
            detached: false
        });

        starProcess.on('error', (err) => {
            log.error(`❌ Error en star.js: ${err.message}`);
            starProcess = null;
        });

        starProcess.on('exit', (code) => {
            if (code !== 0 && code !== null) {
                log.warn(`⚠️ star.js cerró con código ${code}, reiniciando en 5s...`);
                starProcess = null;
                setTimeout(iniciarStarJS, 5000);
            } else {
                log.info(`⭐ star.js cerrado`);
                starProcess = null;
            }
        });

        log.success(`✅ star.js iniciado correctamente`);

    } catch (error) {
        log.error(`❌ Error iniciando star.js: ${error.message}`);
        starProcess = null;
    }
}

// ============ FUNCIÓN PARA DETENER STAR.JS ============
function detenerStarJS() {
    if (starProcess) {
        log.warn(`🛑 Deteniendo star.js...`);
        starProcess.kill();
        starProcess = null;
    }
}

// Limpiar carpeta temp
function cleanTempFolder() {
    const tempPath = path.join(__dirname, 'temp');
    if (!fs.existsSync(tempPath)) return;
    try {
        const files = fs.readdirSync(tempPath);
        let deletedCount = 0;
        files.forEach(file => {
            const filePath = path.join(tempPath, file);
            try {
                if (fs.statSync(filePath).isFile()) {
                    fs.unlinkSync(filePath);
                    deletedCount++;
                }
            } catch (err) {}
        });
        if (deletedCount > 0) {
            log.info(`🗑️ Cache tmp: ${deletedCount} archivos eliminados`);
        }
    } catch (error) {}
}

function startTempCleaner() {
    cleanTempFolder();
    setInterval(() => cleanTempFolder(), 5 * 60 * 1000);
}

// Mostrar banner
console.clear();

const { say } = cfonts;
say('STARLYN', {
    font: 'chrome',
    align: 'center',
    gradient: ['red', 'magenta']
});

say(`Powered by Moonlight Staff`, {
    font: 'console',
    align: 'center',
    gradient: ['red', 'magenta']
});

console.log(chalk.magentaBright('\n❀ Iniciando...\n'));

// Seleccionar método de conexión
if (methodCodeQR) {
    opcion = "1";
} else if (methodCode) {
    opcion = "2";
} else if (!fs.existsSync("./sessions/creds.json")) {
    console.log(chalk.bold.white("\nSeleccione una opción:"));
    console.log(chalk.blueBright("1. Con código QR"));
    console.log(chalk.cyan("2. Con código de texto de 8 dígitos"));
    opcion = readlineSync.question(chalk.bold.white("--> "));
    
    while (!/^[1-2]$/.test(opcion)) {
        log.warn(`No se permiten numeros que no sean 1 o 2`);
        opcion = readlineSync.question("--> ");
    }
    
    if (opcion === "2") {
        console.log(chalk.bold.redBright(`\nPor favor, Ingrese el número de WhatsApp.\n${chalk.bold.yellowBright("Ejemplo: +5219992042946")}\n${chalk.bold.magentaBright('---> ')}`));
        phoneInput = readlineSync.question("");
        phoneNumber = normalizePhoneForPairing(phoneInput);
    }
}

startTempCleaner();

let plugins = new Map();
let reconexion = 0;
const intentos = 15;

// Función para reconectar sub-bots existentes (sin crear nuevos)
async function reconectarSubBots() {
    const sessionsSubsDir = path.join(__dirname, 'Sessions', 'Subs');
    
    if (!fs.existsSync(sessionsSubsDir)) {
        return;
    }
    
    const subFolders = fs.readdirSync(sessionsSubsDir).filter(folder => {
        const folderPath = path.join(sessionsSubsDir, folder);
        return fs.statSync(folderPath).isDirectory() && /^\d+$/.test(folder);
    });
    
    if (subFolders.length === 0) return;
    
    log.info(`🔄 Verificando ${subFolders.length} sub-bot(s)...`);
    
    let conectados = 0;
    
    for (const subNumber of subFolders) {
        const credsPath = path.join(sessionsSubsDir, subNumber, 'creds.json');
        
        if (!fs.existsSync(credsPath)) continue;
        
        const existingSub = getSub(subNumber);
        if (existingSub?.sock?.user) {
            log.success(`✅ Sub-bot ${subNumber} ya está conectado`);
            conectados++;
            continue;
        }
        
        log.warn(`🔄 Conectando sub-bot: ${subNumber}`);
        try {
            await createSubBot(subNumber, subNumber);
            conectados++;
            await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (err) {
            log.error(`❌ Error conectando sub-bot ${subNumber}: ${err.message}`);
        }
    }
    
    log.success(`✅ Sub-bots conectados: ${conectados}/${subFolders.length}\n`);
}

// Función para reconectar bots premium existentes
async function reconectarPremiumBots() {
    const sessionsPremsDir = path.join(__dirname, 'Sessions', 'prems');
    
    if (!fs.existsSync(sessionsPremsDir)) {
        return;
    }
    
    const premFolders = fs.readdirSync(sessionsPremsDir).filter(folder => {
        const folderPath = path.join(sessionsPremsDir, folder);
        return fs.statSync(folderPath).isDirectory() && /^\d+$/.test(folder);
    });
    
    if (premFolders.length === 0) return;
    
    log.info(`🔄 Verificando ${premFolders.length} bot(s) premium...`);
    
    let conectados = 0;
    
    for (const premNumber of premFolders) {
        const credsPath = path.join(sessionsPremsDir, premNumber, 'creds.json');
        
        if (!fs.existsSync(credsPath)) continue;
        
        const existingPrem = getPrem(premNumber);
        if (existingPrem?.sock?.user) {
            log.success(`✅ Premium ${premNumber} ya está conectado`);
            conectados++;
            continue;
        }
        
        log.warn(`🔄 Conectando premium: ${premNumber}`);
        try {
            await createPremiumBot(premNumber, premNumber);
            conectados++;
            await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (err) {
            log.error(`❌ Error conectando premium ${premNumber}: ${err.message}`);
        }
    }
    
    log.success(`✅ Premium conectados: ${conectados}/${premFolders.length}\n`);
}

async function cargarPlugins() {
    const pluginsDir = path.join(__dirname, 'plugins');
    if (!fs.existsSync(pluginsDir)) {
        fs.mkdirSync(pluginsDir, { recursive: true });
        log.info(`📁 Carpeta plugins creada`);
        return;
    }
    
    const pluginFiles = fs.readdirSync(pluginsDir).filter(file => file.endsWith('.js'));
    plugins.clear();
    let successCount = 0;
    let failCount = 0;
    
    log.info(`📂 Cargando plugins (${pluginFiles.length})...\n`);
    
    for (const file of pluginFiles) {
        try {
            const filePath = path.join(pluginsDir, file);
            const fileUrl = `file://${filePath}?update=${Date.now()}`;
            const pluginModule = await import(fileUrl);
            const pluginData = pluginModule.default || pluginModule;
            
            if (pluginData.name) {
                plugins.set(pluginData.name.toLowerCase(), pluginData);
                
                if (pluginData.alias && Array.isArray(pluginData.alias)) {
                    pluginData.alias.forEach(alias => {
                        plugins.set(alias.toLowerCase(), pluginData);
                    });
                }
                log.success(`✅ Plugin cargado: ${pluginData.name}`);
                successCount++;
            } else {
                log.warn(`⚠️ Plugin ${file}: No exporta nombre`);
                failCount++;
            }
        } catch (error) {
            log.error(`❌ Error cargando plugin ${file}: ${error.message}`);
            failCount++;
        }
    }
    log.info(`📦 Total: ${successCount} plugins cargados, ${failCount} fallidos\n`);
}

async function startBot() {
    try {
        // ============ CONECTAR MONGODB ============
        try {
            await connectMongoDB();
            log.success(`✅ MongoDB conectado para packs 24/7`);
        } catch (error) {
            log.warn(`⚠️ MongoDB no disponible: ${error.message}`);
            log.warn(`💡 El bot continuará funcionando sin MongoDB`);
        }
        
        // ============ INICIAR STAR.JS ============
        iniciarStarJS();
        // =======================================
        
        const { state, saveCreds } = await useMultiFileAuthState(sessionName);
        const { version } = await fetchLatestBaileysVersion();
        
        const sock = makeWASocket({
            version,
            logger: pino({ level: "silent" }),
            printQRInTerminal: false,
            browser: Browsers.macOS('Chrome'),
            auth: { 
                creds: state.creds, 
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }))
            },
            markOnlineOnConnect: false,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            msgRetryCounterCache,
        });

        globalSock = sock;
        global.client = sock;

        await cargarPlugins();
        
        events(sock);
        log.success(`✅ Eventos de grupo cargados (welcome/goodbye)`);
        
        // Reconectar sub-bots y premiums después de que el main se conecte
        sock.ev.on("connection.update", async (update) => {
            const { connection } = update;
            if (connection === "open") {
                log.success(`🔌 Bot principal conectado, verificando sub-bots y premiums...`);
                setTimeout(() => {
                    reconectarSubBots();
                    reconectarPremiumBots();
                }, 5000);
            }
        });

        if (opcion === "2" && !fs.existsSync("./sessions/creds.json")) {
            setTimeout(async () => {
                try {
                    if (!state.creds.registered) {
                        const pairing = await sock.requestPairingCode(phoneNumber);
                        const codeBot = pairing?.match(/.{1,4}/g)?.join("-") || pairing;
                        console.log(chalk.bold.white(chalk.bgMagenta(`\n🔢 Código de emparejamiento:`)), chalk.bold.white(chalk.white(codeBot)));
                        log.info(`📱 Ingresa este código en WhatsApp > Dispositivos vinculados\n`);
                    }
                } catch (err) {
                    log.error(`Error al generar código: ${err.message}`);
                }
            }, 3000);
        }

        sock.ev.on("creds.update", saveCreds);

        sock.ev.on("connection.update", async (update) => {
            const { qr, connection, lastDisconnect } = update;
            
            if (qr && (opcion === '1' || methodCodeQR)) {
                console.log(chalk.green.bold("\n[ ✿ ] Escanea este código QR\n"));
                qrcode.generate(qr, { small: true });
            }

            if (connection === "close") {
                const reason = lastDisconnect?.error?.output?.statusCode || 0;
                
                const reasonMessages = {
                    [DisconnectReason.loggedOut]: "Sesión cerrada, eliminando...",
                    [DisconnectReason.forbidden]: "Acceso prohibido",
                    [DisconnectReason.multideviceMismatch]: "Dispositivos no coinciden",
                    [DisconnectReason.connectionReplaced]: "Conexión reemplazada",
                    [DisconnectReason.connectionLost]: "Se perdió la conexión al servidor, intentando reconectar...",
                    [DisconnectReason.connectionClosed]: "Conexión cerrada, intentando reconectarse...",
                    [DisconnectReason.restartRequired]: "Es necesario reiniciar...",
                    [DisconnectReason.timedOut]: "Tiempo de conexión agotado, intentando reconectarse...",
                    [DisconnectReason.badSession]: "Sesión inválida, limpiando y reconectando...",
                };

                if (reason === DisconnectReason.loggedOut || reason === 401 || reason === 403 || reason === 404) {
                    log.error(`Sesión cerrada (${reason}). Eliminando...`);
                    process.exit(1);
                } else if (reason === DisconnectReason.connectionReplaced) {
                    log.warn(`Conexión reemplazada`);
                    return;
                } else {
                    reconexion++;
                    if (reconexion > intentos) {
                        log.error(`Demasiados reintentos (${intentos}). Reinicia manualmente.`);
                        process.exit(1);
                    }
                    const delay = Math.min(3000 * reconexion, 30000);
                    log.warn(`${reasonMessages[reason] || `Desconexión (${reason})`}, reconectando en ${delay/1000}s...`);
                    setTimeout(() => startBot(), delay);
                }
            }

            if (connection === "open") {
                reconexion = 0;
                const userName = sock.user?.name || "Desconocido";
                log.success(`Conectado a: ${userName}`);
                log.success(`${config.nombre} ${config.nombre2} lista! Usa ${config.prefix}ping para probar.\n`);
                
                global.principalBot = sock;
                log.info(`Bot principal registrado globalmente para sugerencias`);
            }
        });

        sock.ev.on('messages.upsert', async (chatUpdate) => {
            try {
                const msg = chatUpdate.messages[0];
                if (!msg?.message) return;
                if (msg.key?.remoteJid === 'status@broadcast') return;
                
                if (Object.keys(msg.message)[0] === 'ephemeralMessage') {
                    msg.message = msg.message.ephemeralMessage.message;
                }
                
                if (msg.key.fromMe && msg.key.id.startsWith('3EB0')) return;
                
                await antilinkHandler(sock, msg);
                await handler(sock, msg, plugins, config);
            } catch (err) {
                log.error(`Error en mensaje: ${err}`);
            }
        });

        sock.decodeJid = (jid) => {
            if (!jid) return jid;
            if (/:\d+@/gi.test(jid)) {
                const decode = jidDecode(jid) || {};
                return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
            }
            return jid;
        };

        return sock;
        
    } catch (error) {
        log.error(`Error: ${error.message}`);
        log.warn(`Reintentando en 5 segundos...`);
        setTimeout(() => startBot(), 5000);
    }
}

startBot();

// Manejar cierre del proceso
process.once('SIGINT', () => {
    log.warn(`\nCerrando bot...\n`);
    detenerStarJS();
    if (globalSock) {
        try { globalSock.end(); } catch (e) {}
    }
    process.exit(0);
});

process.once('SIGTERM', () => {
    log.warn(`\nCerrando bot...\n`);
    detenerStarJS();
    if (globalSock) {
        try { globalSock.end(); } catch (e) {}
    }
    process.exit(0);
});
