import express from 'express';
import { getPairingCode } from './lib/sub.js';
import { verificarKey } from './lib/key.js';

const app = express();
app.use(express.json());

// ============ ENDPOINT PARA VERIFICAR KEY ============
app.post('/api/verify-key', (req, res) => {
    const { key } = req.body;

    if (!key) {
        return res.status(400).json({
            success: false,
            error: 'Falta la key'
        });
    }

    const result = verificarKey(key);

    return res.json({
        success: true,
        valid: result.valid,
        exists: result.exists,
        key: key
    });
});

// ============ ENDPOINT PARA GENERAR CÓDIGO ============
app.post('/api/pairing', async (req, res) => {
    const { number, config } = req.body;

    if (!number) {
        return res.status(400).json({
            success: false,
            error: 'Falta el número de teléfono'
        });
    }

    const numLimpio = number.replace(/\D/g, '');

    if (numLimpio.length < 10) {
        return res.status(400).json({
            success: false,
            error: 'Número inválido'
        });
    }

    try {
        const result = await getPairingCode(numLimpio, config || {});
        
        return res.json({
            success: true,
            code: result.code,
            number: numLimpio,
            status: result.status || 'pending'
        });
    } catch (error) {
        console.error('Error generando código:', error);
        return res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ============ ENDPOINT PARA ESTADO ============
app.get('/api/status', (req, res) => {
    res.json({
        success: true,
        status: 'online',
        timestamp: Date.now()
    });
});

const PORT = process.env.STAR_PORT || 8081;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`⭐ Star API corriendo en http://0.0.0.0:${PORT}`);
    console.log(`📡 POST /api/pairing`);
    console.log(`📡 POST /api/verify-key`);
    console.log(`📡 GET  /api/status`);
});